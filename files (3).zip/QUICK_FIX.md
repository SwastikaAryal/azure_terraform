# Quick Fix Guide - Pipeline Unblocking

## The Problem
Your pipeline failed with: **"This object does not have an attribute named 'generic'"**

This happens because the `bmw_backup_vault` module's diagnostic settings resource tries to access `module.common.names.generic`, but your `naming.json.tpl` doesn't define it.

## The Solution (2 minutes)

### Step 1: Update your naming.json.tpl
Add these two entries to the `resource_type` section of your `naming.json.tpl`:

```json
"generic": {
  "name": "${customer_prefix}${env}${2}${s}gen"
},
"azurerm_monitor_diagnostic_setting": {
  "name": "${customer_prefix}${env}${2}${s}diag"
}
```

**OR** simply replace your entire `naming.json.tpl` with the updated version provided.

### Step 2: Replace your Terraform files
Replace these files with the corrected versions:
- `main.tf` - Fixed monitoring resources
- `variables.tf` - Correct variable structure  
- `terraform.tfvars` - Fixed boolean and webhook structure

### Step 3: Update subscription ID
In `terraform.tfvars` line 40, replace with your actual subscription ID:
```hcl
scopes = ["/subscriptions/YOUR-ACTUAL-SUBSCRIPTION-ID"]
```

### Step 4: Run your pipeline
```bash
terraform init
terraform plan
terraform apply
```

## What Changed?

### In naming.json.tpl:
- ✅ Added `"generic"` resource type (REQUIRED)
- ✅ Added `"azurerm_monitor_diagnostic_setting"` resource type

### In terraform.tfvars:
- ✅ Fixed `enable_backup_vault = true` (was string "true")
- ✅ Moved `webhook_receivers` inside `action_group` object
- ✅ Changed webhook_receivers to array format `[{...}]`

### In main.tf:
- ✅ Fixed `webhook_receivers` reference (was singular)
- ✅ Added proper count conditions to all resources
- ✅ Fixed action group ID reference with index `[0]`

## Alternative Quick Fix (If you can't modify naming.json.tpl)

In `main.tf` line 27, temporarily disable diagnostic settings:
```hcl
enable_diagnostic_settings = false  # Temporary workaround
```

**Note:** This is NOT recommended for production as it disables monitoring.

## Verification

After applying, you should see these resources created:
- ✅ Backup Vault
- ✅ Action Group  
- ✅ Metric Alert
- ✅ Role Assignment
- ✅ Management Lock

Your pipeline should now complete successfully! 🚀
