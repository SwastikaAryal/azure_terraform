# =================================================================================================
# File: terraform/modules/v2/security/outputs.tf
# =================================================================================================

output "nsg_id" {
  description = "The ID of the Network Security Group"
  value       = var.create_nsg ? azurerm_network_security_group.this[0].id : null
}

output "nsg_name" {
  description = "The name of the Network Security Group"
  value       = var.create_nsg ? azurerm_network_security_group.this[0].name : null
}

output "nsg_rules" {
  description = "Map of NSG rule names to their IDs"
  value = {
    for k, v in azurerm_network_security_rule.this : k => v.id
  }
}

output "defender_plan_ids" {
  description = "Map of Defender plan resource types to their IDs"
  value = {
    for k, v in azurerm_security_center_subscription_pricing.this : k => v.id
  }
}

output "security_contact_id" {
  description = "The ID of the Security Center contact"
  value       = var.enable_security_contact ? azurerm_security_center_contact.this[0].id : null
}
