# =================================================================================================
# File: terraform/modules/v2/security/providers.tf
# =================================================================================================

terraform {
  required_version = ">= 1.11.4"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.27.0"
    }
  }
}
