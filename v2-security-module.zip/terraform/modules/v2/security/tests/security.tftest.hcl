# =================================================================================================
# File: terraform/modules/v2/security/tests/security.tftest.hcl
# =================================================================================================
# Terraform test file for the v2 security module.
# Run with: terraform test -chdir=terraform/modules/v2/security
# =================================================================================================

# --------------------------------------------------------------------------
# Mock provider – prevents real Azure calls during plan-mode tests
# --------------------------------------------------------------------------
mock_provider "azurerm" {}

# ==========================================================================
# TEST 1 – NSG creation with default settings
# ==========================================================================
run "nsg_creates_with_defaults" {
  command = plan

  variables {
    cloud_region        = "eastus"
    resource_group_name = "rg-test-security"
    nsg_name            = "nsg-test-app"
    create_nsg          = true
    nsg_rules           = []
    nsg_subnet_ids      = []
    enable_defender     = false
    defender_plans      = []
    enable_security_contact = false
    tags = {
      Environment = "Test"
      ManagedBy   = "Terraform"
    }
  }

  # NSG must be planned for creation
  assert {
    condition     = azurerm_network_security_group.this[0].name == "nsg-test-app"
    error_message = "NSG name must be 'nsg-test-app'."
  }

  assert {
    condition     = azurerm_network_security_group.this[0].location == "eastus"
    error_message = "NSG location must be 'eastus'."
  }

  assert {
    condition     = azurerm_network_security_group.this[0].resource_group_name == "rg-test-security"
    error_message = "NSG resource group must be 'rg-test-security'."
  }

  assert {
    condition     = azurerm_network_security_group.this[0].tags["Environment"] == "Test"
    error_message = "NSG must carry the Environment tag."
  }
}

# ==========================================================================
# TEST 2 – NSG creation is skipped when disabled
# ==========================================================================
run "nsg_skipped_when_disabled" {
  command = plan

  variables {
    cloud_region        = "eastus"
    resource_group_name = "rg-test-security"
    create_nsg          = false
    enable_defender     = false
    defender_plans      = []
    enable_security_contact = false
  }

  assert {
    condition     = length(azurerm_network_security_group.this) == 0
    error_message = "No NSG should be created when create_nsg is false."
  }

  assert {
    condition     = length(azurerm_network_security_rule.this) == 0
    error_message = "No NSG rules should be created when create_nsg is false."
  }
}

# ==========================================================================
# TEST 3 – NSG rules are planned correctly
# ==========================================================================
run "nsg_rules_are_created" {
  command = plan

  variables {
    cloud_region        = "eastus"
    resource_group_name = "rg-test-security"
    nsg_name            = "nsg-test-rules"
    create_nsg          = true
    enable_defender     = false
    defender_plans      = []
    enable_security_contact = false
    nsg_subnet_ids      = []

    nsg_rules = [
      {
        name                       = "AllowHTTPS"
        priority                   = 100
        direction                  = "Inbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "443"
        source_address_prefix      = "10.0.0.0/8"
        destination_address_prefix = "VirtualNetwork"
      },
      {
        name                       = "DenyAllInbound"
        priority                   = 4096
        direction                  = "Inbound"
        access                     = "Deny"
        protocol                   = "*"
        source_port_range          = "*"
        destination_port_range     = "*"
        source_address_prefix      = "*"
        destination_address_prefix = "*"
      }
    ]

    tags = {}
  }

  assert {
    condition     = length(azurerm_network_security_rule.this) == 2
    error_message = "Exactly 2 NSG rules should be planned."
  }

  assert {
    condition     = azurerm_network_security_rule.this["AllowHTTPS"].priority == 100
    error_message = "AllowHTTPS rule must have priority 100."
  }

  assert {
    condition     = azurerm_network_security_rule.this["AllowHTTPS"].direction == "Inbound"
    error_message = "AllowHTTPS rule direction must be Inbound."
  }

  assert {
    condition     = azurerm_network_security_rule.this["AllowHTTPS"].access == "Allow"
    error_message = "AllowHTTPS rule access must be Allow."
  }

  assert {
    condition     = azurerm_network_security_rule.this["AllowHTTPS"].destination_port_range == "443"
    error_message = "AllowHTTPS rule destination port must be 443."
  }

  assert {
    condition     = azurerm_network_security_rule.this["DenyAllInbound"].priority == 4096
    error_message = "DenyAllInbound rule must have priority 4096."
  }

  assert {
    condition     = azurerm_network_security_rule.this["DenyAllInbound"].access == "Deny"
    error_message = "DenyAllInbound rule access must be Deny."
  }
}

# ==========================================================================
# TEST 4 – Defender for Cloud plans are enabled
# ==========================================================================
run "defender_plans_enabled" {
  command = plan

  variables {
    cloud_region        = "eastus"
    resource_group_name = "rg-test-security"
    create_nsg          = false
    enable_security_contact = false

    enable_defender = true
    defender_plans = [
      {
        resource_type = "StorageAccounts"
        tier          = "Standard"
      },
      {
        resource_type = "VirtualMachines"
        tier          = "Standard"
        subplan       = "P2"
      },
      {
        resource_type = "KeyVaults"
        tier          = "Standard"
      }
    ]
  }

  assert {
    condition     = length(azurerm_security_center_subscription_pricing.this) == 3
    error_message = "Exactly 3 Defender plans should be enabled."
  }

  assert {
    condition     = azurerm_security_center_subscription_pricing.this["StorageAccounts"].tier == "Standard"
    error_message = "StorageAccounts Defender plan must be Standard tier."
  }

  assert {
    condition     = azurerm_security_center_subscription_pricing.this["VirtualMachines"].resource_type == "VirtualMachines"
    error_message = "VirtualMachines Defender plan must target VirtualMachines."
  }

  assert {
    condition     = azurerm_security_center_subscription_pricing.this["VirtualMachines"].subplan == "P2"
    error_message = "VirtualMachines Defender plan must use subplan P2."
  }

  assert {
    condition     = azurerm_security_center_subscription_pricing.this["KeyVaults"].tier == "Standard"
    error_message = "KeyVaults Defender plan must be Standard tier."
  }
}

# ==========================================================================
# TEST 5 – Defender is skipped when disabled
# ==========================================================================
run "defender_skipped_when_disabled" {
  command = plan

  variables {
    cloud_region        = "eastus"
    resource_group_name = "rg-test-security"
    create_nsg          = false
    enable_defender     = false
    defender_plans      = []
    enable_security_contact = false
  }

  assert {
    condition     = length(azurerm_security_center_subscription_pricing.this) == 0
    error_message = "No Defender plans should be created when enable_defender is false."
  }
}

# ==========================================================================
# TEST 6 – Security Center contact is created
# ==========================================================================
run "security_contact_created" {
  command = plan

  variables {
    cloud_region            = "eastus"
    resource_group_name     = "rg-test-security"
    create_nsg              = false
    enable_defender         = false
    defender_plans          = []
    enable_security_contact = true
    security_contact_email  = "security-team@company.com"
    security_contact_phone  = "+1-555-0100"
    alert_notifications     = true
    alerts_to_admins        = true
  }

  assert {
    condition     = azurerm_security_center_contact.this[0].email == "security-team@company.com"
    error_message = "Security contact email must match the input."
  }

  assert {
    condition     = azurerm_security_center_contact.this[0].phone == "+1-555-0100"
    error_message = "Security contact phone must match the input."
  }

  assert {
    condition     = azurerm_security_center_contact.this[0].alert_notifications == true
    error_message = "Alert notifications must be enabled."
  }

  assert {
    condition     = azurerm_security_center_contact.this[0].alerts_to_admins == true
    error_message = "Alerts to admins must be enabled."
  }
}

# ==========================================================================
# TEST 7 – Security contact is skipped when disabled
# ==========================================================================
run "security_contact_skipped_when_disabled" {
  command = plan

  variables {
    cloud_region            = "eastus"
    resource_group_name     = "rg-test-security"
    create_nsg              = false
    enable_defender         = false
    defender_plans          = []
    enable_security_contact = false
  }

  assert {
    condition     = length(azurerm_security_center_contact.this) == 0
    error_message = "No security contact should be created when disabled."
  }
}

# ==========================================================================
# TEST 8 – Full stack: NSG + Defender + Contact together
# ==========================================================================
run "full_security_stack" {
  command = plan

  variables {
    cloud_region        = "eastus"
    resource_group_name = "rg-prod-security"
    nsg_name            = "nsg-prod-app"
    create_nsg          = true

    nsg_rules = [
      {
        name                       = "AllowHTTPS"
        priority                   = 100
        direction                  = "Inbound"
        access                     = "Allow"
        protocol                   = "Tcp"
        source_port_range          = "*"
        destination_port_range     = "443"
        source_address_prefix      = "10.0.0.0/8"
        destination_address_prefix = "VirtualNetwork"
      }
    ]

    nsg_subnet_ids = []

    enable_defender = true
    defender_plans = [
      {
        resource_type = "StorageAccounts"
        tier          = "Standard"
      },
      {
        resource_type = "VirtualMachines"
        tier          = "Standard"
        subplan       = "P2"
      }
    ]

    enable_security_contact = true
    security_contact_email  = "soc@company.com"
    security_contact_phone  = "+1-555-0199"
    alert_notifications     = true
    alerts_to_admins        = true

    tags = {
      Environment = "Production"
      ManagedBy   = "Terraform"
      CostCenter  = "SEC-001"
    }
  }

  # NSG assertions
  assert {
    condition     = azurerm_network_security_group.this[0].name == "nsg-prod-app"
    error_message = "NSG name must be 'nsg-prod-app'."
  }

  assert {
    condition     = length(azurerm_network_security_rule.this) == 1
    error_message = "Exactly 1 NSG rule should be planned."
  }

  # Defender assertions
  assert {
    condition     = length(azurerm_security_center_subscription_pricing.this) == 2
    error_message = "Exactly 2 Defender plans should be enabled."
  }

  # Contact assertions
  assert {
    condition     = azurerm_security_center_contact.this[0].email == "soc@company.com"
    error_message = "Security contact email must be 'soc@company.com'."
  }

  # Tag assertions
  assert {
    condition     = azurerm_network_security_group.this[0].tags["CostCenter"] == "SEC-001"
    error_message = "NSG must carry the CostCenter tag."
  }
}

# ==========================================================================
# TEST 9 – NSG diagnostic settings are created when enabled
# ==========================================================================
run "nsg_diagnostics_enabled" {
  command = plan

  variables {
    cloud_region               = "eastus"
    resource_group_name        = "rg-test-security"
    nsg_name                   = "nsg-diag-test"
    create_nsg                 = true
    nsg_rules                  = []
    nsg_subnet_ids             = []
    enable_defender            = false
    defender_plans             = []
    enable_security_contact    = false
    create_diagnostic_settings = true
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-mon/providers/Microsoft.OperationalInsights/workspaces/law-test"
    tags                       = {}
  }

  assert {
    condition     = length(azurerm_monitor_diagnostic_setting.nsg) == 1
    error_message = "Diagnostic setting must be created when enabled."
  }

  assert {
    condition     = azurerm_monitor_diagnostic_setting.nsg[0].name == "nsg-diag-test-diag"
    error_message = "Diagnostic setting name must follow the naming convention."
  }
}

# ==========================================================================
# TEST 10 – Diagnostics skipped when NSG is disabled
# ==========================================================================
run "diagnostics_skipped_without_nsg" {
  command = plan

  variables {
    cloud_region               = "eastus"
    resource_group_name        = "rg-test-security"
    create_nsg                 = false
    enable_defender            = false
    defender_plans             = []
    enable_security_contact    = false
    create_diagnostic_settings = true
    log_analytics_workspace_id = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/rg-mon/providers/Microsoft.OperationalInsights/workspaces/law-test"
  }

  assert {
    condition     = length(azurerm_monitor_diagnostic_setting.nsg) == 0
    error_message = "Diagnostic settings must not be created when NSG is disabled."
  }
}

# ==========================================================================
# TEST 11 – Output values are correct
# ==========================================================================
run "outputs_are_correct" {
  command = plan

  variables {
    cloud_region        = "eastus"
    resource_group_name = "rg-test-outputs"
    nsg_name            = "nsg-output-test"
    create_nsg          = true
    nsg_rules           = []
    nsg_subnet_ids      = []
    enable_defender     = false
    defender_plans      = []
    enable_security_contact = false
    tags                = {}
  }

  assert {
    condition     = output.nsg_name == "nsg-output-test"
    error_message = "Output nsg_name must match the input."
  }

  assert {
    condition     = output.nsg_id != null
    error_message = "Output nsg_id must not be null when NSG is created."
  }
}

# ==========================================================================
# TEST 12 – Outputs are null when NSG is disabled
# ==========================================================================
run "outputs_null_when_nsg_disabled" {
  command = plan

  variables {
    cloud_region        = "eastus"
    resource_group_name = "rg-test-outputs"
    create_nsg          = false
    enable_defender     = false
    defender_plans      = []
    enable_security_contact = false
  }

  assert {
    condition     = output.nsg_name == null
    error_message = "Output nsg_name must be null when NSG is not created."
  }

  assert {
    condition     = output.nsg_id == null
    error_message = "Output nsg_id must be null when NSG is not created."
  }

  assert {
    condition     = output.security_contact_id == null
    error_message = "Output security_contact_id must be null when contact is not created."
  }
}
