# =================================================================================================
# File: terraform/modules/v2/security/main.tf
# =================================================================================================

# ============================= Network Security Group ============================= #
resource "azurerm_network_security_group" "this" {
  count = var.create_nsg ? 1 : 0

  name                = var.nsg_name
  location            = var.cloud_region
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

# ============================= NSG Rules ============================= #
resource "azurerm_network_security_rule" "this" {
  for_each = var.create_nsg ? { for rule in var.nsg_rules : rule.name => rule } : {}

  name                        = each.value.name
  priority                    = each.value.priority
  direction                   = each.value.direction
  access                      = each.value.access
  protocol                    = each.value.protocol
  source_port_range           = lookup(each.value, "source_port_range", "*")
  destination_port_range      = lookup(each.value, "destination_port_range", null)
  destination_port_ranges     = lookup(each.value, "destination_port_ranges", null)
  source_address_prefix       = lookup(each.value, "source_address_prefix", null)
  source_address_prefixes     = lookup(each.value, "source_address_prefixes", null)
  destination_address_prefix  = lookup(each.value, "destination_address_prefix", null)
  destination_address_prefixes = lookup(each.value, "destination_address_prefixes", null)
  resource_group_name         = var.resource_group_name
  network_security_group_name = azurerm_network_security_group.this[0].name
}

# ============================= NSG Subnet Association ============================= #
resource "azurerm_subnet_network_security_group_association" "this" {
  for_each = var.create_nsg ? toset(var.nsg_subnet_ids) : toset([])

  subnet_id                 = each.value
  network_security_group_id = azurerm_network_security_group.this[0].id
}

# ============================= Microsoft Defender for Cloud ============================= #
resource "azurerm_security_center_subscription_pricing" "this" {
  for_each = var.enable_defender ? { for plan in var.defender_plans : plan.resource_type => plan } : {}

  tier          = each.value.tier
  resource_type = each.value.resource_type
  subplan       = lookup(each.value, "subplan", null)
}

# ============================= Security Center Contact ============================= #
resource "azurerm_security_center_contact" "this" {
  count = var.enable_security_contact ? 1 : 0

  email               = var.security_contact_email
  phone               = var.security_contact_phone
  alert_notifications = var.alert_notifications
  alerts_to_admins    = var.alerts_to_admins
}

# ============================= NSG Diagnostic Settings ============================= #
resource "azurerm_monitor_diagnostic_setting" "nsg" {
  count = var.create_nsg && var.create_diagnostic_settings ? 1 : 0

  name                       = format("%s-diag", var.nsg_name)
  target_resource_id         = azurerm_network_security_group.this[0].id
  log_analytics_workspace_id = var.log_analytics_workspace_id

  enabled_log {
    category = "NetworkSecurityGroupEvent"
  }

  enabled_log {
    category = "NetworkSecurityGroupRuleCounter"
  }
}
