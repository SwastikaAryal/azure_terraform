# =================================================================================================
# File: terraform/modules/v2/security/terraform.tfvars
# Example values – adjust for your environment
# =================================================================================================

cloud_region        = "eastus"
resource_group_name = "rg-prod-security"

# NSG Configuration
create_nsg = true
nsg_name   = "nsg-app-tier"

nsg_rules = [
  {
    name                       = "AllowHTTPS"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "443"
    source_address_prefix      = "10.0.0.0/8"
    destination_address_prefix = "VirtualNetwork"
  },
  {
    name                       = "AllowRDP"
    priority                   = 110
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "3389"
    source_address_prefix      = "10.1.0.0/16"
    destination_address_prefix = "VirtualNetwork"
  },
  {
    name                       = "DenyAllInbound"
    priority                   = 4096
    direction                  = "Inbound"
    access                     = "Deny"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "*"
    destination_address_prefix = "*"
  }
]

nsg_subnet_ids = []

# Microsoft Defender for Cloud
enable_defender = true
defender_plans = [
  {
    resource_type = "StorageAccounts"
    tier          = "Standard"
  },
  {
    resource_type = "VirtualMachines"
    tier          = "Standard"
    subplan       = "P2"
  },
  {
    resource_type = "KeyVaults"
    tier          = "Standard"
  },
  {
    resource_type = "Arm"
    tier          = "Standard"
  }
]

# Security Center Contact
enable_security_contact = true
security_contact_email  = "security-team@company.com"
security_contact_phone  = "+1-555-0100"
alert_notifications     = true
alerts_to_admins        = true

# Diagnostic Settings
create_diagnostic_settings = true
log_analytics_workspace_id = "/subscriptions/XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX/resourceGroups/rg-monitoring-prod/providers/Microsoft.OperationalInsights/workspaces/law-prod-eastus"

# Tags
tags = {
  Environment = "Production"
  ManagedBy   = "Terraform"
  CostCenter  = "SEC-001"
  Owner       = "security-team@company.com"
}
