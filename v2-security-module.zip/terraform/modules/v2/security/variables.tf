# =================================================================================================
# File: terraform/modules/v2/security/variables.tf
# =================================================================================================

# ============================= General ============================= #
variable "cloud_region" {
  description = "Azure cloud region for the resources"
  type        = string
}

variable "resource_group_name" {
  description = "Name of the resource group"
  type        = string
}

variable "tags" {
  description = "Tags to apply to resources"
  type        = map(string)
  default     = {}
}

# ============================= NSG Configuration ============================= #
variable "create_nsg" {
  description = "Whether to create a Network Security Group"
  type        = bool
  default     = true
}

variable "nsg_name" {
  description = "Name of the Network Security Group"
  type        = string
  default     = "nsg-default"
}

variable "nsg_rules" {
  description = "List of NSG rules to create"
  type = list(object({
    name                         = string
    priority                     = number
    direction                    = string
    access                       = string
    protocol                     = string
    source_port_range            = optional(string, "*")
    destination_port_range       = optional(string)
    destination_port_ranges      = optional(list(string))
    source_address_prefix        = optional(string)
    source_address_prefixes      = optional(list(string))
    destination_address_prefix   = optional(string)
    destination_address_prefixes = optional(list(string))
  }))
  default = []
}

variable "nsg_subnet_ids" {
  description = "List of subnet IDs to associate with the NSG"
  type        = list(string)
  default     = []
}

# ============================= Microsoft Defender for Cloud ============================= #
variable "enable_defender" {
  description = "Enable Microsoft Defender for Cloud plans"
  type        = bool
  default     = false
}

variable "defender_plans" {
  description = "List of Defender for Cloud pricing plans to enable"
  type = list(object({
    resource_type = string
    tier          = optional(string, "Standard")
    subplan       = optional(string)
  }))
  default = []
}

# ============================= Security Center Contact ============================= #
variable "enable_security_contact" {
  description = "Whether to create a Security Center contact"
  type        = bool
  default     = false
}

variable "security_contact_email" {
  description = "Email address for Security Center contact"
  type        = string
  default     = ""
}

variable "security_contact_phone" {
  description = "Phone number for Security Center contact"
  type        = string
  default     = ""
}

variable "alert_notifications" {
  description = "Whether to send alert notifications to the security contact"
  type        = bool
  default     = true
}

variable "alerts_to_admins" {
  description = "Whether to send alerts to subscription admins"
  type        = bool
  default     = true
}

# ============================= Diagnostic Settings ============================= #
variable "create_diagnostic_settings" {
  description = "Whether to create diagnostic settings for NSG"
  type        = bool
  default     = false
}

variable "log_analytics_workspace_id" {
  description = "The ID of the Log Analytics Workspace for diagnostics"
  type        = string
  default     = null
}
