# =============================================================================
# AUTOMATION ACCOUNT + ALL CHILD RESOURCES
# =============================================================================

# NOTE: The automation account itself is not in the ARM export (it was created
# by the module earlier). We reference it by name in all child resources.
# If the automation account resource is also needed in state, add it below.
# Check: does "fsamccg2-aa-auto" already exist in your state?
# If NOT in state, uncomment and import the block below.

# resource "azurerm_automation_account" "aa" {
#   name                = "fsamccg2-aa-auto"
#   location            = local.region
#   resource_group_name = local.rg
#   sku_name            = "Basic"
#   identity {
#     type         = "SystemAssigned, UserAssigned"
#     identity_ids = [azurerm_user_assigned_identity.central_uai.id]
#   }
#   tags = local.common_tags
#   lifecycle { ignore_changes = [tags] }
# }

# ---------------------------------------------------------------------------
# Connection Types
# ---------------------------------------------------------------------------
resource "azurerm_automation_connection_type" "conn_azure" {
  automation_account_name = local.aa
  is_global               = true
  name                    = "Azure"
  resource_group_name     = local.rg
  field {
    is_encrypted = false
    is_optional  = false
    name         = "AutomationCertificateName"
    type         = "System.String"
  }
  field {
    is_encrypted = false
    is_optional  = false
    name         = "SubscriptionID"
    type         = "System.String"
  }
  lifecycle { ignore_changes = all }
}

resource "azurerm_automation_connection_type" "conn_classic" {
  automation_account_name = local.aa
  is_global               = true
  name                    = "AzureClassicCertificate"
  resource_group_name     = local.rg
  field {
    is_encrypted = false
    is_optional  = false
    name         = "SubscriptionName"
    type         = "System.String"
  }
  field {
    is_encrypted = false
    is_optional  = false
    name         = "SubscriptionId"
    type         = "System.String"
  }
  field {
    is_encrypted = false
    is_optional  = false
    name         = "CertificateAssetName"
    type         = "System.String"
  }
  lifecycle { ignore_changes = all }
}

resource "azurerm_automation_connection_type" "conn_sp" {
  automation_account_name = local.aa
  is_global               = true
  name                    = "AzureServicePrincipal"
  resource_group_name     = local.rg
  field {
    is_encrypted = false
    is_optional  = false
    name         = "ApplicationId"
    type         = "System.String"
  }
  field {
    is_encrypted = false
    is_optional  = false
    name         = "TenantId"
    type         = "System.String"
  }
  field {
    is_encrypted = false
    is_optional  = false
    name         = "CertificateThumbprint"
    type         = "System.String"
  }
  field {
    is_encrypted = false
    is_optional  = false
    name         = "SubscriptionId"
    type         = "System.String"
  }
  lifecycle { ignore_changes = all }
}

# ---------------------------------------------------------------------------
# Schedules
# ---------------------------------------------------------------------------
resource "azurerm_automation_schedule" "idle_detection" {
  automation_account_name = local.aa
  description             = "Schedule for VM idle detection and shutdown"
  expiry_time             = "9999-12-31T18:59:00-05:00"
  frequency               = "Hour"
  interval                = 2
  name                    = "schedule-vm-idle-detection"
  resource_group_name     = local.rg
  start_time              = "2025-09-07T23:05:00-04:00"
  timezone                = "America/New_York"
  lifecycle { ignore_changes = [start_time, expiry_time] }
}

resource "azurerm_automation_schedule" "vm_shutdown" {
  automation_account_name = local.aa
  description             = "Daily schedule for VM shutdown outside business hours"
  expiry_time             = "9999-12-31T18:59:00-05:00"
  frequency               = "Week"
  interval                = 1
  name                    = "schedule-vm-shutdown"
  resource_group_name     = local.rg
  start_time              = "2025-09-09T14:00:00-04:00"
  timezone                = "America/New_York"
  week_days               = ["Friday", "Monday", "Thursday", "Tuesday", "Wednesday"]
  lifecycle { ignore_changes = [start_time, expiry_time] }
}

resource "azurerm_automation_schedule" "vm_startup" {
  automation_account_name = local.aa
  description             = "Daily schedule for VM startup at business hours"
  expiry_time             = "9999-12-31T18:59:00-05:00"
  frequency               = "Week"
  interval                = 1
  name                    = "schedule-vm-startup"
  resource_group_name     = local.rg
  start_time              = "2025-09-09T14:00:00-04:00"
  timezone                = "America/New_York"
  week_days               = ["Friday", "Monday", "Thursday", "Tuesday", "Wednesday"]
  lifecycle { ignore_changes = [start_time, expiry_time] }
}

# ---------------------------------------------------------------------------
# Automation Variables
# ---------------------------------------------------------------------------
resource "azurerm_automation_variable_string" "business_days" {
  automation_account_name = local.aa
  description             = "Comma-separated list of business days (1=Monday, 7=Sunday)"
  encrypted               = false
  name                    = "BusinessDays"
  resource_group_name     = local.rg
  value                   = "1,2,3,4,5"
}

resource "azurerm_automation_variable_string" "business_hours_end" {
  automation_account_name = local.aa
  description             = "Business day end time in HH:MM format"
  encrypted               = false
  name                    = "BusinessHoursEnd"
  resource_group_name     = local.rg
  value                   = "18:00"
}

resource "azurerm_automation_variable_string" "business_hours_start" {
  automation_account_name = local.aa
  description             = "Business day start time in HH:MM format"
  encrypted               = false
  name                    = "BusinessHoursStart"
  resource_group_name     = local.rg
  value                   = "08:00"
}

resource "azurerm_automation_variable_bool" "dry_run_mode" {
  automation_account_name = local.aa
  description             = "Enable dry run mode (log actions without executing)"
  encrypted               = false
  name                    = "DryRunMode"
  resource_group_name     = local.rg
  value                   = true
}

resource "azurerm_automation_variable_bool" "enable_vm_deallocate" {
  automation_account_name = local.aa
  description             = "Deallocate VMs instead of just stopping them"
  encrypted               = false
  name                    = "EnableVMDeallocate"
  resource_group_name     = local.rg
  value                   = true
}

resource "azurerm_automation_variable_string" "excluded_vm_tags" {
  automation_account_name = local.aa
  description             = "JSON object of tag key-value pairs that exclude VMs"
  encrypted               = false
  name                    = "ExcludedVMTags"
  resource_group_name     = local.rg
  value = jsonencode({
    AlwaysOn       = "true"
    AutoShutdown   = "Disabled"
    DatabaseServer = "true"
    Environment    = "Gold"
  })
}

resource "azurerm_automation_variable_string" "required_vm_tags" {
  automation_account_name = local.aa
  description             = "JSON object of tag key-value pairs required for VM inclusion"
  encrypted               = false
  name                    = "RequiredVMTags"
  resource_group_name     = local.rg
  value = jsonencode({
    CostCenter = "*"
  })
}

resource "azurerm_automation_variable_string" "target_resource_groups" {
  automation_account_name = local.aa
  description             = "Comma-separated list of resource group patterns"
  encrypted               = false
  name                    = "TargetResourceGroups"
  resource_group_name     = local.rg
  value                   = "FSAM-CLEANCONFIG-RG"
}

resource "azurerm_automation_variable_string" "target_subscriptions" {
  automation_account_name = local.aa
  description             = "Comma-separated list of subscription IDs to monitor"
  encrypted               = false
  name                    = "TargetSubscriptions"
  resource_group_name     = local.rg
  value                   = "4cda8977-68ea-4ca5-aa6a-fae45e7e98f3"
}

resource "azurerm_automation_variable_string" "timezone" {
  automation_account_name = local.aa
  description             = "Timezone for business hours calculation"
  encrypted               = false
  name                    = "Timezone"
  resource_group_name     = local.rg
  value                   = "America/New_York"
}

resource "azurerm_automation_variable_string" "vm_cpu_threshold" {
  automation_account_name = local.aa
  description             = "CPU utilization threshold for idle detection"
  encrypted               = false
  name                    = "VMCPUThreshold"
  resource_group_name     = local.rg
  value                   = "5"
}

resource "azurerm_automation_variable_string" "vm_disk_threshold_mb" {
  automation_account_name = local.aa
  description             = "Disk activity threshold in MB for idle detection"
  encrypted               = false
  name                    = "VMDiskThresholdMB"
  resource_group_name     = local.rg
  value                   = "50"
}

resource "azurerm_automation_variable_string" "vm_grace_period_minutes" {
  automation_account_name = local.aa
  description             = "Grace period before shutting down idle VMs"
  encrypted               = false
  name                    = "VMGracePeriodMinutes"
  resource_group_name     = local.rg
  value                   = "15"
}

resource "azurerm_automation_variable_string" "vm_idle_threshold_hours" {
  automation_account_name = local.aa
  description             = "Hours a VM must be idle before shutdown consideration"
  encrypted               = false
  name                    = "VMIdleThresholdHours"
  resource_group_name     = local.rg
  value                   = "2"
}

resource "azurerm_automation_variable_string" "vm_network_threshold_mb" {
  automation_account_name = local.aa
  description             = "Network activity threshold in MB for idle detection"
  encrypted               = false
  name                    = "VMNetworkThresholdMB"
  resource_group_name     = local.rg
  value                   = "10"
}

# ---------------------------------------------------------------------------
# Runbooks  (content = what is currently in Azure — omit to avoid content diffs)
# ---------------------------------------------------------------------------
resource "azurerm_automation_runbook" "idle_shutdown" {
  automation_account_name  = local.aa
  description              = "Automatically shutdown VMs that have been idle based on CPU, network, and disk metrics"
  location                 = local.region
  log_activity_trace_level = 0
  log_progress             = true
  log_verbose              = true
  name                     = "Invoke-VMIdleShutdown"
  resource_group_name      = local.rg
  runbook_type             = "PowerShell"
  tags = {
    Component   = "Automation"
    Environment = "CleanConfig"
    ManagedBy   = "Terraform"
    Purpose     = "IdleDetection"
    Team        = "FSCloudTeam"
  }
  # content managed in portal — prevent Terraform from overwriting it
  lifecycle { ignore_changes = [content, tags] }
}

resource "azurerm_automation_runbook" "scheduled_shutdown" {
  automation_account_name  = local.aa
  description              = "Automatically shutdown VMs outside of business hours based on schedule"
  location                 = local.region
  log_activity_trace_level = 0
  log_progress             = true
  log_verbose              = true
  name                     = "Invoke-VMScheduledShutdown"
  resource_group_name      = local.rg
  runbook_type             = "PowerShell"
  tags = {
    Component   = "Automation"
    Environment = "CleanConfig"
    ManagedBy   = "Terraform"
    Purpose     = "ScheduledShutdown"
    Team        = "FSCloudTeam"
  }
  lifecycle { ignore_changes = [content, tags] }
}

resource "azurerm_automation_runbook" "vm_startup" {
  automation_account_name  = local.aa
  description              = "Automatically start VMs at the beginning of business hours"
  location                 = local.region
  log_activity_trace_level = 0
  log_progress             = true
  log_verbose              = true
  name                     = "Invoke-VMStartup"
  resource_group_name      = local.rg
  runbook_type             = "PowerShell"
  tags = {
    Component   = "Automation"
    Environment = "CleanConfig"
    ManagedBy   = "Terraform"
    Purpose     = "VMStartup"
    Team        = "FSCloudTeam"
  }
  lifecycle { ignore_changes = [content, tags] }
}

resource "azurerm_automation_runbook" "sample_ps" {
  automation_account_name  = local.aa
  description              = "Sample PowerShell runbook for cleanconfig"
  location                 = local.region
  log_activity_trace_level = 0
  log_progress             = true
  log_verbose              = true
  name                     = "Sample-PowerShell-Runbook"
  resource_group_name      = local.rg
  runbook_type             = "PowerShell"
  tags                     = local.common_tags
  lifecycle { ignore_changes = [content, tags] }
}

resource "azurerm_automation_runbook" "sample_py" {
  automation_account_name  = local.aa
  description              = "Sample Python 3 runbook for cleanconfig"
  location                 = local.region
  log_activity_trace_level = 0
  log_progress             = true
  log_verbose              = true
  name                     = "Sample-Python3-Runbook"
  resource_group_name      = local.rg
  runbook_type             = "Python3"
  tags                     = local.common_tags
  lifecycle { ignore_changes = [content, tags] }
}

# ---------------------------------------------------------------------------
# Job Schedules  (Runbook ↔ Schedule links)
# ---------------------------------------------------------------------------
resource "azurerm_automation_job_schedule" "idle_detection" {
  automation_account_name = local.aa
  job_schedule_id         = "2477edff-a75e-4f0c-840f-ca286d7a024b"
  parameters = {
    dryrunmode           = "true"
    enablevmdeallocate   = "true"
    excludedvmtags       = "{\"AlwaysOn\":\"true\",\"AutoShutdown\":\"Disabled\",\"DatabaseServer\":\"true\",\"Environment\":\"Gold\"}"
    requiredvmtags       = "{\"CostCenter\":\"*\"}"
    targetresourcegroups = "FSAM-CLEANCONFIG-RG"
    targetsubscriptions  = "4cda8977-68ea-4ca5-aa6a-fae45e7e98f3"
    vmcputhreshold       = "5"
    vmdiskthresholdmb    = "10"
    vmgraceperiodminutes = "15"
    vmidlethresholdhours = "2"
    vmnetworkthresholdmb = "10"
  }
  resource_group_name = local.rg
  runbook_name        = azurerm_automation_runbook.idle_shutdown.name
  schedule_name       = azurerm_automation_schedule.idle_detection.name
  lifecycle { ignore_changes = all }
}

resource "azurerm_automation_job_schedule" "vm_startup_job" {
  automation_account_name = local.aa
  job_schedule_id         = "3cf6c93f-13cc-4223-b303-8823f238dc72"
  parameters = {
    dryrunmode           = "true"
    excludedvmtags       = "{\"AlwaysOn\":\"true\",\"AutoShutdown\":\"Disabled\",\"DatabaseServer\":\"true\",\"Environment\":\"Gold\"}"
    requiredvmtags       = "{\"CostCenter\":\"*\"}"
    targetresourcegroups = "FSAM-CLEANCONFIG-RG"
    targetsubscriptions  = "4cda8977-68ea-4ca5-aa6a-fae45e7e98f3"
  }
  resource_group_name = local.rg
  runbook_name        = azurerm_automation_runbook.vm_startup.name
  schedule_name       = azurerm_automation_schedule.vm_startup.name
  lifecycle { ignore_changes = all }
}

resource "azurerm_automation_job_schedule" "scheduled_shutdown_job" {
  automation_account_name = local.aa
  job_schedule_id         = "5522304f-39b0-4a02-9883-76533db4bca9"
  parameters = {
    businessdays         = "1,2,3,4,5"
    businesshoursend     = "18:00"
    businesshoursstart   = "08:00"
    dryrunmode           = "true"
    enablevmdeallocate   = "true"
    excludedvmtags       = "{\"AlwaysOn\":\"true\",\"AutoShutdown\":\"Disabled\",\"DatabaseServer\":\"true\",\"Environment\":\"Gold\"}"
    requiredvmtags       = "{\"CostCenter\":\"*\"}"
    targetresourcegroups = "FSAM-CLEANCONFIG-RG"
    targetsubscriptions  = "4cda8977-68ea-4ca5-aa6a-fae45e7e98f3"
    timezone             = "America/New_York"
  }
  resource_group_name = local.rg
  runbook_name        = azurerm_automation_runbook.scheduled_shutdown.name
  schedule_name       = azurerm_automation_schedule.vm_shutdown.name
  lifecycle { ignore_changes = all }
}

# ---------------------------------------------------------------------------
# Webhooks  (uri is write-only — always ignore it)
# ---------------------------------------------------------------------------
resource "azurerm_automation_webhook" "sample_webhook" {
  automation_account_name = local.aa
  enabled                 = true
  expiry_time             = "2035-01-19T11:03:04.329+00:00"
  name                    = "SampleWebhookcleanconfig"
  parameters              = {}
  resource_group_name     = local.rg
  run_on_worker_group     = ""
  runbook_name            = azurerm_automation_runbook.sample_ps.name
  uri                     = "https://placeholder-not-used"
  lifecycle { ignore_changes = [uri, expiry_time] }
}

resource "azurerm_automation_webhook" "webhook_idle_shutdown" {
  automation_account_name = local.aa
  enabled                 = true
  expiry_time             = "2026-09-08T02:05:55+00:00"
  name                    = "webhook-vm-idle-shutdown"
  parameters = {
    dryrunmode           = "true"
    excludedvmtags       = "{\"AlwaysOn\":\"true\",\"AutoShutdown\":\"Disabled\",\"DatabaseServer\":\"true\",\"Environment\":\"Gold\"}"
    requiredvmtags       = "{\"CostCenter\":\"*\"}"
    targetresourcegroups = "FSAM-CLEANCONFIG-RG"
    targetsubscriptions  = "4cda8977-68ea-4ca5-aa6a-fae45e7e98f3"
  }
  resource_group_name = local.rg
  run_on_worker_group = ""
  runbook_name        = azurerm_automation_runbook.idle_shutdown.name
  uri                 = "https://placeholder-not-used"
  lifecycle { ignore_changes = [uri, expiry_time] }
}

resource "azurerm_automation_webhook" "webhook_scheduled_shutdown" {
  automation_account_name = local.aa
  enabled                 = true
  expiry_time             = "2026-09-08T02:06:28+00:00"
  name                    = "webhook-vm-scheduled-shutdown"
  parameters = {
    businessdays         = "1,2,3,4,5"
    businesshoursend     = "18:00"
    businesshoursstart   = "08:00"
    dryrunmode           = "true"
    enablevmdeallocate   = "true"
    excludedvmtags       = "{\"AlwaysOn\":\"true\",\"AutoShutdown\":\"Disabled\",\"DatabaseServer\":\"true\",\"Environment\":\"Gold\"}"
    requiredvmtags       = "{\"CostCenter\":\"*\"}"
    targetresourcegroups = "FSAM-CLEANCONFIG-RG"
    targetsubscriptions  = "4cda8977-68ea-4ca5-aa6a-fae45e7e98f3"
    timezone             = "America/New_York"
  }
  resource_group_name = local.rg
  run_on_worker_group = ""
  runbook_name        = azurerm_automation_runbook.scheduled_shutdown.name
  uri                 = "https://placeholder-not-used"
  lifecycle { ignore_changes = [uri, expiry_time] }
}

resource "azurerm_automation_webhook" "webhook_vm_startup" {
  automation_account_name = local.aa
  enabled                 = true
  expiry_time             = "2026-09-08T02:05:59+00:00"
  name                    = "webhook-vm-startup"
  parameters = {
    dryrunmode           = "true"
    excludedvmtags       = "{\"AlwaysOn\":\"true\",\"AutoShutdown\":\"Disabled\",\"DatabaseServer\":\"true\",\"Environment\":\"Gold\"}"
    requiredvmtags       = "{\"CostCenter\":\"*\"}"
    targetresourcegroups = "FSAM-CLEANCONFIG-RG"
    targetsubscriptions  = "4cda8977-68ea-4ca5-aa6a-fae45e7e98f3"
  }
  resource_group_name = local.rg
  run_on_worker_group = ""
  runbook_name        = azurerm_automation_runbook.vm_startup.name
  uri                 = "https://placeholder-not-used"
  lifecycle { ignore_changes = [uri, expiry_time] }
}
