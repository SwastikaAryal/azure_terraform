# =================================================================================================
# File: terraform/env/ccg/imports.tf
#
# EXACT IMPORT BLOCKS — Every resource ID was taken directly from the ARM-exported main.tf.
# The `to =` addresses match the flat resources declared in this repo's .tf files.
#
# USAGE:
#   terraform init
#   terraform plan   ← must show only "will be imported", NO destroy, NO create
#   terraform apply  ← pulls everything into state, zero infra change
#
# After a clean `terraform plan` shows NO CHANGES, these import blocks are
# safe to delete or comment out.
# =================================================================================================

# ── Resource Group ────────────────────────────────────────────────────────────
import {
  to = azurerm_resource_group.application_rg
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG"
}

# ── User Assigned Identities ─────────────────────────────────────────────────
import {
  to = azurerm_user_assigned_identity.storage_uai
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fsam-ccg-eus1-af-appdata-uamid-str"
}

import {
  to = azurerm_user_assigned_identity.central_uai
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fsamccg2-uai"
}

import {
  to = azurerm_user_assigned_identity.app01_uai
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fsamfs-ccg-app01winvm-ua-id"
}

import {
  to = azurerm_user_assigned_identity.app02_uai
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fsamfs-ccg-app02winvm-ua-id"
}

import {
  to = azurerm_user_assigned_identity.app1_uai
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fsamfs-ccg-app1winvm-ua-id"
}

import {
  to = azurerm_user_assigned_identity.app2_uai
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fsamfs-ccg-app2winvm-ua-id"
}

import {
  to = azurerm_user_assigned_identity.web01_uai
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fsamfs-ccg-web01winvm-ua-id"
}

import {
  to = azurerm_user_assigned_identity.web02_uai
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fsamfs-ccg-web02winvm-ua-id"
}

import {
  to = azurerm_user_assigned_identity.web1_uai
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fsamfs-ccg-web1winvm-ua-id"
}

import {
  to = azurerm_user_assigned_identity.web2_uai
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fsamfs-ccg-web2winvm-ua-id"
}

# ── Automation: Connection Types ──────────────────────────────────────────────
import {
  to = azurerm_automation_connection_type.conn_azure
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/connectionTypes/Azure"
}

import {
  to = azurerm_automation_connection_type.conn_classic
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/connectionTypes/AzureClassicCertificate"
}

import {
  to = azurerm_automation_connection_type.conn_sp
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/connectionTypes/AzureServicePrincipal"
}

# ── Automation: Schedules ─────────────────────────────────────────────────────
import {
  to = azurerm_automation_schedule.idle_detection
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/schedules/schedule-vm-idle-detection"
}

import {
  to = azurerm_automation_schedule.vm_shutdown
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/schedules/schedule-vm-shutdown"
}

import {
  to = azurerm_automation_schedule.vm_startup
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/schedules/schedule-vm-startup"
}

# ── Automation: Variables ─────────────────────────────────────────────────────
import {
  to = azurerm_automation_variable_string.business_days
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/BusinessDays"
}

import {
  to = azurerm_automation_variable_string.business_hours_end
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/BusinessHoursEnd"
}

import {
  to = azurerm_automation_variable_string.business_hours_start
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/BusinessHoursStart"
}

import {
  to = azurerm_automation_variable_bool.dry_run_mode
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/DryRunMode"
}

import {
  to = azurerm_automation_variable_bool.enable_vm_deallocate
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/EnableVMDeallocate"
}

import {
  to = azurerm_automation_variable_string.excluded_vm_tags
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/ExcludedVMTags"
}

import {
  to = azurerm_automation_variable_string.required_vm_tags
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/RequiredVMTags"
}

import {
  to = azurerm_automation_variable_string.target_resource_groups
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/TargetResourceGroups"
}

import {
  to = azurerm_automation_variable_string.target_subscriptions
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/TargetSubscriptions"
}

import {
  to = azurerm_automation_variable_string.timezone
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/Timezone"
}

import {
  to = azurerm_automation_variable_string.vm_cpu_threshold
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/VMCPUThreshold"
}

import {
  to = azurerm_automation_variable_string.vm_disk_threshold_mb
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/VMDiskThresholdMB"
}

import {
  to = azurerm_automation_variable_string.vm_grace_period_minutes
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/VMGracePeriodMinutes"
}

import {
  to = azurerm_automation_variable_string.vm_idle_threshold_hours
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/VMIdleThresholdHours"
}

import {
  to = azurerm_automation_variable_string.vm_network_threshold_mb
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/variables/VMNetworkThresholdMB"
}

# ── Automation: Runbooks ──────────────────────────────────────────────────────
import {
  to = azurerm_automation_runbook.idle_shutdown
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/runbooks/Invoke-VMIdleShutdown"
}

import {
  to = azurerm_automation_runbook.scheduled_shutdown
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/runbooks/Invoke-VMScheduledShutdown"
}

import {
  to = azurerm_automation_runbook.vm_startup
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/runbooks/Invoke-VMStartup"
}

import {
  to = azurerm_automation_runbook.sample_ps
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/runbooks/Sample-PowerShell-Runbook"
}

import {
  to = azurerm_automation_runbook.sample_py
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/runbooks/Sample-Python3-Runbook"
}

# ── Automation: Job Schedules ─────────────────────────────────────────────────
import {
  to = azurerm_automation_job_schedule.idle_detection
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/jobSchedules/2477edff-a75e-4f0c-840f-ca286d7a024b"
}

import {
  to = azurerm_automation_job_schedule.vm_startup_job
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/jobSchedules/3cf6c93f-13cc-4223-b303-8823f238dc72"
}

import {
  to = azurerm_automation_job_schedule.scheduled_shutdown_job
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/jobSchedules/5522304f-39b0-4a02-9883-76533db4bca9"
}

# ── Automation: Webhooks ──────────────────────────────────────────────────────
import {
  to = azurerm_automation_webhook.sample_webhook
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/webHooks/SampleWebhookcleanconfig"
}

import {
  to = azurerm_automation_webhook.webhook_idle_shutdown
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/webHooks/webhook-vm-idle-shutdown"
}

import {
  to = azurerm_automation_webhook.webhook_scheduled_shutdown
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/webHooks/webhook-vm-scheduled-shutdown"
}

import {
  to = azurerm_automation_webhook.webhook_vm_startup
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/webHooks/webhook-vm-startup"
}

# ── Proximity Placement Group ─────────────────────────────────────────────────
import {
  to = azurerm_proximity_placement_group.ccg_ppg
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/proximityPlacementGroups/fsamccg-ppg"
}

# ── Virtual Machines ──────────────────────────────────────────────────────────
import {
  to = azurerm_windows_virtual_machine.app1
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1"
}

import {
  to = azurerm_windows_virtual_machine.app2
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app2"
}

import {
  to = azurerm_windows_virtual_machine.web1
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1"
}

import {
  to = azurerm_windows_virtual_machine.web2
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2"
}

# ── Data Disk Attachments ─────────────────────────────────────────────────────
import {
  to = azurerm_virtual_machine_data_disk_attachment.app1_disk
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1/dataDisks/fsamdatadiskfs-ccg-app1winvm"
}

import {
  to = azurerm_virtual_machine_data_disk_attachment.app2_disk
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app2/dataDisks/fsamdatadiskfs-ccg-app2winvm"
}

import {
  to = azurerm_virtual_machine_data_disk_attachment.web1_disk
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1/dataDisks/fsamdatadiskfs-ccg-web1winvm"
}

import {
  to = azurerm_virtual_machine_data_disk_attachment.web2_disk
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2/dataDisks/fsamdatadiskfs-ccg-web2winvm"
}

# ── VM Extensions ─────────────────────────────────────────────────────────────
# app1
import {
  to = azurerm_virtual_machine_extension.app1_aad
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1/extensions/AADLogin"
}
import {
  to = azurerm_virtual_machine_extension.app1_policy
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1/extensions/AzurePolicyforWindows"
}
import {
  to = azurerm_virtual_machine_extension.app1_mde
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1/extensions/MDE.Windows"
}
import {
  to = azurerm_virtual_machine_extension.app1_vmaccess
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1/extensions/enablevmAccess"
}

# app2
import {
  to = azurerm_virtual_machine_extension.app2_aad
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app2/extensions/AADLogin"
}
import {
  to = azurerm_virtual_machine_extension.app2_policy
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app2/extensions/AzurePolicyforWindows"
}
import {
  to = azurerm_virtual_machine_extension.app2_mde
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app2/extensions/MDE.Windows"
}

# web1
import {
  to = azurerm_virtual_machine_extension.web1_aad
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1/extensions/AADLogin"
}
import {
  to = azurerm_virtual_machine_extension.web1_policy
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1/extensions/AzurePolicyforWindows"
}
import {
  to = azurerm_virtual_machine_extension.web1_iis
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1/extensions/IIS"
}
import {
  to = azurerm_virtual_machine_extension.web1_mde
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1/extensions/MDE.Windows"
}

# web2
import {
  to = azurerm_virtual_machine_extension.web2_aad
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2/extensions/AADLogin"
}
import {
  to = azurerm_virtual_machine_extension.web2_policy
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2/extensions/AzurePolicyforWindows"
}
import {
  to = azurerm_virtual_machine_extension.web2_iis
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2/extensions/IIS"
}
import {
  to = azurerm_virtual_machine_extension.web2_mde
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2/extensions/MDE.Windows"
}

# ── Monitor Action Groups ─────────────────────────────────────────────────────
import {
  to = azurerm_monitor_action_group.ag_vm_automation
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Insights/actionGroups/ag-vm-automation"
}

import {
  to = azurerm_monitor_action_group.ag_critical
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Insights/actionGroups/fsamccg2-critical-ag"
}

import {
  to = azurerm_monitor_action_group.ag_warning
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Insights/actionGroups/fsamccg2-warning-ag"
}

# ── Application Insights ──────────────────────────────────────────────────────
import {
  to = azurerm_application_insights.app_insights
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Insights/components/fsam-ccg-2-aapin"
}

# ── Load Balancer ─────────────────────────────────────────────────────────────
import {
  to = azurerm_lb.app_lb
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app"
}

import {
  to = azurerm_lb_backend_address_pool.vm_pool
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/backendAddressPools/bepool-fsamccg2-vm"
}

import {
  to = azurerm_lb_probe.http_probe
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/probes/probe-http-fsamccg2"
}

import {
  to = azurerm_lb_probe.https_probe
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/probes/probe-https-fsamccg2"
}

import {
  to = azurerm_lb_rule.http_rule
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/loadBalancingRules/lbrul-http-fsamccg2"
}

import {
  to = azurerm_lb_rule.https_rule
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/loadBalancingRules/lbrul-https-fsamccg2"
}

# ── Network Interfaces ────────────────────────────────────────────────────────
import {
  to = azurerm_network_interface.nic_app1
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkInterfaces/nic-fsamfs-ccg-app1winvm"
}

import {
  to = azurerm_network_interface.nic_app2
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkInterfaces/nic-fsamfs-ccg-app2winvm"
}

import {
  to = azurerm_network_interface.nic_web1
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkInterfaces/nic-fsamfs-ccg-web1winvm"
}

import {
  to = azurerm_network_interface.nic_web2
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkInterfaces/nic-fsamfs-ccg-web2winvm"
}

# ── NIC → LB Backend Associations ────────────────────────────────────────────
import {
  to = azurerm_network_interface_backend_address_pool_association.web1_lb
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkInterfaces/nic-fsamfs-ccg-web1winvm|/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/backendAddressPools/bepool-fsamccg2-vm"
}

import {
  to = azurerm_network_interface_backend_address_pool_association.web2_lb
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkInterfaces/nic-fsamfs-ccg-web2winvm|/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/backendAddressPools/bepool-fsamccg2-vm"
}

# ── Network Security Groups ───────────────────────────────────────────────────
import {
  to = azurerm_network_security_group.nsg_app1
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkSecurityGroups/nsg-fsamfs-ccg-app1winvm"
}

import {
  to = azurerm_network_security_group.nsg_app2
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkSecurityGroups/nsg-fsamfs-ccg-app2winvm"
}

import {
  to = azurerm_network_security_group.nsg_web1
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkSecurityGroups/nsg-fsamfs-ccg-web1winvm"
}

import {
  to = azurerm_network_security_group.nsg_web2
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkSecurityGroups/nsg-fsamfs-ccg-web2winvm"
}

# ── NSG Security Rules (MDC JIT) ──────────────────────────────────────────────
import {
  to = azurerm_network_security_rule.jit_app1
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkSecurityGroups/nsg-fsamfs-ccg-app1winvm/securityRules/MicrosoftDefenderForCloud-JITRule_207548529_B58C6824DBF54E2D8B03C68427F9EB56"
}

import {
  to = azurerm_network_security_rule.jit_app2
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkSecurityGroups/nsg-fsamfs-ccg-app2winvm/securityRules/MicrosoftDefenderForCloud-JITRule_1423489397_22C91A6C3E3040479170E5BF902BEB81"
}

import {
  to = azurerm_network_security_rule.jit_web1
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkSecurityGroups/nsg-fsamfs-ccg-web1winvm/securityRules/MicrosoftDefenderForCloud-JITRule_691436021_A31967F990F94450BD7FCCB0A05EEB80"
}

# ── Private Endpoints ─────────────────────────────────────────────────────────
import {
  to = azurerm_private_endpoint.aa_pe_webhook
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/privateEndpoints/fsamccg2-aa-auto-pe-agentsvc-Webhook"
}

import {
  to = azurerm_private_endpoint.storage_pe_file
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/privateEndpoints/fsamccgstprivatebmw-pe-file"
}

# ── Log Analytics Workspace ───────────────────────────────────────────────────
import {
  to = azurerm_log_analytics_workspace.law
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.OperationalInsights/workspaces/fsamccg-law"
}

import {
  to = azurerm_log_analytics_linked_service.aa_link
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.OperationalInsights/workspaces/fsamccg-law/linkedServices/Automation"
}

import {
  to = azurerm_log_analytics_solution.vm_insights
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.OperationsManagement/solutions/VMInsights(fsamccg-law)"
}

# ── Recovery Services Vault ───────────────────────────────────────────────────
import {
  to = azurerm_recovery_services_vault.rsv
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.RecoveryServices/vaults/fsam-cleanconfig-rsv"
}

import {
  to = azurerm_backup_policy_file_share.daily_policy
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.RecoveryServices/vaults/fsam-cleanconfig-rsv/backupPolicies/DailyPolicy-fsamcleanconfig"
}

import {
  to = azurerm_backup_policy_vm.default_policy
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.RecoveryServices/vaults/fsam-cleanconfig-rsv/backupPolicies/DefaultPolicy"
}

import {
  to = azurerm_backup_policy_vm.enhanced_policy
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.RecoveryServices/vaults/fsam-cleanconfig-rsv/backupPolicies/EnhancedPolicy"
}

import {
  to = azurerm_backup_policy_vm_workload.hourly_log
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.RecoveryServices/vaults/fsam-cleanconfig-rsv/backupPolicies/HourlyLogBackup"
}

import {
  to = azurerm_backup_policy_vm.rsv_vm_policy
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.RecoveryServices/vaults/fsam-cleanconfig-rsv/backupPolicies/fsam-cleanconfig-rsv-vm"
}

# ── Storage Account ───────────────────────────────────────────────────────────
import {
  to = azurerm_storage_account.ccg_sa
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Storage/storageAccounts/fsamccgstprivatebmw"
}

import {
  to = azurerm_storage_share.cleanconfig_share
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Storage/storageAccounts/fsamccgstprivatebmw/fileServices/default/shares/sfam-cleanconfig"
}

# ── EventGrid ─────────────────────────────────────────────────────────────────
import {
  to = azurerm_eventgrid_system_topic.storage_antimalware
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.EventGrid/systemTopics/fsamccgstprivatebmw-3bfa7d33-7fdb-46c1-a700-e3ce734aba0e"
}

import {
  to = azurerm_eventgrid_system_topic_event_subscription.storage_antimalware
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.EventGrid/systemTopics/fsamccgstprivatebmw-3bfa7d33-7fdb-46c1-a700-e3ce734aba0e/eventSubscriptions/StorageAntimalwareSubscription"
}
