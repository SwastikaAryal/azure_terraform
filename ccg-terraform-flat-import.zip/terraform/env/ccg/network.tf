# =============================================================================
# PROXIMITY PLACEMENT GROUP
# =============================================================================
resource "azurerm_proximity_placement_group" "ccg_ppg" {
  location            = local.region
  name                = "fsamccg-ppg"
  resource_group_name = local.rg
  tags                = {}
  lifecycle { ignore_changes = [tags, allowed_vm_sizes, zone] }
}

# =============================================================================
# LOAD BALANCER
# =============================================================================
resource "azurerm_lb" "app_lb" {
  location            = local.region
  name                = "fsamccg2-lb-app"
  resource_group_name = local.rg
  sku                 = "Standard"
  sku_tier            = "Regional"
  tags                = local.common_tags

  frontend_ip_configuration {
    name                          = "feip-fsamccg2-app"
    private_ip_address_allocation = "Dynamic"
    private_ip_address_version    = "IPv4"
    subnet_id                     = local.subnet_id
  }
  lifecycle { ignore_changes = [tags] }
}

resource "azurerm_lb_backend_address_pool" "vm_pool" {
  loadbalancer_id = azurerm_lb.app_lb.id
  name            = "bepool-fsamccg2-vm"
}

resource "azurerm_lb_probe" "http_probe" {
  interval_in_seconds = 15
  loadbalancer_id     = azurerm_lb.app_lb.id
  name                = "probe-http-fsamccg2"
  number_of_probes    = 2
  port                = 80
  probe_threshold     = 1
  protocol            = "Http"
  request_path        = "/"
}

resource "azurerm_lb_probe" "https_probe" {
  interval_in_seconds = 15
  loadbalancer_id     = azurerm_lb.app_lb.id
  name                = "probe-https-fsamccg2"
  number_of_probes    = 2
  port                = 443
  probe_threshold     = 1
  protocol            = "Https"
  request_path        = "/"
}

resource "azurerm_lb_rule" "http_rule" {
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.vm_pool.id]
  backend_port                   = 80
  disable_outbound_snat          = false
  enable_floating_ip             = false
  enable_tcp_reset               = false
  frontend_ip_configuration_name = "feip-fsamccg2-app"
  frontend_port                  = 80
  idle_timeout_in_minutes        = 4
  load_distribution              = "Default"
  loadbalancer_id                = azurerm_lb.app_lb.id
  name                           = "lbrul-http-fsamccg2"
  probe_id                       = azurerm_lb_probe.http_probe.id
  protocol                       = "Tcp"
}

resource "azurerm_lb_rule" "https_rule" {
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.vm_pool.id]
  backend_port                   = 443
  disable_outbound_snat          = false
  enable_floating_ip             = false
  enable_tcp_reset               = false
  frontend_ip_configuration_name = "feip-fsamccg2-app"
  frontend_port                  = 443
  idle_timeout_in_minutes        = 4
  load_distribution              = "Default"
  loadbalancer_id                = azurerm_lb.app_lb.id
  name                           = "lbrul-https-fsamccg2"
  probe_id                       = azurerm_lb_probe.https_probe.id
  protocol                       = "Tcp"
}

# =============================================================================
# NETWORK INTERFACES
# =============================================================================
resource "azurerm_network_interface" "nic_app1" {
  accelerated_networking_enabled = true
  location                       = local.region
  name                           = "nic-fsamfs-ccg-app1winvm"
  resource_group_name            = local.rg
  tags                           = local.vm_tags

  ip_configuration {
    name                          = "internal-ipconfig-fsamfs-ccg-app1winvm"
    primary                       = true
    private_ip_address_allocation = "Dynamic"
    private_ip_address_version    = "IPv4"
    subnet_id                     = local.subnet_id
  }
  lifecycle { ignore_changes = [tags, ip_configuration[0].private_ip_address] }
}

resource "azurerm_network_interface" "nic_app2" {
  accelerated_networking_enabled = true
  location                       = local.region
  name                           = "nic-fsamfs-ccg-app2winvm"
  resource_group_name            = local.rg
  tags                           = local.vm_tags

  ip_configuration {
    name                          = "internal-ipconfig-fsamfs-ccg-app2winvm"
    primary                       = true
    private_ip_address_allocation = "Dynamic"
    private_ip_address_version    = "IPv4"
    subnet_id                     = local.subnet_id
  }
  lifecycle { ignore_changes = [tags, ip_configuration[0].private_ip_address] }
}

resource "azurerm_network_interface" "nic_web1" {
  accelerated_networking_enabled = true
  location                       = local.region
  name                           = "nic-fsamfs-ccg-web1winvm"
  resource_group_name            = local.rg
  tags                           = local.vm_tags

  ip_configuration {
    name                          = "internal-ipconfig-fsamfs-ccg-web1winvm"
    primary                       = true
    private_ip_address_allocation = "Dynamic"
    private_ip_address_version    = "IPv4"
    subnet_id                     = local.subnet_id
  }
  lifecycle { ignore_changes = [tags, ip_configuration[0].private_ip_address] }
}

resource "azurerm_network_interface" "nic_web2" {
  accelerated_networking_enabled = true
  location                       = local.region
  name                           = "nic-fsamfs-ccg-web2winvm"
  resource_group_name            = local.rg
  tags                           = local.vm_tags

  ip_configuration {
    name                          = "internal-ipconfig-fsamfs-ccg-web2winvm"
    primary                       = true
    private_ip_address_allocation = "Dynamic"
    private_ip_address_version    = "IPv4"
    subnet_id                     = local.subnet_id
  }
  lifecycle { ignore_changes = [tags, ip_configuration[0].private_ip_address] }
}

# NIC → LB Backend Pool associations (web VMs only — app VMs are NOT in LB pool)
resource "azurerm_network_interface_backend_address_pool_association" "web1_lb" {
  backend_address_pool_id = azurerm_lb_backend_address_pool.vm_pool.id
  ip_configuration_name   = "internal-ipconfig-fsamfs-ccg-web1winvm"
  network_interface_id    = azurerm_network_interface.nic_web1.id
}

resource "azurerm_network_interface_backend_address_pool_association" "web2_lb" {
  backend_address_pool_id = azurerm_lb_backend_address_pool.vm_pool.id
  ip_configuration_name   = "internal-ipconfig-fsamfs-ccg-web2winvm"
  network_interface_id    = azurerm_network_interface.nic_web2.id
}

# =============================================================================
# NETWORK SECURITY GROUPS
# =============================================================================
# NOTE: The MDC JIT rules are managed by Microsoft Defender for Cloud.
# We declare the NSGs without the JIT rules and use ignore_changes on security_rule
# so that Defender can freely modify them without causing plan diffs.

resource "azurerm_network_security_group" "nsg_app1" {
  location            = local.region
  name                = "nsg-fsamfs-ccg-app1winvm"
  resource_group_name = local.rg
  tags                = local.vm_tags
  lifecycle {
    ignore_changes = [security_rule, tags]
  }
}

resource "azurerm_network_security_group" "nsg_app2" {
  location            = local.region
  name                = "nsg-fsamfs-ccg-app2winvm"
  resource_group_name = local.rg
  tags                = local.vm_tags
  lifecycle {
    ignore_changes = [security_rule, tags]
  }
}

resource "azurerm_network_security_group" "nsg_web1" {
  location            = local.region
  name                = "nsg-fsamfs-ccg-web1winvm"
  resource_group_name = local.rg
  tags                = local.vm_tags
  lifecycle {
    ignore_changes = [security_rule, tags]
  }
}

resource "azurerm_network_security_group" "nsg_web2" {
  location            = local.region
  name                = "nsg-fsamfs-ccg-web2winvm"
  resource_group_name = local.rg
  tags                = local.vm_tags
  lifecycle {
    ignore_changes = [security_rule, tags]
  }
}

# NSG Security Rules (MDC JIT) — declared so they can be imported into state.
# lifecycle ignore_changes = all prevents Terraform from touching them afterwards.
resource "azurerm_network_security_rule" "jit_app1" {
  access                      = "Deny"
  description                 = "MDC JIT Network Access rule for policy 'default' of VM 'fs-ccg-app1'."
  destination_address_prefix  = "10.66.10.10"
  destination_port_range      = "3389"
  direction                   = "Inbound"
  name                        = "MicrosoftDefenderForCloud-JITRule_207548529_B58C6824DBF54E2D8B03C68427F9EB56"
  network_security_group_name = azurerm_network_security_group.nsg_app1.name
  priority                    = 4096
  protocol                    = "*"
  resource_group_name         = local.rg
  source_address_prefix       = "*"
  source_port_range           = "*"
  lifecycle { ignore_changes = all }
}

resource "azurerm_network_security_rule" "jit_app2" {
  access                      = "Deny"
  description                 = "MDC JIT Network Access rule for policy 'default' of VM 'fs-ccg-app2'."
  destination_address_prefix  = "10.66.10.8"
  destination_port_range      = "3389"
  direction                   = "Inbound"
  name                        = "MicrosoftDefenderForCloud-JITRule_1423489397_22C91A6C3E3040479170E5BF902BEB81"
  network_security_group_name = azurerm_network_security_group.nsg_app2.name
  priority                    = 4096
  protocol                    = "*"
  resource_group_name         = local.rg
  source_address_prefix       = "*"
  source_port_range           = "*"
  lifecycle { ignore_changes = all }
}

resource "azurerm_network_security_rule" "jit_web1" {
  access                      = "Deny"
  description                 = "MDC JIT Network Access rule for policy 'default' of VM 'fs-ccg-web1'."
  destination_address_prefix  = "10.66.10.9"
  destination_port_range      = "3389"
  direction                   = "Inbound"
  name                        = "MicrosoftDefenderForCloud-JITRule_691436021_A31967F990F94450BD7FCCB0A05EEB80"
  network_security_group_name = azurerm_network_security_group.nsg_web1.name
  priority                    = 4096
  protocol                    = "*"
  resource_group_name         = local.rg
  source_address_prefix       = "*"
  source_port_range           = "*"
  lifecycle { ignore_changes = all }
}

# web2 NSG has no JIT rule in current ARM export — no security rule resource needed.

# =============================================================================
# PRIVATE ENDPOINTS
# =============================================================================
resource "azurerm_private_endpoint" "aa_pe_webhook" {
  custom_network_interface_name = "nic-fsamccg2-pe-auto-agentsvc-Webhook"
  location                      = local.region
  name                          = "fsamccg2-aa-auto-pe-agentsvc-Webhook"
  resource_group_name           = local.rg
  subnet_id                     = local.subnet_id
  tags                          = local.common_tags

  private_service_connection {
    is_manual_connection           = false
    name                           = "psc-fsamccg2-aa-auto-pe-agentsvc-Webhook"
    private_connection_resource_id = "/subscriptions/${local.sub_id}/resourceGroups/${local.rg}/providers/Microsoft.Automation/automationAccounts/${local.aa}"
    subresource_names              = ["Webhook"]
  }
  lifecycle { ignore_changes = [tags, private_dns_zone_group] }
}

resource "azurerm_private_endpoint" "storage_pe_file" {
  custom_network_interface_name = "fsamccgstprivatebmw-pe-file-nic"
  location                      = local.region
  name                          = "fsamccgstprivatebmw-pe-file"
  resource_group_name           = local.rg
  subnet_id                     = local.subnet_id
  tags                          = {}

  private_service_connection {
    is_manual_connection           = false
    name                           = "fsamccgstprivatebmw-pe-file"
    private_connection_resource_id = azurerm_storage_account.ccg_sa.id
    subresource_names              = ["file"]
  }
  lifecycle { ignore_changes = [tags, private_dns_zone_group] }
}
