# =============================================================================
# LOG ANALYTICS WORKSPACE
# =============================================================================
resource "azurerm_log_analytics_workspace" "law" {
  allow_resource_only_permissions         = true
  daily_quota_gb                          = -1
  immediate_data_purge_on_30_days_enabled = false
  internet_ingestion_enabled              = true
  internet_query_enabled                  = true
  local_authentication_disabled           = false
  location                                = local.region
  name                                    = "fsamccg-law"
  resource_group_name                     = local.rg
  retention_in_days                       = 90
  sku                                     = "PerGB2018"
  tags = {
    "APPD-ID"           = "APPD-326047"
    "App Name"          = "AF"
    "Cost Center"       = "1845"
    DeploymentTimestamp = "2025-09-11T15:01:33Z"
    Environment         = "CCG"
    "Product-ID"        = "SWP-000"
    Repository          = "atc-github.azure.cloud.bmw/cgbp/terraform-azure-bmw-log-analytics-workspace"
    TerraformWorkspace  = "default"
    customer_prefix     = "fsam"
    env                 = "ccg"
    environment         = "ccg"
  }
  lifecycle { ignore_changes = [tags] }
}

resource "azurerm_log_analytics_linked_service" "aa_link" {
  read_access_id      = "/subscriptions/${local.sub_id}/resourceGroups/${local.rg}/providers/Microsoft.Automation/automationAccounts/${local.aa}"
  resource_group_name = local.rg
  workspace_id        = azurerm_log_analytics_workspace.law.id
  lifecycle { ignore_changes = all }
}

resource "azurerm_log_analytics_solution" "vm_insights" {
  location              = local.region
  resource_group_name   = local.rg
  solution_name         = "VMInsights"
  workspace_name        = azurerm_log_analytics_workspace.law.name
  workspace_resource_id = azurerm_log_analytics_workspace.law.id
  tags = {
    Environment = "CleanConfig"
    ManagedBy   = "Terraform"
    Purpose     = "VMCostOptimization"
    Team        = "FSCloudTeam"
  }
  plan {
    product        = "OMSGallery/VMInsights"
    promotion_code = ""
    publisher      = "Microsoft"
  }
  lifecycle { ignore_changes = [tags] }
}

# =============================================================================
# APPLICATION INSIGHTS
# =============================================================================
resource "azurerm_application_insights" "app_insights" {
  application_type                      = "web"
  daily_data_cap_in_gb                  = 100
  daily_data_cap_notifications_disabled = false
  disable_ip_masking                    = false
  force_customer_storage_for_profiler   = false
  internet_ingestion_enabled            = true
  internet_query_enabled                = true
  local_authentication_disabled         = false
  location                              = local.region
  name                                  = "fsam-ccg-2-aapin"
  resource_group_name                   = local.rg
  retention_in_days                     = 90
  sampling_percentage                   = 100
  tags                                  = local.common_tags
  workspace_id                          = azurerm_log_analytics_workspace.law.id
  lifecycle { ignore_changes = [tags] }
}

# =============================================================================
# MONITOR ACTION GROUPS
# =============================================================================
resource "azurerm_monitor_action_group" "ag_vm_automation" {
  enabled             = true
  location            = "global"
  name                = "ag-vm-automation"
  resource_group_name = local.rg
  short_name          = "vmauto"
  tags = {
    Component   = "Notifications"
    Environment = "CleanConfig"
    ManagedBy   = "Terraform"
    Purpose     = "VMAutomation"
    Team        = "FSCloudTeam"
  }
  email_receiver {
    email_address           = "Miguel.MA.Araujo@partner.bmwgroup.com"
    name                    = "email-Miguel.MA.Araujo-at-partner.bmwgroup.com"
    use_common_alert_schema = false
  }
  email_receiver {
    email_address           = "Shaikh.Islam@partner.bmwfs.com"
    name                    = "email-Shaikh.Islam-at-partner.bmwfs.com"
    use_common_alert_schema = false
  }
  lifecycle { ignore_changes = [tags] }
}

resource "azurerm_monitor_action_group" "ag_critical" {
  enabled             = true
  location            = "global"
  name                = "fsamccg2-critical-ag"
  resource_group_name = local.rg
  short_name          = "crit-dev"
  tags                = local.common_tags
  email_receiver {
    email_address           = "Shravan.Chiduruppa@bmwfs.com"
    name                    = "critical-alerts-email-dev"
    use_common_alert_schema = true
  }
  lifecycle { ignore_changes = [tags] }
}

resource "azurerm_monitor_action_group" "ag_warning" {
  enabled             = true
  location            = "global"
  name                = "fsamccg2-warning-ag"
  resource_group_name = local.rg
  short_name          = "warn-dev"
  tags                = local.common_tags
  email_receiver {
    email_address           = "Shravan.Chiduruppa@bmwfs.com"
    name                    = "warning-alerts-email-dev"
    use_common_alert_schema = true
  }
  lifecycle { ignore_changes = [tags] }
}

# =============================================================================
# STORAGE ACCOUNT
# =============================================================================
resource "azurerm_storage_account" "ccg_sa" {
  access_tier                       = "Hot"
  account_kind                      = "StorageV2"
  account_replication_type          = "ZRS"
  account_tier                      = "Standard"
  allow_nested_items_to_be_public   = false
  cross_tenant_replication_enabled  = true
  default_to_oauth_authentication   = true
  https_traffic_only_enabled        = true
  infrastructure_encryption_enabled = true
  is_hns_enabled                    = false
  location                          = local.region
  min_tls_version                   = "TLS1_2"
  name                              = "fsamccgstprivatebmw"
  public_network_access_enabled     = true
  resource_group_name               = local.rg
  shared_access_key_enabled         = true
  tags = {
    "APPD-ID"           = "APPD-326047"
    "App Name"          = "AF"
    "Cost Center"       = "1845"
    DeploymentTimestamp = "2025-09-11T15:01:33Z"
    Environment         = "CCG"
    "Product-ID"        = "SWP-000"
    Repository          = "atc-github.azure.cloud.bmw/cgbp/terraform-azure-bmw-storage"
    TerraformWorkspace  = "default"
    customer_prefix     = "fsam"
    env                 = "ccg"
    environment         = "ccg"
  }

  azure_files_authentication {
    default_share_level_permission = "StorageFileDataSmbShareElevatedContributor"
    directory_type                 = "AADKERB"
  }
  blob_properties {
    change_feed_enabled      = false
    last_access_time_enabled = false
    versioning_enabled       = false
    container_delete_retention_policy { days = 14 }
    delete_retention_policy {
      days                     = 14
      permanent_delete_enabled = false
    }
  }
  identity {
    identity_ids = [azurerm_user_assigned_identity.storage_uai.id]
    type         = "UserAssigned"
  }
  network_rules {
    bypass                     = ["AzureServices"]
    default_action             = "Deny"
    ip_rules                   = ["20.237.42.239"]
    virtual_network_subnet_ids = [local.subnet_id]
    private_link_access {
      endpoint_resource_id = "/subscriptions/${local.sub_id}/providers/Microsoft.Security/datascanners/StorageDataScanner"
      endpoint_tenant_id   = "ce849bab-cc1c-465b-b62e-18f07c9ac198"
    }
  }
  routing {
    choice                      = "MicrosoftRouting"
    publish_internet_endpoints  = false
    publish_microsoft_endpoints = false
  }
  sas_policy {
    expiration_action = "Log"
    expiration_period = "90.00:00:00"
  }
  share_properties {
    retention_policy { days = 14 }
  }
  lifecycle { ignore_changes = [tags, primary_access_key, secondary_access_key] }
}

resource "azurerm_storage_share" "cleanconfig_share" {
  access_tier      = "TransactionOptimized"
  enabled_protocol = "SMB"
  metadata = {
    AzureBackupProtected = "true"
  }
  name               = "sfam-cleanconfig"
  quota              = 102400
  storage_account_id = azurerm_storage_account.ccg_sa.id
  lifecycle { ignore_changes = [metadata] }
}

# =============================================================================
# RECOVERY SERVICES VAULT + BACKUP POLICIES
# =============================================================================
resource "azurerm_recovery_services_vault" "rsv" {
  classic_vmware_replication_enabled = false
  cross_region_restore_enabled       = true
  immutability                       = "Disabled"
  location                           = local.region
  name                               = "fsam-cleanconfig-rsv"
  public_network_access_enabled      = true
  resource_group_name                = local.rg
  sku                                = "RS0"
  soft_delete_enabled                = true
  storage_mode_type                  = "GeoRedundant"
  tags                               = {}
  lifecycle {
    prevent_destroy = true
    ignore_changes  = [tags]
  }
}

resource "azurerm_backup_policy_file_share" "daily_policy" {
  backup_tier                = "snapshot"
  name                       = "DailyPolicy-fsamcleanconfig"
  recovery_vault_name        = azurerm_recovery_services_vault.rsv.name
  resource_group_name        = local.rg
  snapshot_retention_in_days = 0
  timezone                   = "UTC"
  backup {
    frequency = "Daily"
    time      = "19:30"
  }
  retention_daily { count = 30 }
}

resource "azurerm_backup_policy_vm" "default_policy" {
  instant_restore_retention_days = 2
  name                           = "DefaultPolicy"
  policy_type                    = "V1"
  recovery_vault_name            = azurerm_recovery_services_vault.rsv.name
  resource_group_name            = local.rg
  timezone                       = "UTC"
  backup {
    frequency = "Daily"
    time      = "01:30"
  }
  retention_daily { count = 30 }
}

resource "azurerm_backup_policy_vm" "enhanced_policy" {
  instant_restore_retention_days = 2
  name                           = "EnhancedPolicy"
  policy_type                    = "V2"
  recovery_vault_name            = azurerm_recovery_services_vault.rsv.name
  resource_group_name            = local.rg
  timezone                       = "UTC"
  backup {
    frequency     = "Hourly"
    hour_duration = 12
    hour_interval = 4
    time          = "08:00"
  }
  retention_daily { count = 30 }
}

resource "azurerm_backup_policy_vm_workload" "hourly_log" {
  name                = "HourlyLogBackup"
  recovery_vault_name = azurerm_recovery_services_vault.rsv.name
  resource_group_name = local.rg
  workload_type       = "SQLDataBase"
  protection_policy {
    policy_type = "Log"
    backup {
      frequency_in_minutes = 60
    }
    simple_retention { count = 30 }
  }
  protection_policy {
    policy_type = "Full"
    backup {
      frequency = "Daily"
      time      = "01:30"
    }
    retention_daily { count = 30 }
  }
  settings {
    compression_enabled = false
    time_zone           = "UTC"
  }
}

resource "azurerm_backup_policy_vm" "rsv_vm_policy" {
  instant_restore_retention_days = 7
  name                           = "fsam-cleanconfig-rsv-vm"
  policy_type                    = "V2"
  recovery_vault_name            = azurerm_recovery_services_vault.rsv.name
  resource_group_name            = local.rg
  timezone                       = "UTC"
  backup {
    frequency = "Daily"
    time      = "23:00"
  }
  retention_daily { count = 30 }
}

# =============================================================================
# EVENTGRID (Storage Antimalware — created by Defender for Storage)
# =============================================================================
resource "azurerm_eventgrid_system_topic" "storage_antimalware" {
  location               = local.region
  name                   = "fsamccgstprivatebmw-3bfa7d33-7fdb-46c1-a700-e3ce734aba0e"
  resource_group_name    = local.rg
  source_arm_resource_id = azurerm_storage_account.ccg_sa.id
  topic_type             = "microsoft.storage.storageaccounts"
  tags                   = {}
  lifecycle { ignore_changes = [tags, name, source_arm_resource_id] }
}

resource "azurerm_eventgrid_system_topic_event_subscription" "storage_antimalware" {
  name                                 = "StorageAntimalwareSubscription"
  system_topic                         = azurerm_eventgrid_system_topic.storage_antimalware.name
  resource_group_name                  = local.rg
  event_delivery_schema                = "EventGridSchema"
  included_event_types                 = ["Microsoft.Storage.BlobCreated", "Microsoft.Storage.BlobRenamed"]
  advanced_filtering_on_arrays_enabled = false

  advanced_filter {
    string_contains {
      key    = "data.blobType"
      values = ["BlockBlob"]
    }
  }
  retry_policy {
    event_time_to_live    = 1440
    max_delivery_attempts = 30
  }
  lifecycle { ignore_changes = all }
}
