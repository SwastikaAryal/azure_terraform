# =================================================================================================
# File: terraform/env/ccg/main.tf
#
# PURPOSE: This file is a FLAT (no-module) Terraform configuration that exactly mirrors the
#          current state of FSAM-CLEANCONFIG-RG as exported from the Azure portal (ARM template).
#
#          It is used together with imports.tf to:
#            1. Import all existing resources into Terraform state (terraform apply)
#            2. Produce ZERO infrastructure changes on subsequent terraform plan/apply runs
#
#          Subscription : 4cda8977-68ea-4ca5-aa6a-fae45e7e98f3
#          Resource Group: FSAM-CLEANCONFIG-RG
#          Region        : eastus
#
# APPROACH: Flat resources — no module wrappers — so every `to =` address in imports.tf
#           resolves unambiguously without needing to know module internals.
#
# LIFECYCLE GUARDS: Sensitive / auto-managed attributes use ignore_changes so that
#                   terraform plan shows NO CHANGES after import.
# =================================================================================================

terraform {
  required_version = ">= 1.5.0"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.27.0"
    }
  }

  backend "azurerm" {
    resource_group_name  = "FSAM-DEV-BACKEND-RG"
    storage_account_name = "fsamdevbeprivatebmw"
    container_name       = "tfstate"
    key                  = "terraform-ccg.tfstate"
  }
}

provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy               = true
      recover_soft_deleted_key_vaults            = true
      purge_soft_deleted_keys_on_destroy         = true
      purge_soft_deleted_secrets_on_destroy      = true
      purge_soft_deleted_certificates_on_destroy = true
    }
    resource_group {
      prevent_deletion_if_contains_resources = true
    }
  }
  subscription_id = "4cda8977-68ea-4ca5-aa6a-fae45e7e98f3"
  tenant_id       = "ce849bab-cc1c-465b-b62e-18f07c9ac198"
  use_oidc        = true
}

# =============================================================================
# LOCALS
# =============================================================================
locals {
  sub_id = "4cda8977-68ea-4ca5-aa6a-fae45e7e98f3"
  rg     = "FSAM-CLEANCONFIG-RG"
  region = "eastus"
  aa     = "fsamccg2-aa-auto"

  common_tags = {
    DeploymentTimestamp = "2025-09-11T15:01:33Z"
    TerraformWorkspace  = "default"
    customer_prefix     = "fsam"
    env                 = "ccg"
    environment         = "ccg"
  }

  vm_tags = {
    "APPD-ID"           = "APPD-326047"
    "App Name"          = "AF"
    "Cost Center"       = "1845"
    DeploymentTimestamp = "2025-09-08T02:00:19Z"
    Environment         = "ccg"
    "Product-ID"        = "SWP-000"
    Repository          = "atc-github.azure.cloud.bmw/cgbp/terraform-azure-bmw-vm"
    TerraformWorkspace  = "default"
    customer_prefix     = "fsam"
    env                 = "ccg"
  }

  subnet_id = "/subscriptions/${local.sub_id}/resourceGroups/RG-VNET-SPOKE-EUS-12815/providers/Microsoft.Network/virtualNetworks/VNET-SPOKE-EUS-12815/subnets/Subnet-1"
}

# =============================================================================
# RESOURCE GROUP
# =============================================================================
resource "azurerm_resource_group" "application_rg" {
  location = local.region
  name     = local.rg
  tags     = local.common_tags

  lifecycle { ignore_changes = [tags] }
}

# =============================================================================
# USER ASSIGNED IDENTITIES  (10 total)
# =============================================================================
resource "azurerm_user_assigned_identity" "storage_uai" {
  location            = local.region
  name                = "fsam-ccg-eus1-af-appdata-uamid-str"
  resource_group_name = local.rg
  tags                = {}
  lifecycle { ignore_changes = [tags] }
}

resource "azurerm_user_assigned_identity" "central_uai" {
  location            = local.region
  name                = "fsamccg2-uai"
  resource_group_name = local.rg
  tags                = local.common_tags
  lifecycle { ignore_changes = [tags] }
}

resource "azurerm_user_assigned_identity" "app01_uai" {
  location            = local.region
  name                = "fsamfs-ccg-app01winvm-ua-id"
  resource_group_name = local.rg
  tags                = {}
  lifecycle { ignore_changes = [tags] }
}

resource "azurerm_user_assigned_identity" "app02_uai" {
  location            = local.region
  name                = "fsamfs-ccg-app02winvm-ua-id"
  resource_group_name = local.rg
  tags                = {}
  lifecycle { ignore_changes = [tags] }
}

resource "azurerm_user_assigned_identity" "app1_uai" {
  location            = local.region
  name                = "fsamfs-ccg-app1winvm-ua-id"
  resource_group_name = local.rg
  tags                = {}
  lifecycle { ignore_changes = [tags] }
}

resource "azurerm_user_assigned_identity" "app2_uai" {
  location            = local.region
  name                = "fsamfs-ccg-app2winvm-ua-id"
  resource_group_name = local.rg
  tags                = {}
  lifecycle { ignore_changes = [tags] }
}

resource "azurerm_user_assigned_identity" "web01_uai" {
  location            = local.region
  name                = "fsamfs-ccg-web01winvm-ua-id"
  resource_group_name = local.rg
  tags                = {}
  lifecycle { ignore_changes = [tags] }
}

resource "azurerm_user_assigned_identity" "web02_uai" {
  location            = local.region
  name                = "fsamfs-ccg-web02winvm-ua-id"
  resource_group_name = local.rg
  tags                = {}
  lifecycle { ignore_changes = [tags] }
}

resource "azurerm_user_assigned_identity" "web1_uai" {
  location            = local.region
  name                = "fsamfs-ccg-web1winvm-ua-id"
  resource_group_name = local.rg
  tags                = {}
  lifecycle { ignore_changes = [tags] }
}

resource "azurerm_user_assigned_identity" "web2_uai" {
  location            = local.region
  name                = "fsamfs-ccg-web2winvm-ua-id"
  resource_group_name = local.rg
  tags                = {}
  lifecycle { ignore_changes = [tags] }
}
