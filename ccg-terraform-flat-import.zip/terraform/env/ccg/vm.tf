# =============================================================================
# VIRTUAL MACHINES  (4 total: app1, app2, web1, web2)
# =============================================================================

locals {
  vm_image = "/subscriptions/4b4ad43c-6665-4f59-afb4-562f560bb999/resourceGroups/Image_Offers/providers/Microsoft.Compute/galleries/Iaas_OS_Images/images/bmw-win-srv-2022_ae/versions/3.250509.1747380865"
}

# ---------------- app1 ----------------
resource "azurerm_windows_virtual_machine" "app1" {
  admin_username                                         = "fsamdevmadmin"
  admin_password                                         = null # managed outside Terraform
  allow_extension_operations                             = true
  automatic_updates_enabled                              = true
  bypass_platform_safety_checks_on_user_schedule_enabled = true
  computer_name                                          = "fs-ccg-app1cn"
  disk_controller_type                                   = "SCSI"
  encryption_at_host_enabled                             = false
  extensions_time_budget                                 = "PT1H30M"
  hotpatching_enabled                                    = false
  location                                               = local.region
  name                                                   = "fs-ccg-app1"
  network_interface_ids                                  = [azurerm_network_interface.nic_app1.id]
  patch_assessment_mode                                  = "AutomaticByPlatform"
  patch_mode                                             = "AutomaticByPlatform"
  platform_fault_domain                                  = -1
  priority                                               = "Regular"
  provision_vm_agent                                     = true
  proximity_placement_group_id                           = azurerm_proximity_placement_group.ccg_ppg.id
  resource_group_name                                    = local.rg
  secure_boot_enabled                                    = false
  size                                                   = "Standard_F8s_v2"
  source_image_id                                        = local.vm_image
  tags                                                   = local.vm_tags
  vm_agent_platform_updates_enabled                      = true
  vtpm_enabled                                           = false

  additional_capabilities {
    hibernation_enabled = false
    ultra_ssd_enabled   = false
  }
  boot_diagnostics {}
  identity {
    identity_ids = [azurerm_user_assigned_identity.app1_uai.id]
    type         = "SystemAssigned, UserAssigned"
  }
  os_disk {
    caching              = "ReadWrite"
    disk_size_gb         = 127
    name                 = "fs-ccg-app1_OsDisk_1_bbc2ebe0498e47a2b8b62137ea3555e0"
    storage_account_type = "StandardSSD_LRS"
  }
  lifecycle {
    ignore_changes = [admin_password, custom_data, tags, source_image_id,
      os_disk[0].name, identity[0].identity_ids]
  }
}

resource "azurerm_virtual_machine_data_disk_attachment" "app1_disk" {
  caching                   = "ReadWrite"
  create_option             = "Attach"
  lun                       = 0
  managed_disk_id           = "/subscriptions/${local.sub_id}/resourceGroups/${local.rg}/providers/Microsoft.Compute/disks/fsamdatadiskfs-ccg-app1winvm"
  virtual_machine_id        = azurerm_windows_virtual_machine.app1.id
  write_accelerator_enabled = false
  lifecycle { ignore_changes = all }
}

# ---------------- app2 ----------------
resource "azurerm_windows_virtual_machine" "app2" {
  admin_username                                         = "fsamdevmadmin"
  admin_password                                         = null
  allow_extension_operations                             = true
  automatic_updates_enabled                              = true
  bypass_platform_safety_checks_on_user_schedule_enabled = true
  computer_name                                          = "fs-ccg-app2cn"
  disk_controller_type                                   = "SCSI"
  encryption_at_host_enabled                             = false
  extensions_time_budget                                 = "PT1H30M"
  hotpatching_enabled                                    = false
  location                                               = local.region
  name                                                   = "fs-ccg-app2"
  network_interface_ids                                  = [azurerm_network_interface.nic_app2.id]
  patch_assessment_mode                                  = "AutomaticByPlatform"
  patch_mode                                             = "AutomaticByPlatform"
  platform_fault_domain                                  = -1
  priority                                               = "Regular"
  provision_vm_agent                                     = true
  proximity_placement_group_id                           = azurerm_proximity_placement_group.ccg_ppg.id
  resource_group_name                                    = local.rg
  secure_boot_enabled                                    = false
  size                                                   = "Standard_F8s_v2"
  source_image_id                                        = local.vm_image
  tags                                                   = local.vm_tags
  vm_agent_platform_updates_enabled                      = true
  vtpm_enabled                                           = false

  additional_capabilities {
    hibernation_enabled = false
    ultra_ssd_enabled   = false
  }
  boot_diagnostics {}
  identity {
    identity_ids = [azurerm_user_assigned_identity.app2_uai.id]
    type         = "SystemAssigned, UserAssigned"
  }
  os_disk {
    caching              = "ReadWrite"
    disk_size_gb         = 127
    name                 = "fs-ccg-app2_OsDisk_1_c31379a3f60c4850a243942fe8a97a65"
    storage_account_type = "StandardSSD_LRS"
  }
  lifecycle {
    ignore_changes = [admin_password, custom_data, tags, source_image_id,
      os_disk[0].name, identity[0].identity_ids]
  }
}

resource "azurerm_virtual_machine_data_disk_attachment" "app2_disk" {
  caching                   = "ReadWrite"
  create_option             = "Attach"
  lun                       = 0
  managed_disk_id           = "/subscriptions/${local.sub_id}/resourceGroups/${local.rg}/providers/Microsoft.Compute/disks/fsamdatadiskfs-ccg-app2winvm"
  virtual_machine_id        = azurerm_windows_virtual_machine.app2.id
  write_accelerator_enabled = false
  lifecycle { ignore_changes = all }
}

# ---------------- web1 ----------------
resource "azurerm_windows_virtual_machine" "web1" {
  admin_username                                         = "fsamdevmadmin"
  admin_password                                         = null
  allow_extension_operations                             = true
  automatic_updates_enabled                              = true
  bypass_platform_safety_checks_on_user_schedule_enabled = true
  computer_name                                          = "fs-ccg-web1cn"
  disk_controller_type                                   = "SCSI"
  encryption_at_host_enabled                             = false
  extensions_time_budget                                 = "PT1H30M"
  hotpatching_enabled                                    = false
  location                                               = local.region
  name                                                   = "fs-ccg-web1"
  network_interface_ids                                  = [azurerm_network_interface.nic_web1.id]
  patch_assessment_mode                                  = "AutomaticByPlatform"
  patch_mode                                             = "AutomaticByPlatform"
  platform_fault_domain                                  = -1
  priority                                               = "Regular"
  provision_vm_agent                                     = true
  proximity_placement_group_id                           = azurerm_proximity_placement_group.ccg_ppg.id
  resource_group_name                                    = local.rg
  secure_boot_enabled                                    = false
  size                                                   = "Standard_F8s_v2"
  source_image_id                                        = local.vm_image
  tags                                                   = local.vm_tags
  vm_agent_platform_updates_enabled                      = true
  vtpm_enabled                                           = false

  additional_capabilities {
    hibernation_enabled = false
    ultra_ssd_enabled   = false
  }
  boot_diagnostics {}
  identity {
    identity_ids = [azurerm_user_assigned_identity.web1_uai.id]
    type         = "SystemAssigned, UserAssigned"
  }
  os_disk {
    caching              = "ReadWrite"
    disk_size_gb         = 127
    name                 = "fs-ccg-web1_OsDisk_1_a755e0cf96c44ec6957213d237af1b5f"
    storage_account_type = "StandardSSD_LRS"
  }
  lifecycle {
    ignore_changes = [admin_password, custom_data, tags, source_image_id,
      os_disk[0].name, identity[0].identity_ids]
  }
}

resource "azurerm_virtual_machine_data_disk_attachment" "web1_disk" {
  caching                   = "ReadWrite"
  create_option             = "Attach"
  lun                       = 0
  managed_disk_id           = "/subscriptions/${local.sub_id}/resourceGroups/${local.rg}/providers/Microsoft.Compute/disks/fsamdatadiskfs-ccg-web1winvm"
  virtual_machine_id        = azurerm_windows_virtual_machine.web1.id
  write_accelerator_enabled = false
  lifecycle { ignore_changes = all }
}

# ---------------- web2 ----------------
resource "azurerm_windows_virtual_machine" "web2" {
  admin_username                                         = "fsamdevmadmin"
  admin_password                                         = null
  allow_extension_operations                             = true
  automatic_updates_enabled                              = true
  bypass_platform_safety_checks_on_user_schedule_enabled = true
  computer_name                                          = "fs-ccg-web2cn"
  disk_controller_type                                   = "SCSI"
  encryption_at_host_enabled                             = false
  extensions_time_budget                                 = "PT1H30M"
  hotpatching_enabled                                    = false
  location                                               = local.region
  name                                                   = "fs-ccg-web2"
  network_interface_ids                                  = [azurerm_network_interface.nic_web2.id]
  patch_assessment_mode                                  = "AutomaticByPlatform"
  patch_mode                                             = "AutomaticByPlatform"
  platform_fault_domain                                  = -1
  priority                                               = "Regular"
  provision_vm_agent                                     = true
  proximity_placement_group_id                           = azurerm_proximity_placement_group.ccg_ppg.id
  resource_group_name                                    = local.rg
  secure_boot_enabled                                    = false
  size                                                   = "Standard_F8s_v2"
  source_image_id                                        = local.vm_image
  tags                                                   = local.vm_tags
  vm_agent_platform_updates_enabled                      = true
  vtpm_enabled                                           = false

  additional_capabilities {
    hibernation_enabled = false
    ultra_ssd_enabled   = false
  }
  boot_diagnostics {}
  identity {
    identity_ids = [azurerm_user_assigned_identity.web2_uai.id]
    type         = "SystemAssigned, UserAssigned"
  }
  os_disk {
    caching              = "ReadWrite"
    disk_size_gb         = 127
    name                 = "fs-ccg-web2_OsDisk_1_dfbb7a16a4854d14a84cd339b33e4396"
    storage_account_type = "StandardSSD_LRS"
  }
  lifecycle {
    ignore_changes = [admin_password, custom_data, tags, source_image_id,
      os_disk[0].name, identity[0].identity_ids]
  }
}

resource "azurerm_virtual_machine_data_disk_attachment" "web2_disk" {
  caching                   = "ReadWrite"
  create_option             = "Attach"
  lun                       = 0
  managed_disk_id           = "/subscriptions/${local.sub_id}/resourceGroups/${local.rg}/providers/Microsoft.Compute/disks/fsamdatadiskfs-ccg-web2winvm"
  virtual_machine_id        = azurerm_windows_virtual_machine.web2.id
  write_accelerator_enabled = false
  lifecycle { ignore_changes = all }
}

# =============================================================================
# VM EXTENSIONS
# =============================================================================

# ---------- app1 extensions ----------
resource "azurerm_virtual_machine_extension" "app1_aad" {
  auto_upgrade_minor_version  = true
  automatic_upgrade_enabled   = false
  failure_suppression_enabled = false
  name                        = "AADLogin"
  publisher                   = "Microsoft.Azure.ActiveDirectory"
  tags                        = {}
  type                        = "AADLoginForWindows"
  type_handler_version        = "2.2"
  virtual_machine_id          = azurerm_windows_virtual_machine.app1.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}

resource "azurerm_virtual_machine_extension" "app1_policy" {
  auto_upgrade_minor_version  = true
  automatic_upgrade_enabled   = true
  failure_suppression_enabled = false
  name                        = "AzurePolicyforWindows"
  publisher                   = "Microsoft.GuestConfiguration"
  settings                    = jsonencode({})
  tags                        = {}
  type                        = "ConfigurationforWindows"
  type_handler_version        = "1.29"
  virtual_machine_id          = azurerm_windows_virtual_machine.app1.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}

resource "azurerm_virtual_machine_extension" "app1_mde" {
  auto_upgrade_minor_version  = true
  automatic_upgrade_enabled   = true
  failure_suppression_enabled = false
  name                        = "MDE.Windows"
  publisher                   = "Microsoft.Azure.AzureDefenderForServers"
  settings = jsonencode({
    autoUpdate        = true
    azureResourceId   = azurerm_windows_virtual_machine.app1.id
    forceReOnboarding = false
    vNextEnabled      = true
  })
  tags                 = {}
  type                 = "MDE.Windows"
  type_handler_version = "1.0"
  virtual_machine_id   = azurerm_windows_virtual_machine.app1.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}

resource "azurerm_virtual_machine_extension" "app1_vmaccess" {
  auto_upgrade_minor_version  = true
  automatic_upgrade_enabled   = false
  failure_suppression_enabled = false
  name                        = "enablevmAccess"
  publisher                   = "Microsoft.Compute"
  settings = jsonencode({
    userName = "fsamdevmadmin"
  })
  tags                 = {}
  type                 = "VMAccessAgent"
  type_handler_version = "2.0"
  virtual_machine_id   = azurerm_windows_virtual_machine.app1.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}

# ---------- app2 extensions ----------
resource "azurerm_virtual_machine_extension" "app2_aad" {
  auto_upgrade_minor_version  = true
  automatic_upgrade_enabled   = false
  name                        = "AADLogin"
  publisher                   = "Microsoft.Azure.ActiveDirectory"
  tags                        = {}
  type                        = "AADLoginForWindows"
  type_handler_version        = "2.2"
  virtual_machine_id          = azurerm_windows_virtual_machine.app2.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}

resource "azurerm_virtual_machine_extension" "app2_policy" {
  auto_upgrade_minor_version  = true
  automatic_upgrade_enabled   = true
  name                        = "AzurePolicyforWindows"
  publisher                   = "Microsoft.GuestConfiguration"
  settings                    = jsonencode({})
  tags                        = {}
  type                        = "ConfigurationforWindows"
  type_handler_version        = "1.29"
  virtual_machine_id          = azurerm_windows_virtual_machine.app2.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}

resource "azurerm_virtual_machine_extension" "app2_mde" {
  auto_upgrade_minor_version  = true
  automatic_upgrade_enabled   = true
  name                        = "MDE.Windows"
  publisher                   = "Microsoft.Azure.AzureDefenderForServers"
  settings = jsonencode({
    autoUpdate        = true
    azureResourceId   = azurerm_windows_virtual_machine.app2.id
    forceReOnboarding = false
    vNextEnabled      = true
  })
  tags                 = {}
  type                 = "MDE.Windows"
  type_handler_version = "1.0"
  virtual_machine_id   = azurerm_windows_virtual_machine.app2.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}

# ---------- web1 extensions ----------
resource "azurerm_virtual_machine_extension" "web1_aad" {
  auto_upgrade_minor_version  = true
  automatic_upgrade_enabled   = false
  name                        = "AADLogin"
  publisher                   = "Microsoft.Azure.ActiveDirectory"
  tags                        = {}
  type                        = "AADLoginForWindows"
  type_handler_version        = "2.2"
  virtual_machine_id          = azurerm_windows_virtual_machine.web1.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}

resource "azurerm_virtual_machine_extension" "web1_policy" {
  auto_upgrade_minor_version  = true
  automatic_upgrade_enabled   = true
  name                        = "AzurePolicyforWindows"
  publisher                   = "Microsoft.GuestConfiguration"
  settings                    = jsonencode({})
  tags                        = {}
  type                        = "ConfigurationforWindows"
  type_handler_version        = "1.29"
  virtual_machine_id          = azurerm_windows_virtual_machine.web1.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}

resource "azurerm_virtual_machine_extension" "web1_iis" {
  auto_upgrade_minor_version  = false
  automatic_upgrade_enabled   = false
  name                        = "IIS"
  publisher                   = "Microsoft.Compute"
  settings = jsonencode({
    commandToExecute = "powershell -ExecutionPolicy Bypass -Command \"Install-WindowsFeature Web-Server -IncludeManagementTools; Install-WindowsFeature Web-Asp-Net45\""
  })
  tags = {
    DeploymentTimestamp = "2025-09-08T02:00:19Z"
    TerraformWorkspace  = "default"
    customer_prefix     = "fsam"
    env                 = "ccg"
    environment         = "ccg"
  }
  type                 = "CustomScriptExtension"
  type_handler_version = "1.10"
  virtual_machine_id   = azurerm_windows_virtual_machine.web1.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}

resource "azurerm_virtual_machine_extension" "web1_mde" {
  auto_upgrade_minor_version  = true
  automatic_upgrade_enabled   = true
  name                        = "MDE.Windows"
  publisher                   = "Microsoft.Azure.AzureDefenderForServers"
  settings = jsonencode({
    autoUpdate        = true
    azureResourceId   = azurerm_windows_virtual_machine.web1.id
    forceReOnboarding = false
    vNextEnabled      = true
  })
  tags                 = {}
  type                 = "MDE.Windows"
  type_handler_version = "1.0"
  virtual_machine_id   = azurerm_windows_virtual_machine.web1.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}

# ---------- web2 extensions ----------
resource "azurerm_virtual_machine_extension" "web2_aad" {
  auto_upgrade_minor_version  = true
  automatic_upgrade_enabled   = false
  name                        = "AADLogin"
  publisher                   = "Microsoft.Azure.ActiveDirectory"
  tags                        = {}
  type                        = "AADLoginForWindows"
  type_handler_version        = "2.2"
  virtual_machine_id          = azurerm_windows_virtual_machine.web2.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}

resource "azurerm_virtual_machine_extension" "web2_policy" {
  auto_upgrade_minor_version  = true
  automatic_upgrade_enabled   = true
  name                        = "AzurePolicyforWindows"
  publisher                   = "Microsoft.GuestConfiguration"
  settings                    = jsonencode({})
  tags                        = {}
  type                        = "ConfigurationforWindows"
  type_handler_version        = "1.29"
  virtual_machine_id          = azurerm_windows_virtual_machine.web2.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}

resource "azurerm_virtual_machine_extension" "web2_iis" {
  auto_upgrade_minor_version  = false
  automatic_upgrade_enabled   = false
  name                        = "IIS"
  publisher                   = "Microsoft.Compute"
  settings = jsonencode({
    commandToExecute = "powershell -ExecutionPolicy Bypass -Command \"Install-WindowsFeature Web-Server -IncludeManagementTools; Install-WindowsFeature Web-Asp-Net45\""
  })
  tags = {
    DeploymentTimestamp = "2025-09-08T02:00:19Z"
    TerraformWorkspace  = "default"
    customer_prefix     = "fsam"
    env                 = "ccg"
    environment         = "ccg"
  }
  type                 = "CustomScriptExtension"
  type_handler_version = "1.10"
  virtual_machine_id   = azurerm_windows_virtual_machine.web2.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}

resource "azurerm_virtual_machine_extension" "web2_mde" {
  auto_upgrade_minor_version  = true
  automatic_upgrade_enabled   = true
  name                        = "MDE.Windows"
  publisher                   = "Microsoft.Azure.AzureDefenderForServers"
  settings = jsonencode({
    autoUpdate        = true
    azureResourceId   = azurerm_windows_virtual_machine.web2.id
    forceReOnboarding = false
    vNextEnabled      = true
  })
  tags                 = {}
  type                 = "MDE.Windows"
  type_handler_version = "1.0"
  virtual_machine_id   = azurerm_windows_virtual_machine.web2.id
  lifecycle { ignore_changes = [tags, type_handler_version, settings, protected_settings] }
}
