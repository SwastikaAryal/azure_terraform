# =================================================================================================
# File: terraform/testing/variables.tf
# =================================================================================================

variable "subscription_id" {
  type      = string
  sensitive = true
}

variable "tenant_id" {
  type = string
}

variable "cloud_region" {
  type    = string
  default = "eastus"
}

variable "resource_group_name" {
  description = "Existing RG to deploy the test VM into."
  type        = string
}

variable "virtual_network_name" {
  type = string
}

variable "vnet_resource_group_name" {
  type = string
}

variable "app_subnet_name" {
  type = string
}

variable "vm_custom_suffix" {
  description = "Short suffix for the test VM name — unique per env."
  type        = string
}

variable "vm_size" {
  type    = string
  default = "Standard_B2s"
}

variable "vm_admin_username" {
  type    = string
  default = "fsamdevmadmin"
}

# Passed as -var from the pipeline — never stored in tfvars
variable "vm_admin_password" {
  type      = string
  sensitive = true
}

variable "vm_image_source_id" {
  type    = string
  default = "/subscriptions/4b4ad43c-6665-4f59-afb4-562f560bb999/resourceGroups/Image_Offers/providers/Microsoft.Compute/galleries/Iaas_OS_Images/images/bmw-win-srv-2022_ae/versions/latest"
}
