
{
  "seperator": "-",
  "resource_type": {
    "azurerm_resource_group": {
      "name": "${customer_prefix}${env}${s}rg"
    },
    "azurerm_storage_account": {
      "name": "${customer_prefix}${env}stprivatebmw",
      "length": "24",
      "validRegex": "[^a-z0-9]"
    },
    "azurerm_key_vault": {
      "name": "${customer_prefix}${env}${s}kv"
    },
    "azurerm_log_analytics_workspace": {
      "name": "${customer_prefix}${env}${s}law"
    },
    "azurerm_windows_virtual_machine": {
      "name": "${customer_prefix}${custom_name}winvm"    
    },
    "azurerm_data_protection_backup_vault": {
      "name": "${customer_prefix}${env}${s}bkv"
    },
    "azurerm_data_protection_resource_guard": {
      "name": "${customer_prefix}${env}${s}rgd"
    }
  }
}