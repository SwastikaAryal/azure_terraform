# =================================================================================================
# File: terraform/testing/vm.tf
# Single test VM — created and destroyed within the same pipeline job.
# =================================================================================================

module "test_vm" {
  source = "../modules/virtual_machine"

  resource_group_name      = var.resource_group_name
  cloud_region             = var.cloud_region
  custom_name_suffix       = var.vm_custom_suffix
  global_config            = local.global_config
  region_code              = "2"
  tags                     = local.tags
  naming_file_json_tpl     = "${path.module}/naming.json.tpl"

  subnet_id                = data.azurerm_subnet.app_subnet.id
  app_subnet_name          = var.app_subnet_name
  virtual_network_name     = var.virtual_network_name
  vnet_resource_group_name = var.vnet_resource_group_name

  vm_size         = var.vm_size
  os_type         = "Windows"
  source_image_id = var.vm_image_source_id

  admin_username                       = var.vm_admin_username
  admin_password_key_vault_secret_id   = var.vm_admin_password
  admin_password_direct_for_bmw_module = null

  # Match prod state values — avoids replacement cycles on any future import
  windows_patch_mode             = "AutomaticByPlatform"
  os_disk_storage_account_type   = "StandardSSD_LRS"
  enable_encryption_at_host      = false
  accelerated_networking_enabled = true
  secure_boot_enabled            = false
  vtpm_enabled                   = false

  boot_diagnostics_enabled             = false
  boot_diagnostics_storage_account_uri = null
  enable_system_assigned_identity      = false
  user_assigned_identity_ids           = []
  log_analytics_workspace_id           = null
  log_analytics_primary_shared_key     = null
}

output "vm_id" {
  value = module.test_vm.id
}

output "vm_name" {
  value = module.test_vm.name
}
