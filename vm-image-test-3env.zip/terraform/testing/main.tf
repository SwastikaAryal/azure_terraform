# =================================================================================================
# File: terraform/testing/main.tf
# =================================================================================================

locals {
  global_config = {
    customer_prefix = "fsam"
    env             = "img"
    product_id      = "SWP-000"
    appd_id         = "APPD-326047"
    app_name        = "AF"
    costcenter      = "1845"
    tags            = { env = "img" }
  }

  tags = {
    env        = "img"
    purpose    = "image-gallery-smoke-test"
    managed_by = "terraform-testing-pipeline"
  }
}

data "azurerm_subnet" "app_subnet" {
  name                 = var.app_subnet_name
  virtual_network_name = var.virtual_network_name
  resource_group_name  = var.vnet_resource_group_name
}
