# =================================================================================================
# File: terraform/testing/providers.tf
# Backend key is injected per job via -backend-config in the pipeline.
# =================================================================================================

terraform {
  required_version = ">= 1.7.2"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.27.0"
    }
  }

  backend "azurerm" {}
}

provider "azurerm" {
  features {}
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id
  use_oidc        = true
}
