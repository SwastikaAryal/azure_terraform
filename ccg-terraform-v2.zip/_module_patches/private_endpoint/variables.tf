//=========================================================================
// File: terraform/modules/private_endpoint/variables.tf
// =========================================================================

variable "base_name" {
  type        = string
  description = "Base name for the private endpoint and related resources."
}

variable "resource_group_name" {
  type        = string
  description = "Name of the resource group for the private endpoint."
}

variable "cloud_region" {
  type        = string
  description = "Azure region where the private endpoint will be deployed."
}

variable "subnet_id" {
  type        = string
  description = "ID of the subnet where the private endpoint will be deployed."
}

variable "private_connection_resource_id" {
  type        = string
  description = "ID of the resource to which the private endpoint connects."
}

variable "is_manual_connection" {
  type        = bool
  default     = false
  description = "Whether the private endpoint connection is manual."
}

variable "request_message" {
  type        = string
  default     = "Requesting private link connection"
  description = "Message to send with manual connection requests."
}

variable "subresource_names" {
  type        = list(string)
  description = "List of subresource names for the private service connection."
}

variable "private_dns_zone_ids" {
  type        = list(string)
  default     = []
  description = "No longer used by this module if DNS is manual. Kept for compatibility if used elsewhere with DNS automation."
}

variable "tags" {
  type        = map(string)
  default     = {}
  description = "Tags to apply to the private endpoint."
}

variable "custom_nic_name" {
  type        = string
  default     = null
  description = "Custom name for the network interface of the private endpoint."
}

variable "psc_name_override" {
  type        = string
  default     = null
  description = "Override for the private_service_connection name. If null, defaults to 'psc-{base_name}'."
}
