# =================================================================================================
# File: terraform/modules/keyvault/main.tf
# =================================================================================================

locals {
  # The BMW KV module generates name as: {prefix}{env}-{custom_name}
  # For CCG the existing Azure resource name is "fsamccg2-kv" (has "2" after env).
  # To produce "fsamccg2-kv" we pass env="ccg2" so BMW generates "fsamccg2-kv".
  # This env override is ONLY passed to the BMW KV module for naming purposes.
  # All other env-based logic (tags, policies) remains unaffected because they use
  # the original global_config passed from the env level.
  kv_global_config_with_bump = merge(var.global_config, {
    env = format("%s%s", var.global_config.env, var.region_code)
  })
}

module "bmw_key_vault" {
  source              = "git::https://atc-github.azure.cloud.bmw/cgbp/terraform-azure-bmw-key-vault.git?ref=5.3.1"
  # Use env+region_code merged config so BMW generates "{prefix}{env}{region_code}-{custom_name}"
  # e.g. "fsamccg2-kv" when prefix=fsam, env=ccg, region_code=2, custom_name=kv
  global_config               = local.kv_global_config_with_bump
  cloud_region                = var.cloud_region
  resource_group_name         = var.resource_group_name
  custom_name                 = var.custom_name_suffix
  sku_name                    = var.sku_name
  enable_rbac_authorization   = var.enable_rbac_authorization
  purge_protection_enabled    = var.purge_protection_enabled
  soft_delete_retention_days  = var.soft_delete_retention_days
  enabled_for_disk_encryption = var.enabled_for_disk_encryption
  enable_logging              = var.create_diagnostic_settings
  log_analytics_workspace_id  = var.create_diagnostic_settings ? var.log_analytics_workspace_id : null
  allowed_ips                 = var.allowed_ips
  allowed_subnet_ids          = var.allowed_subnet_ids
  custom_tags                 = var.tags
  naming_file_json_tpl        = var.naming_file_json_tpl
  public_network_access_enabled = var.public_network_access_enabled
}
