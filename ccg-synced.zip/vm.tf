# =================================================================================================
# File: terraform/env/ccg/vm.tf
# All values confirmed from terraform-ccg.tfstate
# =================================================================================================

module "application_vms" {
  source   = "../../modules/virtual_machine"
  for_each = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf }

  resource_group_name                  = azurerm_resource_group.application_rg.name
  cloud_region                         = var.cloud_region
  custom_name_suffix                   = each.value.custom_suffix
  global_config                        = local.global_config_for_commons
  region_code                          = local.number_bump
  tags                                 = local.merged_tags
  subnet_id                            = data.azurerm_subnet.app_subnet.id
  app_subnet_name                      = var.app_subnet_name
  virtual_network_name                 = var.virtual_network_name
  vnet_resource_group_name             = var.vnet_resource_group_name
  vm_size                              = each.value.size
  admin_username                       = var.vm_admin_username
  os_type                              = "Windows"
  source_image_id                      = var.vm_image_source_id
  admin_password_key_vault_secret_id   = var.admin_password_key_vault_secret_id
  admin_password_direct_for_bmw_module = null
  enable_system_assigned_identity      = false
  user_assigned_identity_ids           = [module.central_managed_identity.id]
  log_analytics_workspace_id           = module.application_log_analytics.log_analytics_id
  log_analytics_primary_shared_key     = module.application_log_analytics.log_analytics_primary_shared_key
  boot_diagnostics_enabled             = true
  windows_patch_mode                   = var.windows_patch_mode
  naming_file_json_tpl                 = local.naming_json
  secure_boot_enabled                  = var.secure_boot_enabled
  vtpm_enabled                         = var.vtpm_enabled
}

# =============================================================================
# VM EXTENSIONS
# All values confirmed from terraform-ccg.tfstate.
# lifecycle ignore_changes = all prevents any drift from causing changes.
# =============================================================================

# enablevmAccess — app1 ONLY
# State: name=enablevmAccess, publisher=Microsoft.Compute, type=VMAccessAgent,
#        version=2.0, auto_upgrade_minor=true, automatic_upgrade=false
#        settings={"userName":"fsamdevmadmin"}
resource "azurerm_virtual_machine_extension" "enable_vm_access" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if vm_conf.custom_suffix == "fs-ccg-app1" }
  name                       = "enablevmAccess"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Compute"
  type                       = "VMAccessAgent"
  type_handler_version       = "2.0"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = false
  settings = jsonencode({
    "userName" = var.vm_admin_username
  })
  tags       = local.merged_tags
  depends_on = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, settings, protected_settings, type_handler_version]
  }
}

# AADLogin — all 4 VMs
# State: name=AADLogin, publisher=Microsoft.Azure.ActiveDirectory,
#        type=AADLoginForWindows, version=2.2,
#        auto_upgrade_minor=true, automatic_upgrade=false
resource "azurerm_virtual_machine_extension" "aad_login" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "AADLogin") }
  name                       = "AADLogin"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Azure.ActiveDirectory"
  type                       = "AADLoginForWindows"
  type_handler_version       = "2.2"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = false
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, settings, protected_settings, type_handler_version]
  }
}

# IIS — web1 and web2 only
# State: name=IIS, publisher=Microsoft.Compute, type=CustomScriptExtension,
#        version=1.10, auto_upgrade_minor=false, automatic_upgrade=false
resource "azurerm_virtual_machine_extension" "iis_installer" {
  for_each             = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "IIS") }
  name                 = "IIS"
  virtual_machine_id   = module.application_vms[each.key].id
  publisher            = "Microsoft.Compute"
  type                 = "CustomScriptExtension"
  type_handler_version = "1.10"
  settings = jsonencode({
    commandToExecute = "powershell -ExecutionPolicy Bypass -Command \"Install-WindowsFeature Web-Server -IncludeManagementTools; Install-WindowsFeature Web-Asp-Net45\""
  })
  tags       = local.merged_tags
  depends_on = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, settings, protected_settings, type_handler_version]
  }
}

# MDE.Windows — all 4 VMs
# State: name=MDE.Windows, publisher=Microsoft.Azure.AzureDefenderForServers,
#        type=MDE.Windows, version=1.0,
#        auto_upgrade_minor=true, automatic_upgrade=true
#        settings contain azureResourceId which is VM-specific — ignore_changes prevents drift
resource "azurerm_virtual_machine_extension" "mde_windows" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "MDE") }
  name                       = "MDE.Windows"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Azure.AzureDefenderForServers"
  type                       = "MDE.Windows"
  type_handler_version       = "1.0"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = true
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, settings, protected_settings, type_handler_version]
  }
}

# AzurePolicyforWindows — all 4 VMs (deployed automatically by Azure Policy)
# State: name=AzurePolicyforWindows, publisher=Microsoft.GuestConfiguration,
#        type=ConfigurationforWindows, version=1.29,
#        auto_upgrade_minor=true, automatic_upgrade=true, settings={}
resource "azurerm_virtual_machine_extension" "azure_policy" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf }
  name                       = "AzurePolicyforWindows"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.GuestConfiguration"
  type                       = "ConfigurationforWindows"
  type_handler_version       = "1.29"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = true
  settings                   = jsonencode({})
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, settings, protected_settings, type_handler_version]
  }
}
