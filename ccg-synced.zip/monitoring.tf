# =================================================================================================
# File: terraform/env/ccg/monitoring.tf
# =================================================================================================

module "application_log_analytics" {
  source                             = "../../modules/log_analytics_workspace"
  resource_group_name                = azurerm_resource_group.application_rg.name
  cloud_region                       = var.cloud_region
  custom_name_suffix                 = var.log_analytics_custom_suffix
  global_config                      = local.global_config_for_commons
  region_code                        = local.number_bump
  tags                               = local.merged_tags
  sku                                = var.log_analytics_sku
  retention_in_days                  = var.log_analytics_retention_in_days
  create_app_insights_via_bmw_module = false
  app_insights_custom_suffix         = var.app_insights_custom_suffix
  app_insights_application_type      = var.app_insights_application_type
  naming_file_json_tpl               = local.naming_json
  depends_on                         = [azurerm_resource_group.application_rg]
}

module "critical_alerts_action_group" {
  source              = "../../modules/action_group"
  resource_group_name = azurerm_resource_group.application_rg.name
  global_config       = local.global_config_for_commons
  custom_name_suffix  = format("-critical")
  region_code         = local.number_bump
  short_name          = "crit-dev"
  tags                = local.merged_tags
  email_receivers     = [{ name = "critical-alerts-email-dev", email_address = "Shravan.Chiduruppa@bmwfs.com", use_common_alert_schema = true }]
  depends_on          = [azurerm_resource_group.application_rg]
}

module "warning_alerts_action_group" {
  source              = "../../modules/action_group"
  resource_group_name = azurerm_resource_group.application_rg.name
  global_config       = local.global_config_for_commons
  custom_name_suffix  = format("-warning")
  region_code         = local.number_bump
  short_name          = "warn-dev"
  tags                = local.merged_tags
  email_receivers     = [{ name = "warning-alerts-email-dev", email_address = "Shravan.Chiduruppa@bmwfs.com", use_common_alert_schema = true }]
  depends_on          = [azurerm_resource_group.application_rg]
}
