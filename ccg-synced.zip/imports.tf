# =================================================================================================
# File: terraform/env/ccg/imports.tf
# =================================================================================================
# All CCG resources have been imported into state via terraform import CLI commands.
# This file is intentionally empty.
# Do NOT add import blocks here — they have already been processed.
# =================================================================================================
