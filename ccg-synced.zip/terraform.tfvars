# =================================================================================================
# File: terraform/env/ccg/terraform.tfvars
# All values confirmed from terraform-ccg.tfstate
# =================================================================================================

cloud_region    = "eastus"
environment     = "ccg"
subscription_id = "4cda8977-68ea-4ca5-aa6a-fae45e7e98f3"
tenant_id       = "ce849bab-cc1c-465b-b62e-18f07c9ac198"

global_config_base = {
  customer_prefix = "fsam"
  env             = "ccg"
  product_id      = "SWP-000"
  appd_id         = "APPD-326047"
  app_name        = "AF"
  costcenter      = "1845"
  tags = {
    customer_prefix = "fsam"
    env             = "ccg"
    owner           = "FG-AM-32"
    appd_id         = "APPD-326047"
    app_name        = "AF"
  }
}

# Exact name of existing resource group — do not change
resource_group_name_override = "FSAM-CLEANCONFIG-RG"

# Networking — confirmed from state file
virtual_network_name     = "VNET-SPOKE-EUS-12815"
vnet_resource_group_name = "RG-VNET-SPOKE-EUS-12815"
app_subnet_name          = "Subnet-1"
allowed_ips              = ["10.81.118.0/26"]

# VM credentials — confirmed from state file (admin_username = fsamdevmadmin)
vm_admin_username                  = "fsamdevmadmin"
vm_image_source_id                 = "/subscriptions/4b4ad43c-6665-4f59-afb4-562f560bb999/resourceGroups/Image_Offers/providers/Microsoft.Compute/galleries/Iaas_OS_Images/images/bmw-win-srv-2022_ae/versions/3.250509.1747380865"
admin_password_key_vault_secret_id = "$vmcompute@123"

# VM settings confirmed from state file
windows_patch_mode  = "AutomaticByPlatform"
secure_boot_enabled = false
vtpm_enabled        = false

# VM configs — 4 VMs confirmed from state file
vm_configurations = [
  { custom_suffix = "fs-ccg-app1", size = "Standard_F8s_v2", extensions_to_install = ["AADLogin", "MDE"] },
  { custom_suffix = "fs-ccg-app2", size = "Standard_F8s_v2", extensions_to_install = ["AADLogin", "MDE"] },
  { custom_suffix = "fs-ccg-web1", size = "Standard_F8s_v2", extensions_to_install = ["IIS", "AADLogin", "MDE"] },
  { custom_suffix = "fs-ccg-web2", size = "Standard_F8s_v2", extensions_to_install = ["IIS", "AADLogin", "MDE"] }
]

# Managed disks — confirmed from state file (StandardSSD_ZRS, 100GB, lun=0)
standalone_managed_disks_config = [
  { vm_custom_suffix = "fs-ccg-app1", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
  { vm_custom_suffix = "fs-ccg-app2", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
  { vm_custom_suffix = "fs-ccg-web1", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
  { vm_custom_suffix = "fs-ccg-web2", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" }
]

create_vmss = false

# Only "file" PE exists in portal — confirmed from state file
enable_storage_private_endpoints = true

# No KV PE in CCG portal
enable_keyvault_private_endpoint = false

# Automation "Webhook" PE exists — confirmed from state file
enable_automation_private_endpoint = true

# Module naming suffixes — drives resource names inside BMW modules
central_managed_identity_custom_suffix = "uai"          # → fsamccg2-uai
automation_account_custom_suffix       = "auto"         # → fsamccg2-aa-auto
log_analytics_custom_suffix            = "law"          # → fsamccg-law
app_insights_custom_suffix             = "aapin"        # → fsam-ccg-2-aapin (name ignored via lifecycle)
load_balancer_custom_suffix            = "app"          # → fsamccg2-lb-app
key_vault_custom_suffix                = "kv"           # → fsamccg2-kv
storage_account_main_custom_suffix     = "stprivatebmw" # → fsamccgstprivatebmw

log_analytics_sku               = "PerGB2018"
log_analytics_retention_in_days = 90
app_insights_application_type   = "web"

automation_account_sku_name = "Basic"
automation_module_names     = []

# All 3 connection types — confirmed from state file
automation_account_connection_types_config = [
  {
    name      = "Azure"
    is_global = true
    fields = [
      { name = "AutomationCertificateName", type = "System.String", is_encrypted = false, is_optional = false },
      { name = "SubscriptionID",            type = "System.String", is_encrypted = false, is_optional = false }
    ]
  },
  {
    name      = "AzureClassicCertificate"
    is_global = true
    fields = [
      { name = "SubscriptionName",     type = "System.String", is_encrypted = false, is_optional = false },
      { name = "SubscriptionId",       type = "System.String", is_encrypted = false, is_optional = false },
      { name = "CertificateAssetName", type = "System.String", is_encrypted = false, is_optional = false }
    ]
  },
  {
    name      = "AzureServicePrincipal"
    is_global = true
    fields = [
      { name = "ApplicationId",         type = "System.String", is_encrypted = false, is_optional = false },
      { name = "TenantId",              type = "System.String", is_encrypted = false, is_optional = false },
      { name = "CertificateThumbprint", type = "System.String", is_encrypted = false, is_optional = false },
      { name = "SubscriptionId",        type = "System.String", is_encrypted = false, is_optional = false }
    ]
  }
]

# Storage account — confirmed from state file
storage_account_main_config = {
  tier                            = "Standard"
  replication_type                = "ZRS"
  allow_blob_public_access        = false
  public_network_access_enabled   = true
  shared_access_key_enabled       = true
  min_tls_version                 = "TLS1_2"
  default_to_oauth_authentication = true
}

# Key Vault — confirmed from state file
key_vault_sku_name = "standard"
key_vault_config_flags = {
  enabled_for_disk_encryption = true
  purge_protection_enabled    = true
  soft_delete_retention_days  = 90
}

recovery_services_vault_custom_suffix = "rsv"
recovery_services_vault_sku           = "RS0"
recovery_services_vault_config_flags = {
  soft_delete_enabled = true
  storage_mode_type   = "GeoRedundant"
}
vm_backup_policy_default_config = {
  name                  = "fsam-cleanconfig-rsv-vm"
  frequency             = "Daily"
  time                  = "23:00"
  timezone              = "UTC"
  retention_daily_count = 30
}

enable_database_migration_service = false
