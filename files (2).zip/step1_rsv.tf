###############################################################################
# step1_rsv.tf
# Runbook: Recovery Services Vault – Verify
# Backup method: Azure Backup built-in RSV verification (pre-check, no restore)
# Frequency: N/A – Pre-check | Dependency: None – DR Start
#
# Terraform OWNS: Backup Operator RBAC, backup failure alert
# Terraform READS: data.azurerm_recovery_services_vault.rsv
###############################################################################

# DR operator gets Backup Operator role on the existing RSV
resource "azurerm_role_assignment" "dr_operator_backup_operator" {
  scope                = data.azurerm_recovery_services_vault.rsv.id
  role_definition_name = "Backup Operator"
  principal_id         = var.dr_operator_object_id
}

# Alert: any backup job failure on the existing RSV
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "rsv_backup_failure" {
  name                 = "rsv-backup-job-failure"
  location             = local.loc
  resource_group_name  = local.rg
  severity             = 1
  description          = "Step 1: RSV backup job failed – DR operator must investigate"
  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [data.azurerm_recovery_services_vault.rsv.id]

  criteria {
    query = <<-QUERY
      AddonAzureBackupJobs
      | where JobStatus == "Failed"
      | where BackupItemType in ("AzureIaasVM", "SQLDataBase")
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action { action_groups = [azurerm_monitor_action_group.infra_ag.id] }
}

output "step1_verify" {
  description = "Step 1 runbook verification commands"
  value = <<-EOT
    # Confirm vault healthy and not soft-deleted
    az backup vault show --name ${var.rsv_name} --resource-group ${local.rg} \
      --query "{state:properties.provisioningState, softDelete:properties.softDeleteFeatureState}" -o json

    # Confirm replication = GRS
    az backup vault backup-properties show \
      --name ${var.rsv_name} --resource-group ${local.rg} \
      --query "properties.storageModelType" -o tsv

    # List all backup items
    az backup item list --resource-group ${local.rg} --vault-name ${var.rsv_name} -o table

    # Latest restore point (RPO gap)
    az backup recoverypoint list \
      --resource-group ${local.rg} --vault-name ${var.rsv_name} \
      --container-name "iaasvmcontainer;iaasvmcontainerv2;${local.rg};${var.vm_name}" \
      --item-name "vm;iaasvmcontainerv2;${local.rg};${var.vm_name}" -o table
  EOT
}
