###############################################################################
# step8_ssl.tf
# Runbook: SSL Certificate – Verify & Bind
# Backup method: KV certificate versioning + manual IIS HTTPS binding
# Frequency: Manual (certificate renewal cycle) | Dependency: Step 7
#
# Terraform OWNS: cert expiry alert (30-day warning)
# Terraform READS: data.azurerm_key_vault_certificate.ssl_cert
#
# NOTE: KV auto-versions all certificate updates – no backup action needed.
#       IIS HTTPS re-binding after restore is a manual step (see output below).
###############################################################################

# Alert: SSL cert expiring within 30 days
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "ssl_expiry" {
  name                 = "ssl-cert-expiry-30days"
  location             = local.loc
  resource_group_name  = local.rg
  severity             = 2
  description          = "Step 8: SSL cert expiring within 30 days – renew and re-bind IIS"
  evaluation_frequency = "P1D"
  window_duration      = "P1D"
  scopes               = [data.azurerm_log_analytics_workspace.law.id]

  criteria {
    query = <<-QUERY
      AzureDiagnostics
      | where ResourceType == "VAULTS"
      | where OperationName == "CertificateNearExpiry"
      | where Resource =~ "${var.keyvault_name}"
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action { action_groups = [azurerm_monitor_action_group.infra_ag.id] }
}

output "step8_verify" {
  description = "Step 8 runbook verification commands"
  value = <<-EOT
    # Check cert versions in KV
    az keyvault certificate list-versions \
      --vault-name ${var.keyvault_name} --name ${var.ssl_cert_name} -o table

    # Check cert expiry
    az keyvault certificate show \
      --vault-name ${var.keyvault_name} --name ${var.ssl_cert_name} \
      --query "{thumbprint:x509Thumbprint,expires:attributes.expires,enabled:attributes.enabled}" -o json

    # After restore – re-bind cert to IIS (run inside VM, PowerShell):
    # $cert = Get-ChildItem Cert:\LocalMachine\My | Where-Object { $_.Subject -like '*fsam*' }
    # Import-Module WebAdministration
    # $binding = Get-WebBinding -Name "Default Web Site" -Protocol https
    # $binding.AddSslCertificate($cert.Thumbprint, "My")
  EOT
}
