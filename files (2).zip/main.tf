###############################################################################
# main.tf
#
# All portal resources are referenced via DATA BLOCKS in data_sources.tf.
# This state file ONLY owns the DR/backup config layered on top.
# Run: terraform init → terraform plan → terraform apply. Nothing else needed.
###############################################################################

terraform {
  required_version = ">= 1.3"
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~> 3.100"
    }
  }

  backend "azurerm" {
    resource_group_name  = "tfstate-rg"
    storage_account_name = "fsamtfstate"
    container_name       = "tfstate"
    key                  = "fsam-uat-dr-backup.tfstate"
  }
}

provider "azurerm" {
  subscription_id = var.subscription_id
  features {
    key_vault {
      recover_soft_deleted_key_vaults = true
      recover_soft_deleted_secrets    = true
      purge_soft_delete_on_destroy    = false
    }
    recovery_services_vault {
      purge_soft_delete_on_destroy = false
    }
    virtual_machine {
      delete_os_disk_on_deletion = false
    }
  }
}

locals {
  rg  = var.resource_group_name
  loc = var.location
  tags = {
    project    = "FSAM-UAT"
    managed_by = "Terraform-DR"
    phase      = "Phase1-Steps1-9"
  }
}
