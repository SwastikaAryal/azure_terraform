###############################################################################
# step7_lb.tf
# Runbook: Load Balancer – Health Verify
# Backup method: ARM/Bicep IaC + LB config export (no restore – verify only)
# Frequency: On-change (IaC pipeline) | Dependency: Step 6
#
# Terraform OWNS: LB diagnostic logs, DipAvailability + VipAvailability alerts
# Terraform READS: data.azurerm_lb.lb
###############################################################################

resource "azurerm_monitor_diagnostic_setting" "lb_diag" {
  name                       = "lb-diag-dr"
  target_resource_id         = data.azurerm_lb.lb.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.law.id

  metric { category = "AllMetrics"; enabled = true }
}

# Alert: backend health probe failing
resource "azurerm_monitor_metric_alert" "lb_dip" {
  name                = "lb-backend-unhealthy"
  resource_group_name = local.rg
  scopes              = [data.azurerm_lb.lb.id]
  description         = "Step 7: LB backend health probe failing – VM unreachable"
  severity            = 1
  frequency           = "PT1M"
  window_size         = "PT5M"

  criteria {
    metric_namespace = "Microsoft.Network/loadBalancers"
    metric_name      = "DipAvailability"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 100
  }

  action { action_group_id = azurerm_monitor_action_group.infra_ag.id }
}

# Alert: frontend VIP unavailable
resource "azurerm_monitor_metric_alert" "lb_vip" {
  name                = "lb-vip-unavailable"
  resource_group_name = local.rg
  scopes              = [data.azurerm_lb.lb.id]
  description         = "Step 7: LB VIP unavailable – frontend unreachable"
  severity            = 1
  frequency           = "PT1M"
  window_size         = "PT5M"

  criteria {
    metric_namespace = "Microsoft.Network/loadBalancers"
    metric_name      = "VipAvailability"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 100
  }

  action { action_group_id = azurerm_monitor_action_group.infra_ag.id }
}

output "step7_verify" {
  description = "Step 7 runbook verification commands"
  value = <<-EOT
    # Confirm LB backend pool and probe config
    az network lb show --name ${var.lb_name} --resource-group ${local.rg} \
      --query "{frontendIPs:frontendIPConfigurations[].name,backendPools:backendAddressPools[].name,probes:probes[].{name:name,port:port}}" -o json

    # Export LB config as IaC source-of-truth snapshot
    az network lb show --name ${var.lb_name} --resource-group ${local.rg} -o json \
      > lb-config-export-$(date +%Y%m%d).json
  EOT
}
