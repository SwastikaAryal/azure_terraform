###############################################################################
# step9_monitoring.tf
# Runbook: Monitoring & Alerting – Verify Active
# Backup method: Azure Monitor native (always-on) + Log Analytics
# Frequency: Real-time (continuous ingestion) | Dependency: Step 8
#
# Terraform OWNS: Action Group (shared by ALL step alerts), DCR, Monitor Agent
# Terraform READS: data.azurerm_log_analytics_workspace.law, data.azurerm_virtual_machine.vm
###############################################################################

# Action Group – shared by every alert in steps 1–9b
resource "azurerm_monitor_action_group" "infra_ag" {
  name                = "fsamuat-infra-alerts"
  resource_group_name = local.rg
  short_name          = "fsam-ag"

  email_receiver {
    name                    = "infra-team"
    email_address           = var.alert_email
    use_common_alert_schema = true
  }

  tags = local.tags
}

# Data Collection Rule: VM perf counters + event logs → existing Log Analytics
resource "azurerm_monitor_data_collection_rule" "vm_dcr" {
  name                = "fsamuat-vm-dcr"
  resource_group_name = local.rg
  location            = local.loc
  tags                = local.tags

  destinations {
    log_analytics {
      workspace_resource_id = data.azurerm_log_analytics_workspace.law.id
      name                  = "law-dest"
    }
  }

  data_flow {
    streams      = ["Microsoft-Perf", "Microsoft-Event"]
    destinations = ["law-dest"]
  }

  data_sources {
    performance_counter {
      streams                       = ["Microsoft-Perf"]
      sampling_frequency_in_seconds = 60
      counter_specifiers = [
        "\\Processor(_Total)\\% Processor Time",
        "\\Memory\\Available MBytes",
        "\\LogicalDisk(C:)\\% Free Space",   # Step 5 – OS disk
        "\\LogicalDisk(E:)\\% Free Space",   # Step 6 – data disk
        "\\Network Interface(*)\\Bytes Total/sec",
      ]
      name = "vm-perf-counters"
    }

    windows_event_log {
      streams        = ["Microsoft-Event"]
      x_path_queries = [
        "Application!*[System[(Level=1 or Level=2)]]",
        "System!*[System[(Level=1 or Level=2)]]",
      ]
      name = "vm-event-logs"
    }
  }
}

# Associate DCR with the existing VM
resource "azurerm_monitor_data_collection_rule_association" "vm_dcr_assoc" {
  name                    = "fsamuat-vm-dcr-assoc"
  target_resource_id      = data.azurerm_virtual_machine.vm.id
  data_collection_rule_id = azurerm_monitor_data_collection_rule.vm_dcr.id
}

# Azure Monitor Agent on the existing VM
resource "azurerm_virtual_machine_extension" "ama" {
  name                       = "AzureMonitorWindowsAgent"
  virtual_machine_id         = data.azurerm_virtual_machine.vm.id
  publisher                  = "Microsoft.Azure.Monitor"
  type                       = "AzureMonitorWindowsAgent"
  type_handler_version       = "1.0"
  auto_upgrade_minor_version = true
  tags                       = local.tags
}

output "step9_verify" {
  description = "Step 9 runbook verification commands"
  value = <<-EOT
    # Confirm Log Analytics is receiving heartbeats (run in LAW → Logs):
    # Heartbeat | where Computer == "${var.vm_name}" | summarize max(TimeGenerated)

    # Confirm all alert rules are enabled
    az monitor metrics alert list --resource-group ${local.rg} -o table
    az monitor scheduled-query list --resource-group ${local.rg} -o table

    # Confirm action group is active
    az monitor action-group show --name fsamuat-infra-alerts --resource-group ${local.rg} -o json

    # Confirm Monitor Agent running on VM (PowerShell on VM):
    # Get-Service -Name AzureMonitorAgent
  EOT
}
