###############################################################################
# step4_network.tf
# Runbook: Virtual Network, NSGs & NICs
# Backup method: ARM/Bicep IaC + NSG flow log export
# Frequency: On-change (IaC pipeline deploy) | Dependency: Step 3
#
# Terraform OWNS: Network Watcher, NSG flow logs, VNet + NSG diagnostic settings
# Terraform READS: data.azurerm_virtual_network.vnet, data.azurerm_network_security_group.nsg
###############################################################################

# Network Watcher – required for NSG flow logs
resource "azurerm_network_watcher" "nw" {
  name                = "fsamuat-network-watcher"
  location            = local.loc
  resource_group_name = local.rg
  tags                = local.tags
}

# NSG flow logs → existing Storage + Log Analytics
resource "azurerm_network_watcher_flow_log" "nsg_flow_log" {
  network_watcher_name      = azurerm_network_watcher.nw.name
  resource_group_name       = local.rg
  name                      = "fsamuat-nsg-flowlog"
  network_security_group_id = data.azurerm_network_security_group.nsg.id
  storage_account_id        = data.azurerm_storage_account.backup_sa.id
  enabled                   = true

  retention_policy {
    enabled = true
    days    = 30
  }

  traffic_analytics {
    enabled               = true
    workspace_id          = data.azurerm_log_analytics_workspace.law.workspace_id
    workspace_region      = data.azurerm_log_analytics_workspace.law.location
    workspace_resource_id = data.azurerm_log_analytics_workspace.law.id
    interval_in_minutes   = 10
  }

  tags = local.tags
}

# Diagnostic settings: NSG → Log Analytics
resource "azurerm_monitor_diagnostic_setting" "nsg_diag" {
  name                       = "nsg-diag-dr"
  target_resource_id         = data.azurerm_network_security_group.nsg.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.law.id

  enabled_log { category = "NetworkSecurityGroupEvent" }
  enabled_log { category = "NetworkSecurityGroupRuleCounter" }
}

# Diagnostic settings: VNet → Log Analytics
resource "azurerm_monitor_diagnostic_setting" "vnet_diag" {
  name                       = "vnet-diag-dr"
  target_resource_id         = data.azurerm_virtual_network.vnet.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.law.id

  metric { category = "AllMetrics"; enabled = true }
}

output "step4_verify" {
  description = "Step 4 runbook verification commands"
  value = <<-EOT
    # Confirm NSG flow logs are active
    az network watcher flow-log show \
      --location ${local.loc} --name fsamuat-nsg-flowlog -o json

    # Confirm VNet subnets and NSG associations intact
    az network vnet show --name ${var.vnet_name} --resource-group ${local.rg} \
      --query "subnets[].{Name:name,NSG:networkSecurityGroup.id,Prefix:addressPrefix}" -o table
  EOT
}
