###############################################################################
# step3_storage.tf
# Runbook: Storage Account – Backup Staging
# Backup method: Azure Backup staging (RSV-managed) + ZRS geo-redundancy
# Frequency: Matches RSV policy (daily full, incremental) | Dependency: Step 2
#
# Terraform OWNS: lifecycle management policy, diagnostic logs, availability alert
# Terraform READS: data.azurerm_storage_account.backup_sa
###############################################################################

# Lifecycle policy aligned to RSV daily/incremental retention
resource "azurerm_storage_management_policy" "backup_lifecycle" {
  storage_account_id = data.azurerm_storage_account.backup_sa.id

  rule {
    name    = "backup-staging-retention"
    enabled = true

    filters {
      blob_types   = ["blockBlob"]
      prefix_match = ["backup/"]
    }

    actions {
      base_blob {
        tier_to_cool_after_days_since_modification_greater_than    = 7   # incremental → cool
        tier_to_archive_after_days_since_modification_greater_than = 30  # full → archive
        delete_after_days_since_modification_greater_than          = 90  # matches RSV retention
      }
      snapshot {
        delete_after_days_since_creation_greater_than = 30
      }
    }
  }
}

# Diagnostic logs: storage → Log Analytics
resource "azurerm_monitor_diagnostic_setting" "storage_diag" {
  name                       = "storage-diag-dr"
  target_resource_id         = "${data.azurerm_storage_account.backup_sa.id}/blobServices/default"
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.law.id

  enabled_log { category = "StorageRead" }
  enabled_log { category = "StorageWrite" }
  enabled_log { category = "StorageDelete" }
  metric      { category = "Transaction"; enabled = true }
}

# Alert: storage availability drop
resource "azurerm_monitor_metric_alert" "storage_availability" {
  name                = "storage-availability-drop"
  resource_group_name = local.rg
  scopes              = [data.azurerm_storage_account.backup_sa.id]
  description         = "Step 3: Storage availability < 100% – backup staging at risk"
  severity            = 2
  frequency           = "PT5M"
  window_size         = "PT15M"

  criteria {
    metric_namespace = "Microsoft.Storage/storageAccounts"
    metric_name      = "Availability"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 100
  }

  action { action_group_id = azurerm_monitor_action_group.infra_ag.id }
}

output "step3_verify" {
  description = "Step 3 runbook verification commands"
  value = <<-EOT
    # Confirm replication = ZRS
    az storage account show --name ${var.storage_account_name} --resource-group ${local.rg} \
      --query "{replication:sku.name, tier:sku.tier}" -o json

    # Confirm lifecycle policy applied
    az storage account management-policy show \
      --account-name ${var.storage_account_name} --resource-group ${local.rg} -o json
  EOT
}
