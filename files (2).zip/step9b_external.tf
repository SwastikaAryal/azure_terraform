###############################################################################
# step9b_external.tf
# Runbook: UAT Interfaces – External Connectivity Verify
# Backup method: No backup/restore – external services (Vertex, AWS Cognito, AWS API)
# Frequency: N/A – External services | Dependency: Step 9
#
# Terraform OWNS: outbound connectivity failure alert
# Terraform READS: data.azurerm_network_security_group.nsg
#
# NOTE: External services are not managed here. Connectivity verify only.
###############################################################################

# Alert: outbound HTTPS denies detected in NSG flow logs
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "external_connectivity" {
  name                 = "external-connectivity-failure"
  location             = local.loc
  resource_group_name  = local.rg
  severity             = 2
  description          = "Step 9b: Outbound HTTPS to Vertex/Cognito/AWS API being blocked"
  evaluation_frequency = "PT15M"
  window_duration      = "PT15M"
  scopes               = [data.azurerm_log_analytics_workspace.law.id]

  criteria {
    query = <<-QUERY
      AzureDiagnostics
      | where Category == "NetworkSecurityGroupFlowEvent"
      | where FlowStatus_s == "D"
      | where DestPort_d == 443
      | where Direction_s == "O"
    QUERY
    time_aggregation_method = "Count"
    threshold               = 10
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action { action_groups = [azurerm_monitor_action_group.infra_ag.id] }
}

output "step9b_verify" {
  description = "Step 9b runbook verification commands"
  value = <<-EOT
    # Run inside the VM (PowerShell) to test all 3 external endpoints:

    $endpoints = @(
      "https://cognito-idp.us-east-1.amazonaws.com",    # AWS Cognito
      "https://aiplatform.googleapis.com",               # Vertex AI
      "https://execute-api.us-east-1.amazonaws.com"     # AWS API Gateway
    )
    foreach ($ep in $endpoints) {
      try {
        $r = Invoke-WebRequest -Uri $ep -UseBasicParsing -TimeoutSec 10
        Write-Host "OK  [$($r.StatusCode)] $ep"
      } catch {
        Write-Host "FAIL $ep - $($_.Exception.Message)"
      }
    }

    # If any fail – check NSG outbound rules:
    az network nsg rule list --nsg-name ${var.nsg_name} --resource-group ${local.rg} \
      --query "[?direction=='Outbound'].{Name:name,Priority:priority,Access:access,Port:destinationPortRange}" -o table
  EOT
}
