###############################################################################
# data_sources.tf
#
# Every resource here already exists in the Azure portal.
# Data blocks = READ ONLY. Terraform will NEVER modify or destroy these.
# All step files reference these data blocks to attach DR/backup config.
###############################################################################

# Step 1 – Recovery Services Vault
data "azurerm_recovery_services_vault" "rsv" {
  name                = var.rsv_name
  resource_group_name = local.rg
}

# Step 2 – Key Vault
data "azurerm_key_vault" "kv" {
  name                = var.keyvault_name
  resource_group_name = local.rg
}

# Step 3 – Storage Account
data "azurerm_storage_account" "backup_sa" {
  name                = var.storage_account_name
  resource_group_name = local.rg
}

# Step 4 – VNet and NSG
data "azurerm_virtual_network" "vnet" {
  name                = var.vnet_name
  resource_group_name = local.rg
}

data "azurerm_network_security_group" "nsg" {
  name                = var.nsg_name
  resource_group_name = local.rg
}

data "azurerm_subnet" "app_subnet" {
  name                 = "app-subnet"
  virtual_network_name = var.vnet_name
  resource_group_name  = local.rg
}

# Steps 5 + 6 – VM (OS disk C:\ and data disk E:\ are both covered by VM backup job)
data "azurerm_virtual_machine" "vm" {
  name                = var.vm_name
  resource_group_name = local.rg
}

# Step 7 – Load Balancer
data "azurerm_lb" "lb" {
  name                = var.lb_name
  resource_group_name = local.rg
}

# Step 8 – SSL Certificate inside Key Vault
data "azurerm_key_vault_certificate" "ssl_cert" {
  name         = var.ssl_cert_name
  key_vault_id = data.azurerm_key_vault.kv.id
}

# Step 9 – Log Analytics Workspace
data "azurerm_log_analytics_workspace" "law" {
  name                = var.law_name
  resource_group_name = local.rg
}
