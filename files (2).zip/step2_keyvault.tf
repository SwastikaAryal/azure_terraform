###############################################################################
# step2_keyvault.tf
# Runbook: Key Vault – Secrets & Access
# Backup method: KV soft-delete + purge-protection (geo-redundant, auto-replication)
# Frequency: Continuous | Dependency: Step 1
#
# Terraform OWNS: MI role assignment, KV admin roles, diagnostic logs, availability alert
# Terraform READS: data.azurerm_key_vault.kv
###############################################################################

# App Managed Identity → Key Vault Secrets User on existing KV
# If this is removed in portal → terraform apply re-creates it
resource "azurerm_role_assignment" "app_mi_kv_secrets_user" {
  scope                = data.azurerm_key_vault.kv.id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = var.app_managed_identity_principal_id
}

# KV Admin for DBA / infra team to re-populate secrets after restore
resource "azurerm_role_assignment" "kv_admin" {
  for_each             = toset(var.admin_object_ids)
  scope                = data.azurerm_key_vault.kv.id
  role_definition_name = "Key Vault Administrator"
  principal_id         = each.value
}

# Diagnostic logs: KV audit events → existing Log Analytics
resource "azurerm_monitor_diagnostic_setting" "kv_diag" {
  name                       = "kv-diag-dr"
  target_resource_id         = data.azurerm_key_vault.kv.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.law.id

  enabled_log { category = "AuditEvent" }
  metric      { category = "AllMetrics"; enabled = true }
}

# Alert: KV availability drop
resource "azurerm_monitor_metric_alert" "kv_availability" {
  name                = "kv-availability-drop"
  resource_group_name = local.rg
  scopes              = [data.azurerm_key_vault.kv.id]
  description         = "Step 2: KV availability < 100% – check soft-delete/purge state"
  severity            = 1
  frequency           = "PT5M"
  window_size         = "PT15M"

  criteria {
    metric_namespace = "Microsoft.KeyVault/vaults"
    metric_name      = "Availability"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 100
  }

  action { action_group_id = azurerm_monitor_action_group.infra_ag.id }
}

output "step2_verify" {
  description = "Step 2 runbook verification commands"
  value = <<-EOT
    # Confirm KV not purged and purge-protection on
    az keyvault show --name ${var.keyvault_name} --resource-group ${local.rg} \
      --query "{softDelete:properties.enableSoftDelete, purgeProtection:properties.enablePurgeProtection}" -o json

    # List secrets (confirm sql-sa-password, db-connection-string exist)
    az keyvault secret list --vault-name ${var.keyvault_name} -o table

    # Check PE connection state = Approved
    az network private-endpoint list --resource-group ${local.rg} \
      --query "[?contains(name,'kvprivatebmw')].{Name:name,State:privateLinkServiceConnections[0].privateLinkServiceConnectionState.status}" -o table

    # Test MI access (run inside VM – PowerShell):
    # $t = (Invoke-RestMethod "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://vault.azure.net" -Headers @{Metadata="true"}).access_token
    # Invoke-RestMethod "https://${var.keyvault_name}.vault.azure.net/secrets/sql-sa-password?api-version=7.3" -Headers @{Authorization="Bearer $t"}

    # If MI access fails – re-run:
    # terraform apply -target=azurerm_role_assignment.app_mi_kv_secrets_user
  EOT
}
