###############################################################################
# step5_6_vm_backup.tf
# Runbook Step 5: VM OS Disk C:\ – crash-consistent + app-consistent snapshots
# Runbook Step 6: VM Data Disk E:\ – disk snapshot included in same VM backup job
# Backup method: Azure VM Backup via RSV
# Frequency: Daily (RSV VM backup policy) | Dependency: Step 4 (Step5), Step 5 (Step6)
#
# Terraform OWNS: VM daily backup policy, VM backup protection registration,
#                 VM heartbeat alert, CPU alert
# Terraform READS: data.azurerm_virtual_machine.vm, data.azurerm_recovery_services_vault.rsv
#
# NOTE: One backup job covers BOTH C:\ (Step 5) and E:\ (Step 6).
#       RSV captures all attached disks automatically in the VM backup job.
###############################################################################

# Daily VM backup policy – covers OS disk C:\ and data disk E:\ in one job
resource "azurerm_backup_policy_vm" "vm_daily_policy" {
  name                = "fsam-uat-vm-daily-policy"
  resource_group_name = local.rg
  recovery_vault_name = data.azurerm_recovery_services_vault.rsv.name

  timezone = "UTC"

  backup {
    frequency = "Daily"
    time      = "02:00"
  }

  retention_daily   { count = 30 }
  retention_weekly  { count = 12; weekdays = ["Sunday"] }
  retention_monthly { count = 12; weekdays = ["Sunday"]; weeks = ["First"] }

  instant_restore_retention_days = 2   # app-consistent snapshot retention
}

# Register existing VM for backup in existing RSV
# If backup protection is removed → terraform apply re-registers it
resource "azurerm_backup_protected_vm" "vm_backup" {
  resource_group_name = local.rg
  recovery_vault_name = data.azurerm_recovery_services_vault.rsv.name
  source_vm_id        = data.azurerm_virtual_machine.vm.id
  backup_policy_id    = azurerm_backup_policy_vm.vm_daily_policy.id
}

# Alert: VM heartbeat missing (VM deleted or down)
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "vm_heartbeat" {
  name                 = "vm-heartbeat-missing"
  location             = local.loc
  resource_group_name  = local.rg
  severity             = 1
  description          = "Step 5: VM heartbeat missing for 5 min – may be deleted or crashed"
  evaluation_frequency = "PT5M"
  window_duration      = "PT5M"
  scopes               = [data.azurerm_log_analytics_workspace.law.id]

  criteria {
    query = <<-QUERY
      Heartbeat
      | where Computer == "${var.vm_name}"
      | summarize LastHeartbeat = max(TimeGenerated)
      | where LastHeartbeat < ago(5m)
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action { action_groups = [azurerm_monitor_action_group.infra_ag.id] }
}

# Alert: VM CPU > 90%
resource "azurerm_monitor_metric_alert" "vm_cpu" {
  name                = "vm-cpu-high"
  resource_group_name = local.rg
  scopes              = [data.azurerm_virtual_machine.vm.id]
  description         = "Step 5: VM CPU > 90% for 5 min"
  severity            = 2
  frequency           = "PT1M"
  window_size         = "PT5M"

  criteria {
    metric_namespace = "Microsoft.Compute/virtualMachines"
    metric_name      = "Percentage CPU"
    aggregation      = "Average"
    operator         = "GreaterThan"
    threshold        = 90
  }

  action { action_group_id = azurerm_monitor_action_group.infra_ag.id }
}

output "step5_6_verify" {
  description = "Steps 5 + 6 runbook verification commands"
  value = <<-EOT
    # Confirm VM backup is registered (status = Healthy)
    az backup item show \
      --resource-group ${local.rg} --vault-name ${var.rsv_name} \
      --container-name "iaasvmcontainer;iaasvmcontainerv2;${local.rg};${var.vm_name}" \
      --name "vm;iaasvmcontainerv2;${local.rg};${var.vm_name}" \
      --backup-management-type AzureIaasVM -o json

    # Latest restore point (should be < 24 hrs for daily policy)
    az backup recoverypoint list \
      --resource-group ${local.rg} --vault-name ${var.rsv_name} \
      --container-name "iaasvmcontainer;iaasvmcontainerv2;${local.rg};${var.vm_name}" \
      --item-name "vm;iaasvmcontainerv2;${local.rg};${var.vm_name}" -o table

    # TO RESTORE VM if deleted:
    az backup restore restore-disks \
      --resource-group ${local.rg} --vault-name ${var.rsv_name} \
      --container-name "iaasvmcontainer;iaasvmcontainerv2;${local.rg};${var.vm_name}" \
      --item-name "vm;iaasvmcontainerv2;${local.rg};${var.vm_name}" \
      --rp-name <restore-point-name> \
      --storage-account ${var.storage_account_name} \
      --restore-to-staging-storage-account
  EOT
}
