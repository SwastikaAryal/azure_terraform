# =================================================================================================
# File: terraform/env/ccg-tst/terraform.tfvars
# Matches FS-SANDBOX resource group — CCG TST environment
# =================================================================================================

cloud_region    = "eastus"
environment     = "dev"
subscription_id = "4cda8977-68ea-4ca5-aa6a-fae45e7e98f3"
tenant_id       = "ce849bab-cc1c-465b-b62e-18f07c9ac198"

global_config_base = {
  customer_prefix = "fsam"
  env             = "tst"
  product_id      = "SWP-000"
  appd_id         = "APPD-326047"
  app_name        = "AF"
  costcenter      = "1845"
  tags = {
    customer_prefix = "fsam"
    env             = "tst"
    owner           = "FG-AM-32"
    appd_id         = "APPD-326047"
    app_name        = "AF"
  }
}

# New resource group for CCG tst deployment
resource_group_name_override = "FS-SANDBOX"

# Networking
virtual_network_name     = "VNET-SPOKE-EUS-12815"
vnet_resource_group_name = "RG-VNET-SPOKE-EUS-12815"
app_subnet_name          = "Subnet-1"
allowed_ips              = ["10.81.118.0/26"]

# VM credentials and image
vm_admin_username                  = "fsamdevmadmin"
vm_image_source_id                 = "/subscriptions/4b4ad43c-6665-4f59-afb4-562f560bb999/resourceGroups/Image_Offers/providers/Microsoft.Compute/galleries/Iaas_OS_Images/images/bmw-win-srv-2022_ae/versions/3.250509.1747380865"
admin_password_key_vault_secret_id = "$vmcompute@123"

# Must match deployed VMs — AutomaticByPlatform confirmed from ARM export
windows_patch_mode  = "AutomaticByPlatform"
secure_boot_enabled = false
vtpm_enabled        = false

# VM names use "tst" suffix for sandbox environment
vm_configurations = [
  { custom_suffix = "fs-tst-app1", size = "Standard_F8s_v2", extensions_to_install = ["AADLogin", "MDE"] },
  { custom_suffix = "fs-tst-app2", size = "Standard_F8s_v2", extensions_to_install = ["AADLogin", "MDE"] },
  { custom_suffix = "fs-tst-web1", size = "Standard_F8s_v2", extensions_to_install = ["IIS", "AADLogin", "MDE"] },
  { custom_suffix = "fs-tst-web2", size = "Standard_F8s_v2", extensions_to_install = ["IIS", "AADLogin", "MDE"] }
]

# Disk names updated for tst VMs
standalone_managed_disks_config = [
  { vm_custom_suffix = "fs-tst-app1", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
  { vm_custom_suffix = "fs-tst-app2", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
  { vm_custom_suffix = "fs-tst-web1", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
  { vm_custom_suffix = "fs-tst-web2", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" }
]

# No VMSS in tst environment
create_vmss = false

# Only "file" PE exists
enable_storage_private_endpoints = true

# No KV private endpoint
enable_keyvault_private_endpoint = false

# Automation "Webhook" PE
enable_automation_private_endpoint = true

# Module naming suffixes — all updated to use "tst" instead of "ccg"
# Resulting resource names:
#   fsamtst-uai      (central managed identity)
#   fsamtst-aa-auto  (automation account)
#   fsamtst-law      (log analytics workspace)
#   fsamtst-aapin    (application insights)
#   fsamtst-lb-app   (load balancer)
#   fsamtst-kv       (key vault)
#   fsamtststprivatebmw (storage account)
central_managed_identity_custom_suffix = "uai"
automation_account_custom_suffix       = "auto"
log_analytics_custom_suffix            = "law"
app_insights_custom_suffix             = "aapin"
load_balancer_custom_suffix            = "app"
key_vault_custom_suffix                = "kv"
storage_account_main_custom_suffix     = "stprivatebmw"

log_analytics_sku               = "PerGB2018"
log_analytics_retention_in_days = 90
app_insights_application_type   = "web"

automation_account_sku_name = "Basic"
# Set to [] — modules already exist in portal, managed outside Terraform
automation_module_names = []

# All 3 connection types from ARM export
automation_account_connection_types_config = [
  {
    name      = "Azure"
    is_global = true
    fields = [
      { name = "AutomationCertificateName", type = "System.String", is_encrypted = false, is_optional = false },
      { name = "SubscriptionID",            type = "System.String", is_encrypted = false, is_optional = false }
    ]
  },
  {
    name      = "AzureClassicCertificate"
    is_global = true
    fields = [
      { name = "SubscriptionName",     type = "System.String", is_encrypted = false, is_optional = false },
      { name = "SubscriptionId",       type = "System.String", is_encrypted = false, is_optional = false },
      { name = "CertificateAssetName", type = "System.String", is_encrypted = false, is_optional = false }
    ]
  },
  {
    name      = "AzureServicePrincipal"
    is_global = true
    fields = [
      { name = "ApplicationId",         type = "System.String", is_encrypted = false, is_optional = false },
      { name = "TenantId",              type = "System.String", is_encrypted = false, is_optional = false },
      { name = "CertificateThumbprint", type = "System.String", is_encrypted = false, is_optional = false },
      { name = "SubscriptionId",        type = "System.String", is_encrypted = false, is_optional = false }
    ]
  }
]

storage_account_main_config = {
  tier                            = "Standard"
  replication_type                = "ZRS"
  allow_blob_public_access        = false
  public_network_access_enabled   = true
  shared_access_key_enabled       = true
  min_tls_version                 = "TLS1_2"
  default_to_oauth_authentication = true
}

recovery_services_vault_custom_suffix = "rsv"
recovery_services_vault_sku           = "RS0"
recovery_services_vault_config_flags = {
  soft_delete_enabled = true
  storage_mode_type   = "GeoRedundant"
}
vm_backup_policy_default_config = {
  name                  = "fsam-tst-rsv-vm"
  frequency             = "Daily"
  time                  = "23:00"
  timezone              = "UTC"
  retention_daily_count = 30
}

key_vault_sku_name = "standard"
key_vault_config_flags = {
  enabled_for_disk_encryption = true
  purge_protection_enabled    = true
  soft_delete_retention_days  = 90
}

enable_database_migration_service = false
