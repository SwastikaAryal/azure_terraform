# =================================================================================================
# File: terraform/env/uat/outputs.tf
# =================================================================================================

output "environment_deployed" {
  description = "The environment name that has been deployed."
  value       = local.global_config_for_commons.env
}

output "application_resource_group_name" {
  description = "Name of the resource group for the application."
  value       = azurerm_resource_group.application_rg.name
}

output "application_resource_group_id" {
  description = "ID of the resource group for the application."
  value       = azurerm_resource_group.application_rg.id
}

output "central_managed_identity_details" {
  description = "Details of the central managed identity module."
  value = {
    id           = module.central_managed_identity.id
    principal_id = module.central_managed_identity.principal_id
    client_id    = module.central_managed_identity.client_id
    name         = module.central_managed_identity.name
  }
}

output "application_key_vault_details" {
  description = "Details of the application Key Vault."
  value = {
    id   = module.application_key_vault.id
    uri  = module.application_key_vault.uri
    name = module.application_key_vault.name
  }
  sensitive = true
}

output "application_storage_account_details" {
  description = "Details of the application storage account."
  value = {
    id   = module.application_storage_account.id
    name = module.application_storage_account.name
  }
}

# output "application_sql_managed_instance_details" {
#   description = "Details of the application SQL Managed Instance."
#   value = {
#     id   = module.application_sql_managed_instance.id
#     name = module.application_sql_managed_instance.name
#     fqdn = module.application_sql_managed_instance.fqdn
#   }
# }

output "application_load_balancer_details" {
  description = "Details of the application load balancer."
  value = {
    id                       = module.application_load_balancer.id
    name                     = module.application_load_balancer.name
    frontend_ip_config_names = [for config in module.application_load_balancer.frontend_ip_configurations : config.name]
  }
}

output "application_log_analytics_workspace_id" {
  description = "ID of the Log Analytics Workspace."
  value       = module.application_log_analytics.log_analytics_id
}

output "application_log_analytics_details" {
  description = "Details of the application Log Analytics workspace."
  value = {
    workspace_id = module.application_log_analytics.log_analytics_workspace_id
    resource_id  = module.application_log_analytics.log_analytics_id
    name         = module.application_log_analytics.log_analytics_name
  }
}

output "application_insights_details" {
  description = "Details of the application Application Insights instance."
  value = {
    id                  = module.application_log_analytics.app_insights_id
    name                = module.application_log_analytics.app_insights_name
    instrumentation_key = module.application_log_analytics.app_insights_instrumentation_key
    connection_string   = module.application_log_analytics.app_insights_connection_string
  }
  sensitive = true
}

output "application_automation_account_details" {
  description = "Details of the application Automation Account."
  value = {
    id   = module.application_automation_account.id
    name = module.application_automation_account.name
  }
}

# output "application_recovery_services_vault_details" {
#   description = "Details of the application Recovery Services Vault."
#   value = {
#     id   = module.application_recovery_services_vault.id
#     name = module.application_recovery_services_vault.name
#   }
# }

# output "application_vm_outputs" {
#   description = "Consolidated outputs for each virtual machine in the application."
#   value = {
#     for vm_key, vm_module in module.application_vms :
#     vm_key => {
#       id                            = vm_module.id
#       name                          = vm_module.name
#       vm_resource_id_for_attachment = vm_module.vm_resource_id_for_attachment
#       nic_id                        = vm_module.nic_id
#     }
#   }
# }

output "application_vm_ids" {
  description = "The IDs of the deployed virtual machines."
  value = {
    for vm_key, vm_module in module.application_vms :
    vm_key => vm_module.id
  }
}

output "application_vm_names" {
  description = "The names of the deployed virtual machines."
  value = {
    for vm_key, vm_module in module.application_vms :
    vm_key => vm_module.name
  }
}

output "application_vm_resource_ids" {
  description = "Resource IDs of the virtual machines for attachment."
  value = {
    for vm_key, vm_module in module.application_vms :
    vm_key => vm_module.vm_resource_id_for_attachment
  }
}

output "application_vm_nic_ids" {
  value = {
    for vm_key, vm_module in module.application_vms :
    vm_key => vm_module.nic_id
  }
}


output "application_vmss_details" {
  value = var.create_vmss && contains(keys(module.application_vmss), "vmss1") ? module.application_vmss["vmss1"] : null
}

output "app_subnet_data_source_details" {
  description = "Details of the application subnet from the data source."
  value = {
    id               = data.azurerm_subnet.app_subnet.id
    name             = data.azurerm_subnet.app_subnet.name
    address_prefixes = data.azurerm_subnet.app_subnet.address_prefixes
  }
}

# output "db_subnet_data_source_details" {
#   description = "Details of the database subnet from the data source."
#   value = {
#     id               = data.azurerm_subnet.db_subnet.id
#     name             = data.azurerm_subnet.db_subnet.name
#     address_prefixes = data.azurerm_subnet.db_subnet.address_prefixes
#   }
# }

# output "dms_details" {
#   description = "Details of the Azure Database Migration Service, if created."
#   value       = var.enable_database_migration_service && length(azurerm_database_migration_service.dms) > 0 ? azurerm_database_migration_service.dms[0] : null
# }

output "storage_private_endpoint_ips" {
  description = "Private IP addresses for storage account private endpoints."
  value = {
    for k, pe_module in module.application_storage_private_endpoints :
    k => pe_module.private_ip_address
  }
  sensitive = true
}

output "keyvault_private_endpoint_ip" {
  description = "Private IP address for the Key Vault private endpoint."
  value       = var.enable_keyvault_private_endpoint && length(module.key_vault_private_endpoint) > 0 ? module.key_vault_private_endpoint[0].private_ip_address : null
  sensitive   = true
}

# output "automation_private_endpoint_ip" {
#   description = "Private IP address for the Automation Account private endpoint."
#   value       = var.enable_automation_private_endpoint && length(module.automation_agentsvc_private_endpoint) > 0 ? module.automation_agentsvc_private_endpoint[0].private_ip_address : null
#   sensitive   = true
# }

output "automation_private_endpoint_ips" {
  value = var.enable_automation_private_endpoint ? { for key in ["Webhook"] : key => contains(keys(module.automation_agentsvc_private_endpoint), key) ? module.automation_agentsvc_private_endpoint[key].private_ip_address : null } : {}
}

# output "vm_extension_targets" {
#   value = {
#     octopus = keys(azurerm_virtual_machine_extension.octopus_tentacle)
#     iis     = keys(azurerm_virtual_machine_extension.iis_installer)
#     mde     = keys(azurerm_virtual_machine_extension.mde_windows)
#   }
# }

output "vm_extension_targets" {
  value = {
    # combined = keys(azurerm_virtual_machine_extension.custom_script_combined)
    mde      = keys(azurerm_virtual_machine_extension.mde_windows)
    monitor  = keys(azurerm_virtual_machine_extension.azure_monitor_agent)
    tentacle = keys(azurerm_virtual_machine_extension.octopus_tentacle)
    iis      = keys(azurerm_virtual_machine_extension.iis_installer)
    vmaccess = keys(azurerm_virtual_machine_extension.enable_vm_access)
    aadlogin = keys(azurerm_virtual_machine_extension.aad_login)
  }
}

# output "vm_extension_deployments" {
#   value = {
#     for vm_key, deployment in azurerm_resource_group_template_deployment.vm_extensions :
#     vm_key => deployment.name
#   }
# }
