# =================================================================================================
# File: terraform/env/uat/variables.tf
# =================================================================================================

variable "environment" {
  description = "The deployment environment (e.g., cleanconfig)."
  type        = string
}

variable "subscription_id" {
  description = "Azure Subscription ID."
  type        = string
  sensitive   = true
}

variable "tenant_id" {
  description = "Azure Tenant ID."
  type        = string
  sensitive   = true
}

variable "cloud_region" {
  description = "Azure region for the deployment (e.g., 'eastus')."
  type        = string
}

variable "global_config_base" {
  description = "Base global configuration for BMW modules."
  type = object({
    customer_prefix = string
    env             = string
    product_id      = string
    appd_id         = string
    app_name        = string
    costcenter      = string
    tags            = map(string)
  })
}

variable "custom_tags_override" {
  description = "Custom tags to merge with commons and fixed tags."
  type        = map(string)
  default     = {}
}

variable "resource_group_name_override" {
  description = "Optional override for the resource group name. If set, this exact name will be used."
  type        = string
  default     = ""
}

variable "virtual_network_name" {
  description = "Name of the existing Virtual Network where resources and Private Endpoints will be deployed."
  type        = string
  default     = "VNET-SPOKE-EUS-10882"
}

variable "vnet_resource_group_name" {
  description = "Resource group name of the existing Virtual Network."
  type        = string
}

variable "app_subnet_name" {
  description = "Name of the existing application subnet to be used by resources and for Private Endpoints."
  type        = string
}

# variable "db_subnet_name" {
#   description = "Name of the existing database (SQL MI) subnet to be used."
#   type        = string
# }

variable "allowed_ips" {
  description = "List of allowed IP CIDRs for Key Vault access"
  type        = list(string)
}

variable "vm_image_source_id" {
  description = "Source image ID for Windows VMs."
  type        = string
}

variable "vm_admin_username" {
  description = "Admin username for VMs."
  type        = string
}

variable "vm_admin_password_kv_secret_name" {
  description = "Name of the Key Vault secret for VM admin password. If null, a password will be generated."
  type        = string
  default     = "vmAdminPassword"
}

variable "admin_password_key_vault_secret_id" {
  description = "Password for the VMs."
  type        = string
  default     = "$vmcompute@123"
}


variable "vm_configurations" {
  description = "Configuration for the virtual machines."
  type = list(object({
    custom_suffix         = string
    size                  = string
    extensions_to_install = optional(list(string), [])
  }))
  default = [
    { custom_suffix = "fs-ccg-web1", size = "Standard_F8s_v2", extensions_to_install = ["IIS", "MDE", "OctopusDeploy", "Monitoring", "EnableVMAccess", "PartitionDisk", "AADLogin"] },
    { custom_suffix = "fs-ccg-web2", size = "Standard_F8s_v2", extensions_to_install = ["IIS", "MDE", "OctopusDeploy", "Monitoring", "EnableVMAccess", "PartitionDisk", "AADLogin"] },
    { custom_suffix = "fs-ccg-app1", size = "Standard_F8s_v2", extensions_to_install = ["MDE", "OctopusDeploy", "Monitoring", "EnableVMAccess", "PartitionDisk", "AADLogin"] },
    { custom_suffix = "fs-ccg-app2", size = "Standard_F8s_v2", extensions_to_install = ["MDE", "OctopusDeploy", "Monitoring", "EnableVMAccess", "PartitionDisk", "AADLogin"] }
  ]
}

# variable "network_interface_ids" {
#   type        = list(string)
#   description = " (Required). A list of Network Interface IDs which should be attached to this Virtual Machine. The first Network Interface ID in this list will be the Primary Network Interface on the Virtual Machine."
# }

variable "windows_patch_mode" {
  type        = string
  description = "Specifies the mode of in-guest patching to this Windows Virtual Machine. Possible values are `Manual`, `AutomaticByOS` and `AutomaticByPlatform`"
  default     = "AutomaticByOS"
}

variable "standalone_managed_disks_config" {
  description = "Configuration for standalone managed disks."
  type = list(object({
    vm_custom_suffix     = string
    disk_custom_suffix   = string
    disk_size_gb         = number
    lun                  = number
    caching              = string
    storage_account_type = string
  }))
  default = [
    { vm_custom_suffix = "fs-ccg-web1", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
    { vm_custom_suffix = "fs-ccg-web2", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
    { vm_custom_suffix = "fs-ccg-app1", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
    { vm_custom_suffix = "fs-ccg-app2", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
  ]

}

variable "key_vault_custom_suffix" {
  type    = string
  default = "kv"
}

variable "key_vault_sku_name" {
  type    = string
  default = "standard"
}

variable "key_vault_config_flags" {
  type = object({
    enabled_for_disk_encryption = optional(bool, true)
    purge_protection_enabled    = optional(bool, true)
    soft_delete_retention_days  = optional(number, 90)
  })
  default = { enabled_for_disk_encryption = true, purge_protection_enabled = true, soft_delete_retention_days = 90 }
}

variable "storage_account_main_custom_suffix" {
  type    = string
  default = "appdata"
}

variable "storage_account_main_config" {
  type = object({
    tier                            = string
    replication_type                = string
    allow_blob_public_access        = optional(bool, false)
    public_network_access_enabled   = optional(bool, false)
    shared_access_key_enabled       = optional(bool, true)
    min_tls_version                 = optional(string, "TLS1_2")
    default_to_oauth_authentication = optional(bool, true)
  })
  default = { tier = "Standard", replication_type = "ZRS", allow_blob_public_access = false, public_network_access_enabled = false, shared_access_key_enabled = true, min_tls_version = "TLS1_2", default_to_oauth_authentication = true }
}

variable "enable_storage_private_endpoints" {
  type    = bool
  default = true
}

# variable "sql_mi_custom_suffix" {
#   type    = string
#   default = "sqlmi"
# }

# variable "sql_mi_administrator_login" {
#   type    = string
#   default = "sfamadmindev"
# }

# variable "sql_mi_administrator_password" {
#   type      = string
#   sensitive = true
# }

# variable "sql_mi_config_details" {
#   type = object({
#     sku_name                       = string
#     vcores                         = number
#     storage_size_in_gb             = number
#     license_type                   = string
#     maintenance_configuration_name = string
#     collation                      = optional(string, "SQL_Latin1_General_CP1_CI_AS")
#     proxy_override                 = optional(string, "Proxy")
#     public_data_endpoint_enabled   = optional(bool, false)
#     timezone_id                    = optional(string, "Eastern Standard Time")
#     storage_account_type           = optional(string, "ZRS")
#     databases                      = list(object({ name = string, collation = optional(string, "SQL_Latin1_General_CP1_CI_AS") }))
#   })
#   default = { sku_name = "GP_Gen5", vcores = 4, storage_size_in_gb = 256, license_type = "LicenseIncluded", maintenance_configuration_name = "SQL_EastUS_MI_2", databases = [{ name = "sfam_dev_db1" }, { name = "sfam_dev_db2" }, { name = "sfam_dev_POC_TEST)" }, { name = "sfam_dev_bobcatexchangedb)" }] }
# }

# variable "sql_mi_ad_admin_config" {
#   type = object({
#     login_username              = string
#     object_id                   = string
#     azuread_authentication_only = optional(bool, false)
#   })
#   default = {
#     login_username              = null
#     object_id                   = null
#     azuread_authentication_only = false
#   }
# }

# variable "sql_mi_tde_key_vault_key_id" {
#   type    = string
#   default = null
# }

# variable "sql_mi_tde_key_vault_key_id" {
#   type    = bool
#   default = true
# }

variable "log_analytics_custom_suffix" {
  type    = string
  default = "log"
}

variable "log_analytics_sku" {
  type    = string
  default = "PerGB2018"
}

variable "log_analytics_retention_in_days" {
  type    = number
  default = 90
}

variable "app_insights_custom_suffix" {
  type    = string
  default = "aapin"
}

variable "app_insights_application_type" {
  type    = string
  default = "web"
}

variable "automation_account_custom_suffix" {
  type    = string
  default = "auto"
}

variable "automation_account_sku_name" {
  type    = string
  default = "Basic"
}

variable "automation_module_names" {
  type    = list(string)
  default = ["Az.Accounts", "Az.Compute", "Az.Storage"]
}

variable "automation_account_connection_types_config" {
  type = list(object({
    name      = string
    is_global = bool
    fields = list(object({
      name         = string
      type         = string
      is_encrypted = bool
      is_optional  = bool
    }))
  }))
  default = [
    {
      name      = "Azure"
      is_global = true
      fields = [
        {
          name         = "SubscriptionID"
          type         = "System.String"
          is_encrypted = false
          is_optional  = false
        },
        {
          name         = "AutomationCertificateName"
          type         = "System.String"
          is_encrypted = false
          is_optional  = false
        }
      ]
    },
    {
      name      = "AzureServicePrincipal"
      is_global = true
      fields = [
        {
          name         = "ApplicationId"
          type         = "System.String"
          is_encrypted = false
          is_optional  = false
        },
        {
          name         = "TenantId"
          type         = "System.String"
          is_encrypted = false
          is_optional  = false
        },
        {
          name         = "CertificateThumbprint"
          type         = "System.String"
          is_encrypted = false
          is_optional  = false
        },
        {
          name         = "SubscriptionId"
          type         = "System.String"
          is_encrypted = false
          is_optional  = false
        }
      ]
    }
  ]
}

variable "recovery_services_vault_custom_suffix" {
  type    = string
  default = "rsv"
}

variable "recovery_services_vault_sku" {
  type    = string
  default = "RS0"
}

variable "recovery_services_vault_config_flags" {
  type = object({
    soft_delete_enabled = optional(bool, true)
    storage_mode_type   = optional(string, "GeoRedundant")
  })
  default = {
    soft_delete_enabled = true
    storage_mode_type   = "GeoRedundant"
  }
}

variable "vm_backup_policy_default_config" {
  type = object({
    name                  = string
    frequency             = string
    time                  = string
    timezone              = string
    retention_daily_count = number
  })
  default = {
    name                  = "DefaultBackupPolicy"
    frequency             = "Daily"
    time                  = "23:00"
    timezone              = "UTC"
    retention_daily_count = 30
  }
}

variable "central_managed_identity_custom_suffix" {
  type    = string
  default = "central"
}

variable "load_balancer_custom_suffix" {
  type    = string
  default = "app"
}

variable "create_vmss" {
  type    = bool
  default = false
}

variable "vmss_custom_suffix" {
  type    = string
  default = "vmss"
}

variable "vmss_sku_name" {
  type    = string
  default = "Standard_F4s_v2"
}

variable "vmss_instances_count" {
  type    = number
  default = 2
}

variable "vmss_admin_password_kv_secret_name" {
  type    = string
  default = "vmssAdminPassword"
}

variable "enable_keyvault_private_endpoint" {
  type    = bool
  default = true # TODO False
}

variable "enable_automation_private_endpoint" {
  type    = bool
  default = false
}

variable "enable_network_private_endpoint" {
  type    = bool
  default = false
}

variable "enable_database_migration_service" {
  type    = bool
  default = false
}

variable "user_assigned_identity_id" {
  type        = string
  default     = null
  description = "Optional user-assigned identity ID to use instead of creating a new one."
}

variable "os_type" {
  description = "The operating system type for the VM. Allowed values: Windows or Linux."
  type        = string
  default     = "Windows"
}

variable "backup_vault_retention_days" {
  type    = string
  default = 14
}


variable "custom_name_suffix_bv" {
  type        = string
  default     = "bv"
  description = "Custom suffix to append to the VM Scale Set name."
}

variable "queue_properties" {
  type    = any
  default = null
}

variable "blob_properties" {
  type    = any
  default = null
}

variable "share_properties" {
  type    = any
  default = null
}

variable "private_link_access" {
  type = map(object({
    endpoint_resource_id = string
    endpoint_tenant_id   = string
  }))
  default     = {}
  description = "Private link access configuration"
}

# variable "key_vault_certificate_secret_url" {
#   type = any
#   default = null
# }
