# =================================================================================================
# File: terraform/env/ccg/terraform.tfvars
# UPDATED to match the current FSAM-CLEANCONFIG-RG deployment exactly
# =================================================================================================

// Provider & Environment
cloud_region    = "eastus"
environment     = "ccg"
subscription_id = "4cda8977-68ea-4ca5-aa6a-fae45e7e98f3"
tenant_id       = "ce849bab-cc1c-465b-b62e-18f07c9ac198"

// Global config — drives all BMW module naming
global_config_base = {
  customer_prefix = "fsam"
  env             = "ccg"
  product_id      = "SWP-000"
  appd_id         = "APPD-326047"
  app_name        = "AF"
  costcenter      = "1845"
  tags = {
    customer_prefix = "fsam"
    env             = "ccg"
    owner           = "FG-AM-32"
    appd_id         = "APPD-326047"
    app_name        = "AF"
  }
}

// Resource group — override to match existing portal name exactly
resource_group_name_override = "FSAM-CLEANCONFIG-RG"

// Networking — existing shared VNet
virtual_network_name     = "VNET-SPOKE-EUS-12815"
vnet_resource_group_name = "RG-VNET-SPOKE-EUS-12815"
app_subnet_name          = "Subnet-1"
allowed_ips              = ["10.81.118.0/26"]

// VM image & credentials — must match what is deployed
vm_admin_username  = "fsamdevmadmin"
vm_image_source_id = "/subscriptions/4b4ad43c-6665-4f59-afb4-562f560bb999/resourceGroups/Image_Offers/providers/Microsoft.Compute/galleries/Iaas_OS_Images/images/bmw-win-srv-2022_ae/versions/3.250509.1747380865"
admin_password_key_vault_secret_id = "$vmcompute@123"

// Patch mode must match the deployed VMs (AutomaticByPlatform)
windows_patch_mode = "AutomaticByPlatform"

// VM configurations — custom_suffix drives naming inside BMW VM module
// Module name formula: {customer_prefix}{env}{region_code}{custom_suffix}vm
// = "fsamccg2" + suffix + "vm"  → BUT actual names in Azure are fs-ccg-app1 etc
// The BMW VM module uses custom_name = custom_suffix directly for NIC/VM naming
// Actual deployed names confirmed from ARM export: fs-ccg-app1, fs-ccg-app2, fs-ccg-web1, fs-ccg-web2
vm_configurations = [
  { custom_suffix = "fs-ccg-app1", size = "Standard_F8s_v2", extensions_to_install = ["AADLogin", "MDE"] },
  { custom_suffix = "fs-ccg-app2", size = "Standard_F8s_v2", extensions_to_install = ["AADLogin", "MDE"] },
  { custom_suffix = "fs-ccg-web1", size = "Standard_F8s_v2", extensions_to_install = ["IIS", "AADLogin", "MDE"] },
  { custom_suffix = "fs-ccg-web2", size = "Standard_F8s_v2", extensions_to_install = ["IIS", "AADLogin", "MDE"] }
]

// Managed disks — must match deployed disk names
// Module disk_name = "{cust}{disk_suffix}{vm_suffix}winvm" = "fsamdatadiskfs-ccg-app1winvm"
standalone_managed_disks_config = [
  { vm_custom_suffix = "fs-ccg-app1", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
  { vm_custom_suffix = "fs-ccg-app2", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
  { vm_custom_suffix = "fs-ccg-web1", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
  { vm_custom_suffix = "fs-ccg-web2", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" }
]

// VMSS disabled
create_vmss = false

// Private endpoints
enable_storage_private_endpoints   = true
enable_keyvault_private_endpoint   = true
enable_automation_private_endpoint = true

// Suffixes — drive BMW module naming conventions
central_managed_identity_custom_suffix = "uai"   // → fsamccg2-uai
automation_account_custom_suffix       = "auto"  // → fsamccg2-aa-auto
log_analytics_custom_suffix            = "law"   // → fsamccg-law (BMW module uses different pattern)
app_insights_custom_suffix             = "aapin" // → fsam-ccg-2-aapin (BMW module naming)
load_balancer_custom_suffix            = "app"   // → fsamccg2-lb-app
key_vault_custom_suffix                = "kv"    // → fsamccg2-kv
storage_account_main_custom_suffix     = "stprivatebmw" // → fsamccgstprivatebmw

// Log Analytics config
log_analytics_sku              = "PerGB2018"
log_analytics_retention_in_days = 90
app_insights_application_type  = "web"

// Automation account
automation_account_sku_name = "Basic"
automation_module_names     = []   // modules are managed in portal, not by Terraform

automation_account_connection_types_config = [
  {
    name      = "Azure"
    is_global = true
    fields = [
      { name = "AutomationCertificateName", type = "System.String", is_encrypted = false, is_optional = false },
      { name = "SubscriptionID",            type = "System.String", is_encrypted = false, is_optional = false }
    ]
  },
  {
    name      = "AzureClassicCertificate"
    is_global = true
    fields = [
      { name = "SubscriptionName",      type = "System.String", is_encrypted = false, is_optional = false },
      { name = "SubscriptionId",        type = "System.String", is_encrypted = false, is_optional = false },
      { name = "CertificateAssetName",  type = "System.String", is_encrypted = false, is_optional = false }
    ]
  },
  {
    name      = "AzureServicePrincipal"
    is_global = true
    fields = [
      { name = "ApplicationId",          type = "System.String", is_encrypted = false, is_optional = false },
      { name = "TenantId",               type = "System.String", is_encrypted = false, is_optional = false },
      { name = "CertificateThumbprint",  type = "System.String", is_encrypted = false, is_optional = false },
      { name = "SubscriptionId",         type = "System.String", is_encrypted = false, is_optional = false }
    ]
  }
]

// Storage account
storage_account_main_config = {
  tier                            = "Standard"
  replication_type                = "ZRS"
  allow_blob_public_access        = false
  public_network_access_enabled   = true
  shared_access_key_enabled       = true
  min_tls_version                 = "TLS1_2"
  default_to_oauth_authentication = true
}

// Recovery Services Vault (backup.tf is currently commented out — leave commented)
recovery_services_vault_custom_suffix = "rsv"
recovery_services_vault_sku           = "RS0"
recovery_services_vault_config_flags = {
  soft_delete_enabled = true
  storage_mode_type   = "GeoRedundant"
}
vm_backup_policy_default_config = {
  name                  = "fsam-cleanconfig-rsv-vm"
  frequency             = "Daily"
  time                  = "23:00"
  timezone              = "UTC"
  retention_daily_count = 30
}

// Key Vault
key_vault_sku_name = "standard"
key_vault_config_flags = {
  enabled_for_disk_encryption = true
  purge_protection_enabled    = true
  soft_delete_retention_days  = 90
}

// Database migration service — not deployed in CCG
enable_database_migration_service = false
