# =================================================================================================
# File: terraform/env/ccg/vm)automations.tf
# =================================================================================================

# VM-focused automation module
module "vm_automation_idle_resources" {
  source = "git::https://atc-github.azure.cloud.bmw/fsam-sa/azurerm-vm-automation-runbooks.git"

  # Basic configuration
  resource_group_name           = azurerm_resource_group.application_rg.name
  location                      = var.cloud_region
  automation_account_name       = module.application_automation_account.name
  log_analytics_workspace_name  = module.application_log_analytics.log_analytics_name
  action_group_name             = "ag-vm-automation"
  action_group_short_name       = "vmauto"

  # VM-specific idle detection settings
  vm_idle_threshold_hours = 2    # Aggressive for cost savings
  vm_cpu_threshold       = 5     # 5% CPU threshold
  vm_network_threshold_mb = 10   # 10MB network activity
  vm_disk_threshold_mb   = 50    # 50MB disk activity

  # Business hours configuration
  business_hours_start = "08:00"
  business_hours_end   = "18:00"
  business_days        = [1, 2, 3, 4, 5]  # Monday to Friday
  timezone             = "America/New_York"

  # Enable both idle detection and scheduled shutdown
  enable_idle_detection     = true
  enable_scheduled_shutdown = true

  # VM-specific exclusion rules
  excluded_vm_tags = {
    "AutoShutdown" = "Disabled"
    "Environment"  = "Gold"
    "AlwaysOn"     = "true"
    "DatabaseServer" = "true"
  }

  # Require cost center tag for governance
  required_vm_tags = {
    "CostCenter" = "*"
  }

  # Exclude high-end VM sizes that might be critical
  exclude_vm_sizes = [
    "Standard_M*",     # Memory-optimized
    "Standard_N*"      # GPU instances
  ]

  # Target specific VM sizes for cost optimization
  target_vm_sizes = [
    "Standard_F*"
  ]

  target_resource_groups = [azurerm_resource_group.application_rg.name]

  # Notification settings
  notification_emails = [
    "Miguel.MA.Araujo@partner.bmwgroup.com",
    "Shaikh.Islam@partner.bmwfs.com"
  ]

  # VM operation settings
  enable_vm_deallocate        = true   # Deallocate for maximum savings
  vm_grace_period_minutes     = 15     # 15-minute grace period
  vm_shutdown_timeout_minutes = 10     # 10-minute timeout

  # Enable startup automation for business hours
  enable_startup_automation = true
  startup_delay_minutes     = 5

  # Cost analysis
  enable_cost_analysis         = true
  cost_analysis_retention_days = 90

  # Start in dry run mode for testing
  dry_run_mode = true

  tags = {
    Environment = "CleanConfig"
    Purpose     = "VMCostOptimization"
    ManagedBy   = "Terraform"
    Team        = "FSCloudTeam"
  }
depends_on = [ module.application_vms ] 
}
