# =================================================================================================
# File: terraform/env/dev/vm.tf
# =================================================================================================

module "application_vms" {
  source   = "../../modules/virtual_machine"
  for_each = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf }

  resource_group_name = azurerm_resource_group.application_rg.name
  cloud_region        = var.cloud_region
  custom_name_suffix  = each.value.custom_suffix
  global_config       = local.global_config_for_commons
  # global_config                      = local.resource_name_prefix
  region_code                        = local.number_bump
  tags                               = local.merged_tags
  subnet_id                          = data.azurerm_subnet.app_subnet.id
  app_subnet_name                    = var.app_subnet_name
  virtual_network_name               = var.virtual_network_name
  vnet_resource_group_name           = var.vnet_resource_group_name
  vm_size                            = each.value.size
  admin_username                     = var.vm_admin_username
  os_type                            = "Windows"
  source_image_id                    = var.vm_image_source_id
  admin_password_key_vault_secret_id = var.admin_password_key_vault_secret_id
  # network_interface_ids              = var.network_interface_ids
  # admin_password_key_vault_secret_id   = local.vm_password_is_from_kv && length(azurerm_key_vault_secret.vm_admin_password) > 0 ? azurerm_key_vault_secret.vm_admin_password[0].id : null # TODO
  admin_password_direct_for_bmw_module = null
  enable_system_assigned_identity      = false
  user_assigned_identity_ids           = [module.central_managed_identity.id]
  # recovery_services_vault_name         = module.application_recovery_services_vault.name
  # backup_policy_name                   = module.application_recovery_services_vault != null ? var.vm_backup_policy_default_config.name : null
  log_analytics_workspace_id       = module.application_log_analytics.log_analytics_id
  log_analytics_primary_shared_key = module.application_log_analytics.log_analytics_primary_shared_key
  boot_diagnostics_enabled         = true
  windows_patch_mode               = var.windows_patch_mode
  naming_file_json_tpl             = local.naming_json
  # key_vault_certificate_secret_url = var.key_vault_certificate_secret_url

  depends_on = [
    # data.azurerm_subnet.app_subnet,
    # # azurerm_key_vault_secret.vm_admin_password,
    # module.central_managed_identity,
    # # module.application_recovery_services_vault,
    # module.application_log_analytics,
    # module.application_storage_account
  ]
}

# resource "azurerm_resource_group_template_deployment" "vm_extensions" {
#   for_each            = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf }
#   name                = "VM-${each.key}"
#   resource_group_name = azurerm_resource_group.application_rg.name
#   deployment_mode     = "Incremental"

#   template_content = file("${path.module}/extensions.json")

#   parameters_content = jsonencode({
#     vmName                             = { value = module.application_vms[each.key].name },
#     location                           = { value = var.cloud_region },
#     extensions_to_install              = { value = each.value.extensions_to_install },
#     vm_admin_username                  = { value = var.vm_admin_username },
#     admin_password_key_vault_secret_id = { value = var.admin_password_key_vault_secret_id },
#     log_analytics_id                   = { value = module.application_log_analytics.log_analytics_id },
#     log_analytics_primary_shared_key   = { value = module.application_log_analytics.log_analytics_primary_shared_key },
#     azure_ad_tenant_id                 = { value = var.tenant_id }
#   })

#   depends_on = [
#     module.application_vms,
#     azurerm_resource_group.application_rg
#   ]
# }



# resource "azurerm_virtual_machine_extension" "iis_installer" {
#   for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "IIS") }
#   name                       = "IISInstaller"
#   virtual_machine_id         = module.application_vms[each.key].id
#   publisher                  = "Microsoft.Compute"
#   type                       = "CustomScriptExtension"
#   type_handler_version       = "1.10"
#   auto_upgrade_minor_version = true
#   settings = jsonencode({
#     commandToExecute = "powershell -ExecutionPolicy Bypass -Command \"Install-WindowsFeature Web-Server -IncludeManagementTools; Install-WindowsFeature Web-Asp-Net45\""
#   })
#   tags       = local.merged_tags
#   depends_on = [module.application_vms]
#   lifecycle {
#     ignore_changes = [tags]
#   }
# }

# resource "azurerm_virtual_machine_extension" "octopus_tentacle" {
#   for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "OctopusTentacle") }
#   name                       = "OctopusTentacleInstaller"
#   virtual_machine_id         = module.application_vms[each.key].id
#   publisher                  = "Microsoft.Compute"
#   type                       = "CustomScriptExtension"
#   type_handler_version       = "1.10"
#   auto_upgrade_minor_version = true
#   settings = jsonencode({
#     commandToExecute = <<-EOT
#       powershell -ExecutionPolicy Bypass -Command "
#         Invoke-WebRequest -Uri 'https://download.octopusdeploy.com/octopus/Octopus.Tentacle.7.0.0-x64.msi' -OutFile 'C:\\Tentacle.msi';
#         Start-Process msiexec.exe -ArgumentList '/i C:\\Tentacle.msi /quiet' -Wait"
#       "
#     EOT
#   })
#   tags       = local.merged_tags
#   depends_on = [module.application_vms]
#   lifecycle {
#     ignore_changes = [tags]
#   }
# }

# resource "azurerm_virtual_machine_extension" "enable_vm_access" {
#   for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf }
#   name                       = "EnableVMAccess"
#   virtual_machine_id         = module.application_vms[each.key].id
#   publisher                  = "Microsoft.Compute"
#   type                       = "VMAccessAgent"
#   type_handler_version       = "2.4"
#   auto_upgrade_minor_version = true
#   settings = jsonencode({
#     "UserName" = var.vm_admin_username
#   })
#   protected_settings = jsonencode({
#     "Password" = var.admin_password_key_vault_secret_id
#   })
#   tags       = local.merged_tags
#   depends_on = [module.application_vms]
#   lifecycle {
#     ignore_changes = [tags]
#   }
# }




resource "azurerm_virtual_machine_extension" "enable_vm_access" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf }
  name                       = "EnableVMAccess"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Compute"
  type                       = "VMAccessAgent"
  type_handler_version       = "2.4"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = true
  settings = jsonencode({
    "UserName" = var.vm_admin_username
  })
  protected_settings = jsonencode({
    "Password" = var.admin_password_key_vault_secret_id
  })
  tags       = local.merged_tags
  depends_on = [module.application_vms]
  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_virtual_machine_extension" "aad_login" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "AADLogin") }
  name                       = "AADLoginForWindows"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Azure.ActiveDirectory"
  type                       = "AADLoginForWindows"
  type_handler_version       = "1.0" # "2.2.0.0"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = true
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_virtual_machine_extension" "iis_installer" {
  for_each             = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "IIS") }
  name                 = "IIS"
  virtual_machine_id   = module.application_vms[each.key].id
  publisher            = "Microsoft.Compute"
  type                 = "CustomScriptExtension"
  type_handler_version = "1.10" # "1.9.5"
  # auto_upgrade_minor_version = true
  # automatic_upgrade_enabled  = true
  settings = jsonencode({
    commandToExecute = "powershell -ExecutionPolicy Bypass -Command \"Install-WindowsFeature Web-Server -IncludeManagementTools; Install-WindowsFeature Web-Asp-Net45\""
  })
  tags       = local.merged_tags
  depends_on = [module.application_vms]
  lifecycle {
    ignore_changes = [tags]
  }
}


resource "azurerm_virtual_machine_extension" "octopus_tentacle" {
  for_each             = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "OctopusDeploy") }
  name                 = "OctopusDeployWindowsTentacle"
  virtual_machine_id   = module.application_vms[each.key].id
  publisher            = "OctopusDeploy.Tentacle"
  type                 = "OctopusDeployWindowsTentacle" #"OctopusDeployWindowsTentacle"
  type_handler_version = "2.0"
  # auto_upgrade_minor_version = true
  # automatic_upgrade_enabled  = true
  tags       = local.merged_tags
  depends_on = [module.application_vms]
  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_virtual_machine_extension" "mde_windows" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "MDE") }
  name                       = "MDE.Windows"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Azure.AzureDefenderForServers"
  type                       = "CustomScriptExtension"
  type_handler_version       = "1.0.13.0"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = true
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags]
  }
}

resource "azurerm_virtual_machine_extension" "azure_monitor_agent" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "Monitoring") }
  name                       = "AzureMonitorWindowsAgent"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Azure.Monitor.Extension"
  type                       = "AzureMonitorWindowsAgent"
  type_handler_version       = "1.10" # "1.9.0.0"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = true
  settings = jsonencode({
    workspaceId = module.application_log_analytics.log_analytics_id
  })
  protected_settings = jsonencode({
    workspaceKey = module.application_log_analytics.log_analytics_primary_shared_key
  })
  tags       = local.merged_tags
  depends_on = [module.application_vms]
  lifecycle {
    ignore_changes = [tags]
  }
}




module "application_vmss" {
  # count                              = var.create_vmss ? 1 : 0
  for_each            = var.create_vmss ? { "vmss1" = {} } : {}
  source              = "../../modules/vm_scale_set"
  resource_group_name = azurerm_resource_group.application_rg.name
  location            = var.cloud_region
  custom_name_suffix  = var.vmss_custom_suffix
  global_config       = local.global_config_for_commons
  # global_config                      = local.resource_name_prefix
  region_code                        = local.number_bump
  tags                               = local.merged_tags
  subnet_id                          = [data.azurerm_subnet.app_subnet.id]
  vm_sku                             = var.vmss_sku_name
  instances_count                    = var.vmss_instances_count
  admin_username                     = var.vm_admin_username
  os_type                            = "Windows"
  source_image_id                    = var.vm_image_source_id
  key_vault_id                       = module.application_key_vault.id
  admin_password_key_vault_secret_id = "$vmscale@123"
  # admin_password_key_vault_secret_id = try(azurerm_key_vault_secret.vmss_admin_password[0].id, null)
  user_assigned_identity_ids = [module.central_managed_identity.id]
  virtual_network_name       = var.virtual_network_name
  vnet_resource_group_name   = var.vnet_resource_group_name
  des_key_expiration_date    = "2027-12-31T23:59:59Z"
  depends_on                 = [data.azurerm_subnet.app_subnet, module.central_managed_identity] #, azurerm_key_vault_secret.vmss_admin_password]
}

// Secret for VMSS admin password (if generated or needs to be stored)
# resource "azurerm_key_vault_secret" "vmss_admin_password" {
#   count        = local.vm_password_is_from_kv ? 1 : 0
#   name         = var.vmss_admin_password_kv_secret_name
#   value        = random_password.vm_admin_password_generator[0].result
#   key_vault_id = module.application_key_vault.id
#   tags         = local.merged_tags
#   content_type = "password"
#   # depends_on   = [module.application_key_vault, random_password.vm_admin_password_generator] #, time_sleep.wait_for_kv_rbac_propagation]
# }
