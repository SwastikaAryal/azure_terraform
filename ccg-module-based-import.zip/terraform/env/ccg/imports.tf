# =================================================================================================
# File: terraform/env/ccg/imports.tf
#
# PURPOSE: Import all existing FSAM-CLEANCONFIG-RG resources into Terraform state.
#
# Every `to =` address was derived by reading the ACTUAL module source code:
#   - modules/managed_identity/main.tf    → resource "azurerm_user_assigned_identity" "user_identity"
#   - modules/automation_account/main.tf  → resource "azurerm_automation_account" "automation_account"
#   - modules/load_balancer/main.tf       → resource "azurerm_lb" "load_balancer" etc.
#   - modules/private_endpoint/main.tf    → resource "azurerm_private_endpoint" "pe"
#   - modules/managed_disk/main.tf        → resource "azurerm_managed_disk" "disk"
#   - modules/action_group/main.tf        → resource "azurerm_monitor_action_group" "action_group"
#   - vm.tf (env level)                   → azurerm_virtual_machine_extension.*
#   - managed_disks.tf (env level)        → azurerm_virtual_machine_data_disk_attachment.disk_attachments
#
# The BMW sub-modules (bmw_log_analytics_workspace, bmw_storage_account, bmw_vm,
# bmw_key_vault, bmw_recovery_services_vault) cannot be imported via import blocks
# because import blocks cannot target resources inside nested external modules.
# Those resources must be imported using `terraform import` CLI commands — see below.
#
# USAGE:
#   Step 1: terraform init
#   Step 2: terraform plan   → verify only imports, zero creates/destroys
#   Step 3: terraform apply  → imports all resources into state
#   Step 4: Run CLI imports for BMW sub-module resources (see MANUAL IMPORTS section)
#   Step 5: terraform plan   → must show "No changes"
#
# Subscription : 4cda8977-68ea-4ca5-aa6a-fae45e7e98f3
# Resource Group: FSAM-CLEANCONFIG-RG
# =================================================================================================

# ── Resource Group ─────────────────────────────────────────────────────────────
import {
  to = azurerm_resource_group.application_rg
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG"
}

# ── Central Managed Identity ───────────────────────────────────────────────────
# modules/managed_identity/main.tf → resource "azurerm_user_assigned_identity" "user_identity"
# name produced = "fsamccg2-uai"  (formula: {cust}{env}{region_code}-uai)
import {
  to = module.central_managed_identity.azurerm_user_assigned_identity.user_identity
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fsamccg2-uai"
}

# ── Automation Account ─────────────────────────────────────────────────────────
# modules/automation_account/main.tf → resource "azurerm_automation_account" "automation_account"
# name produced = "fsamccg2-aa-auto"  (formula: {cust}{env}{region_code}-aa-{suffix})
import {
  to = module.application_automation_account.azurerm_automation_account.automation_account
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto"
}

# ── Automation Connection Types ────────────────────────────────────────────────
# automation.tf (env level) → resource "azurerm_automation_connection_type" "environment_connection_types"
# for_each key = conn_type_conf.name
import {
  to = azurerm_automation_connection_type.environment_connection_types["Azure"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/connectionTypes/Azure"
}
import {
  to = azurerm_automation_connection_type.environment_connection_types["AzureClassicCertificate"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/connectionTypes/AzureClassicCertificate"
}
import {
  to = azurerm_automation_connection_type.environment_connection_types["AzureServicePrincipal"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/connectionTypes/AzureServicePrincipal"
}

# ── Monitor Action Groups ──────────────────────────────────────────────────────
# modules/action_group/main.tf → resource "azurerm_monitor_action_group" "action_group"
# name formula: {cust}{env}{region_code}{suffix}-ag
# critical: suffix = "-critical" → "fsamccg2-critical-ag"
# warning:  suffix = "-warning"  → "fsamccg2-warning-ag"
import {
  to = module.critical_alerts_action_group.azurerm_monitor_action_group.action_group
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Insights/actionGroups/fsamccg2-critical-ag"
}
import {
  to = module.warning_alerts_action_group.azurerm_monitor_action_group.action_group
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Insights/actionGroups/fsamccg2-warning-ag"
}

# ── Application Insights ───────────────────────────────────────────────────────
# modules/log_analytics_workspace/main.tf
# → resource "azurerm_application_insights" "explicit_app_insights" [0]
# (created when create_app_insights_via_bmw_module = false, which is set in monitoring.tf)
# name = "fsam-ccg-2-aapin"  (formula: {cust}{env}{region_code}-{ai_suffix} but BMW uses hyphen separator)
import {
  to = module.application_log_analytics.azurerm_application_insights.explicit_app_insights[0]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Insights/components/fsam-ccg-2-aapin"
}

# ── Load Balancer ──────────────────────────────────────────────────────────────
# modules/load_balancer/main.tf → resource "azurerm_lb" "load_balancer"
# name = "fsamccg2-lb-app"  (formula: {cust}{env}{region_code}-lb-{suffix})
import {
  to = module.application_load_balancer.azurerm_lb.load_balancer
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app"
}

# modules/load_balancer/main.tf → resource "azurerm_lb_backend_address_pool" "backend_pool"
# for_each key = pool.name = "bepool-fsamccg2-vm"
import {
  to = module.application_load_balancer.azurerm_lb_backend_address_pool.backend_pool["bepool-fsamccg2-vm"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/backendAddressPools/bepool-fsamccg2-vm"
}

# modules/load_balancer/main.tf → resource "azurerm_lb_probe" "probe"
# for_each key = probe.name
import {
  to = module.application_load_balancer.azurerm_lb_probe.probe["probe-http-fsamccg2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/probes/probe-http-fsamccg2"
}
import {
  to = module.application_load_balancer.azurerm_lb_probe.probe["probe-https-fsamccg2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/probes/probe-https-fsamccg2"
}

# modules/load_balancer/main.tf → resource "azurerm_lb_rule" "rule"
# for_each key = rule.name
import {
  to = module.application_load_balancer.azurerm_lb_rule.rule["lbrul-http-fsamccg2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/loadBalancingRules/lbrul-http-fsamccg2"
}
import {
  to = module.application_load_balancer.azurerm_lb_rule.rule["lbrul-https-fsamccg2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/loadBalancingRules/lbrul-https-fsamccg2"
}

# modules/load_balancer/main.tf → resource "azurerm_network_interface_backend_address_pool_association" "lb_backend_assoc"
# for_each = backend_nics  where key = vm_key matching "web" in vm_configurations
# vm_configurations custom_suffix values: "fs-ccg-web1", "fs-ccg-web2"
import {
  to = module.application_load_balancer.azurerm_network_interface_backend_address_pool_association.lb_backend_assoc["fs-ccg-web1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkInterfaces/nic-fsamfs-ccg-web1winvm|/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/backendAddressPools/bepool-fsamccg2-vm"
}
import {
  to = module.application_load_balancer.azurerm_network_interface_backend_address_pool_association.lb_backend_assoc["fs-ccg-web2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkInterfaces/nic-fsamfs-ccg-web2winvm|/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/backendAddressPools/bepool-fsamccg2-vm"
}

# ── Private Endpoints ──────────────────────────────────────────────────────────
# modules/private_endpoint/main.tf → resource "azurerm_private_endpoint" "pe"
# name = base_name (passed directly to module)

# Storage PE: only "file" exists in the portal
# base_name = format("%s-pe-%s", sa_name, "file") = "fsamccgstprivatebmw-pe-file"
import {
  to = module.application_storage_private_endpoints["file"].azurerm_private_endpoint.pe
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/privateEndpoints/fsamccgstprivatebmw-pe-file"
}

# Automation PE: for_each key = "Webhook"
# base_name = format("%s-pe-agentsvc-%s", aa_name, "Webhook") = "fsamccg2-aa-auto-pe-agentsvc-Webhook"
import {
  to = module.automation_agentsvc_private_endpoint["Webhook"].azurerm_private_endpoint.pe
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/privateEndpoints/fsamccg2-aa-auto-pe-agentsvc-Webhook"
}

# ── Managed Disks ──────────────────────────────────────────────────────────────
# modules/managed_disk/main.tf → resource "azurerm_managed_disk" "disk"
# disk_name formula: {cust}{disk_suffix}{vm_suffix}winvm = "fsamdatadisk{vm_suffix}winvm"
# for_each key in managed_disks.tf = format("%s-%s", vm_suffix, disk_suffix) = "fs-ccg-app1-datadisk"

import {
  to = module.standalone_managed_disks["fs-ccg-app1-datadisk"].azurerm_managed_disk.disk
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/disks/fsamdatadiskfs-ccg-app1winvm"
}
import {
  to = module.standalone_managed_disks["fs-ccg-app2-datadisk"].azurerm_managed_disk.disk
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/disks/fsamdatadiskfs-ccg-app2winvm"
}
import {
  to = module.standalone_managed_disks["fs-ccg-web1-datadisk"].azurerm_managed_disk.disk
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/disks/fsamdatadiskfs-ccg-web1winvm"
}
import {
  to = module.standalone_managed_disks["fs-ccg-web2-datadisk"].azurerm_managed_disk.disk
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/disks/fsamdatadiskfs-ccg-web2winvm"
}

# ── Data Disk Attachments ──────────────────────────────────────────────────────
# managed_disks.tf (env level) → resource "azurerm_virtual_machine_data_disk_attachment" "disk_attachments"
# for_each key = same as standalone_managed_disks key
import {
  to = azurerm_virtual_machine_data_disk_attachment.disk_attachments["fs-ccg-app1-datadisk"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1/dataDisks/fsamdatadiskfs-ccg-app1winvm"
}
import {
  to = azurerm_virtual_machine_data_disk_attachment.disk_attachments["fs-ccg-app2-datadisk"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app2/dataDisks/fsamdatadiskfs-ccg-app2winvm"
}
import {
  to = azurerm_virtual_machine_data_disk_attachment.disk_attachments["fs-ccg-web1-datadisk"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1/dataDisks/fsamdatadiskfs-ccg-web1winvm"
}
import {
  to = azurerm_virtual_machine_data_disk_attachment.disk_attachments["fs-ccg-web2-datadisk"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2/dataDisks/fsamdatadiskfs-ccg-web2winvm"
}

# ── VM Extensions (env-level resources in vm.tf) ───────────────────────────────
# vm.tf → azurerm_virtual_machine_extension.enable_vm_access  (for_each = all VMs)
# NOTE: ARM export shows name "enablevmAccess" on app1 only.
# Code name = "EnableVMAccess" — if resource name in Azure differs Terraform will
# find it by VM ID + extension name.  Import uses the Azure extension name exactly.
import {
  to = azurerm_virtual_machine_extension.enable_vm_access["fs-ccg-app1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1/extensions/enablevmAccess"
}

# vm.tf → azurerm_virtual_machine_extension.aad_login  (for_each = VMs with AADLogin)
# Code deploys extension named "AADLoginForWindows" but Azure portal may show "AADLogin"
# Import using the EXACT name shown in ARM export
import {
  to = azurerm_virtual_machine_extension.aad_login["fs-ccg-app1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1/extensions/AADLogin"
}
import {
  to = azurerm_virtual_machine_extension.aad_login["fs-ccg-app2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app2/extensions/AADLogin"
}
import {
  to = azurerm_virtual_machine_extension.aad_login["fs-ccg-web1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1/extensions/AADLogin"
}
import {
  to = azurerm_virtual_machine_extension.aad_login["fs-ccg-web2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2/extensions/AADLogin"
}

# vm.tf → azurerm_virtual_machine_extension.iis_installer  (for_each = VMs with IIS)
import {
  to = azurerm_virtual_machine_extension.iis_installer["fs-ccg-web1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1/extensions/IIS"
}
import {
  to = azurerm_virtual_machine_extension.iis_installer["fs-ccg-web2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2/extensions/IIS"
}

# vm.tf → azurerm_virtual_machine_extension.mde_windows  (for_each = VMs with MDE)
import {
  to = azurerm_virtual_machine_extension.mde_windows["fs-ccg-app1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1/extensions/MDE.Windows"
}
import {
  to = azurerm_virtual_machine_extension.mde_windows["fs-ccg-app2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app2/extensions/MDE.Windows"
}
import {
  to = azurerm_virtual_machine_extension.mde_windows["fs-ccg-web1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1/extensions/MDE.Windows"
}
import {
  to = azurerm_virtual_machine_extension.mde_windows["fs-ccg-web2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2/extensions/MDE.Windows"
}

# vm.tf → azurerm_virtual_machine_extension.azure_monitor_agent  (for_each = VMs with Monitoring)
# AzurePolicyforWindows is deployed by Azure Policy automatically, not by this code
# Import it to suppress plan diffs if needed via CLI (see manual imports below)


###############################################################################
# =============================================================================
# MANUAL CLI IMPORTS — BMW Sub-Module Resources (cannot use import blocks)
# =============================================================================
# Run these AFTER "terraform apply" completes the import blocks above.
# These resources live inside nested external BMW modules so terraform import
# blocks cannot target them.  Use the CLI instead:
#
# terraform init  (must run first)
#
# ----- Log Analytics Workspace (inside module.application_log_analytics.module.bmw_log_analytics_workspace) -----
# Run: terraform state list | grep log_analytics
# Then import with the exact path shown. Typical path:
#   terraform import \
#     'module.application_log_analytics.module.bmw_log_analytics_workspace.azurerm_log_analytics_workspace.this[0]' \
#     '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.OperationalInsights/workspaces/fsamccg-law'
#
# ----- Log Analytics Linked Service -----
#   terraform import \
#     'module.application_log_analytics.module.bmw_log_analytics_workspace.azurerm_log_analytics_linked_service.automation[0]' \
#     '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.OperationalInsights/workspaces/fsamccg-law/linkedServices/Automation'
#
# ----- Storage Account (inside module.application_storage_account.module.bmw_storage_account) -----
#   terraform import \
#     'module.application_storage_account.module.bmw_storage_account.azurerm_storage_account.this[0]' \
#     '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Storage/storageAccounts/fsamccgstprivatebmw'
#
# ----- Storage File Share -----
#   terraform import \
#     'module.application_storage_account.module.bmw_storage_account.azurerm_storage_share.this["sfam-cleanconfig"]' \
#     '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Storage/storageAccounts/fsamccgstprivatebmw/fileServices/default/shares/sfam-cleanconfig'
#
# ----- Storage UAI (created inside bmw_storage_account) -----
#   terraform import \
#     'module.application_storage_account.module.bmw_storage_account.azurerm_user_assigned_identity.storage_uai[0]' \
#     '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fsam-ccg-eus1-af-appdata-uamid-str'
#
# ----- VMs (inside module.application_vms["fs-ccg-app1"].module.bmw_vm) -----
# Run: terraform state list | grep virtual_machine
# For each VM (app1, app2, web1, web2):
#   terraform import \
#     'module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_windows_virtual_machine.this[0]' \
#     '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1'
#
#   terraform import \
#     'module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_windows_virtual_machine.this[0]' \
#     '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app2'
#
#   terraform import \
#     'module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_windows_virtual_machine.this[0]' \
#     '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1'
#
#   terraform import \
#     'module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_windows_virtual_machine.this[0]' \
#     '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2'
#
# ----- NICs (inside BMW VM module) -----
#   terraform import \
#     'module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_network_interface.this[0]' \
#     '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkInterfaces/nic-fsamfs-ccg-app1winvm'
# (repeat for app2, web1, web2 with their NIC names)
#
# ----- NSGs (inside BMW VM module) -----
#   terraform import \
#     'module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_network_security_group.this[0]' \
#     '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkSecurityGroups/nsg-fsamfs-ccg-app1winvm'
# (repeat for app2, web1, web2)
#
# ----- Key Vault (inside module.application_key_vault.module.bmw_key_vault) -----
#   terraform import \
#     'module.application_key_vault.module.bmw_key_vault.azurerm_key_vault.this[0]' \
#     '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.KeyVault/vaults/fsamccg2-kv'
#
# ----- Recovery Services Vault (inside module.application_recovery_services_vault, if uncommented in backup.tf) -----
#   First uncomment backup.tf module block, then:
#   terraform import \
#     'module.application_recovery_services_vault.module.bmw_recovery_services_vault.azurerm_recovery_services_vault.this[0]' \
#     '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.RecoveryServices/vaults/fsam-cleanconfig-rsv'
#
# ----- VM Automation module (vm_automations.tf external module) -----
# The vm_automation_idle_resources module creates schedules, runbooks, variables, webhooks.
# Run: terraform state list | grep vm_automation
# Import each resource with its path. Example:
#   terraform import \
#     'module.vm_automation_idle_resources.azurerm_automation_schedule.idle_detection[0]' \
#     '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/schedules/schedule-vm-idle-detection'
#
# =============================================================================
# HOW TO FIND EXACT PATHS INSIDE NESTED MODULES:
# After terraform init (which downloads all modules):
#   terraform plan -generate-config-out=generated.tf 2>&1 | grep "module\." | head -50
# or:
#   terraform providers schema -json | python3 -m json.tool | grep -A2 '"module_calls"'
# or simply let terraform plan run and read the error messages — they tell you
# exactly what path it expected.
###############################################################################
