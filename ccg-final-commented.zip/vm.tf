# =================================================================================================
# File: terraform/env/ccg/vm.tf
# KEY CHANGES vs original:
#   1. os_disk_storage_account_type = "StandardSSD_LRS"
#      State shows LRS — original code defaults to ZRS — would force VM destroy
#   2. lifecycle ignore_changes on all extensions
#   3. removed{} blocks for all BMW VM module internals not in Azure CCG
# =================================================================================================

module "application_vms" {
  source   = "../../modules/virtual_machine"
  for_each = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf }

  resource_group_name                  = azurerm_resource_group.application_rg.name
  cloud_region                         = var.cloud_region
  custom_name_suffix                   = each.value.custom_suffix
  global_config                        = local.global_config_for_commons
  region_code                          = local.number_bump
  tags                                 = local.merged_tags
  subnet_id                            = data.azurerm_subnet.app_subnet.id
  app_subnet_name                      = var.app_subnet_name
  virtual_network_name                 = var.virtual_network_name
  vnet_resource_group_name             = var.vnet_resource_group_name
  vm_size                              = each.value.size
  admin_username                       = var.vm_admin_username
  os_type                              = "Windows"
  source_image_id                      = var.vm_image_source_id
  admin_password_key_vault_secret_id   = var.admin_password_key_vault_secret_id
  admin_password_direct_for_bmw_module = null
  enable_system_assigned_identity      = false
  user_assigned_identity_ids           = [module.central_managed_identity.id]
  log_analytics_workspace_id           = module.application_log_analytics.log_analytics_id
  log_analytics_primary_shared_key     = module.application_log_analytics.log_analytics_primary_shared_key
  boot_diagnostics_enabled             = true
  windows_patch_mode                   = var.windows_patch_mode
  naming_file_json_tpl                 = local.naming_json
  secure_boot_enabled                  = var.secure_boot_enabled
  vtpm_enabled                         = var.vtpm_enabled
  # FIX: State file shows StandardSSD_LRS on all 4 VMs.
  # Without this the plan defaults to StandardSSD_ZRS which forces a VM destroy+recreate.
  os_disk_storage_account_type         = "StandardSSD_LRS"
}

# =============================================================================
# VM EXTENSIONS — all values confirmed from terraform-ccg.tfstate
# =============================================================================

# enablevmAccess — app1 ONLY (not on app2, web1, web2)
resource "azurerm_virtual_machine_extension" "enable_vm_access" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if vm_conf.custom_suffix == "fs-ccg-app1" }
  name                       = "enablevmAccess"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Compute"
  type                       = "VMAccessAgent"
  type_handler_version       = "2.0"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = false
  settings                   = jsonencode({ "userName" = var.vm_admin_username })
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, settings, protected_settings, type_handler_version]
  }
}

# AADLogin — all 4 VMs
resource "azurerm_virtual_machine_extension" "aad_login" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "AADLogin") }
  name                       = "AADLogin"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Azure.ActiveDirectory"
  type                       = "AADLoginForWindows"
  type_handler_version       = "2.2"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = false
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, settings, protected_settings, type_handler_version]
  }
}

# IIS — web1 and web2 only
resource "azurerm_virtual_machine_extension" "iis_installer" {
  for_each             = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "IIS") }
  name                 = "IIS"
  virtual_machine_id   = module.application_vms[each.key].id
  publisher            = "Microsoft.Compute"
  type                 = "CustomScriptExtension"
  type_handler_version = "1.10"
  settings             = jsonencode({ commandToExecute = "powershell -ExecutionPolicy Bypass -Command \"Install-WindowsFeature Web-Server -IncludeManagementTools; Install-WindowsFeature Web-Asp-Net45\"" })
  tags                 = local.merged_tags
  depends_on           = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, settings, protected_settings, type_handler_version]
  }
}

# MDE.Windows — all 4 VMs
resource "azurerm_virtual_machine_extension" "mde_windows" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "MDE") }
  name                       = "MDE.Windows"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Azure.AzureDefenderForServers"
  type                       = "MDE.Windows"
  type_handler_version       = "1.0"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = true
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, settings, protected_settings, type_handler_version]
  }
}

# AzurePolicyforWindows — all 4 VMs (deployed automatically by Azure Policy)
resource "azurerm_virtual_machine_extension" "azure_policy" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf }
  name                       = "AzurePolicyforWindows"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.GuestConfiguration"
  type                       = "ConfigurationforWindows"
  type_handler_version       = "1.29"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = true
  settings                   = jsonencode({})
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, settings, protected_settings, type_handler_version]
  }
}

# =============================================================================
# COMMENTED OUT — BMW VM module internal resources NOT IN AZURE CCG
#
# The BMW VM module creates all of these internally when certain features are enabled.
# NONE of them exist in the CCG Azure environment (confirmed from terraform-ccg.tfstate).
# Without removed{} blocks Terraform plans to CREATE all of them (causes the 51 adds).
#
# Per VM (×4 = app1, app2, web1, web2):
#   azurerm_disk_encryption_set.disk                              — disk encryption NOT enabled in CCG
#   azurerm_key_vault_key.disk                                    — no CMK for VM disks in CCG
#   azurerm_managed_disk.data_disk                                — BMW internal disk, not the standalone one
#   azurerm_monitor_data_collection_rule.linux                    — Linux DCR not needed (Windows VMs)
#   azurerm_monitor_data_collection_rule.windows                  — DCR not deployed in CCG
#   azurerm_monitor_data_collection_rule_association.data_collection_rule — DCR assoc not in CCG
#   azurerm_monitor_data_collection_rule_association.linux        — Linux DCR assoc not in CCG
#   azurerm_monitor_diagnostic_setting.linux                      — Linux diag not needed
#   azurerm_monitor_diagnostic_setting.windows                    — diag settings not in CCG
#   azurerm_network_security_rule.nsg_rule                        — NSG rules not in CCG
#   azurerm_role_assignment.keyvault_identity_user                — role assignment not in CCG
#   azurerm_role_assignment.log_identity_user                     — role assignment not in CCG
#   azurerm_virtual_machine_data_disk_attachment.data_disk        — BMW internal attachment
#   azurerm_virtual_machine_extension.ama_linux                   — Linux AMA not in CCG
#   azurerm_virtual_machine_extension.ama_windows                 — Windows AMA not in CCG
#   azurerm_virtual_machine_extension.dependency_agent_windows    — dep agent not in CCG
# =============================================================================

# ── fs-ccg-app1 ──────────────────────────────────────────────────────────────
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_disk_encryption_set.disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_key_vault_key.disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_managed_disk.data_disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_monitor_data_collection_rule.linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_monitor_data_collection_rule.windows ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_monitor_data_collection_rule_association.data_collection_rule ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_monitor_data_collection_rule_association.linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_monitor_diagnostic_setting.linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_monitor_diagnostic_setting.windows ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_network_security_rule.nsg_rule ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_role_assignment.keyvault_identity_user ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_role_assignment.log_identity_user ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_virtual_machine_data_disk_attachment.data_disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_virtual_machine_extension.ama_linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_virtual_machine_extension.ama_windows ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_virtual_machine_extension.dependency_agent_windows ; lifecycle { destroy = false } }

# ── fs-ccg-app2 ──────────────────────────────────────────────────────────────
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_disk_encryption_set.disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_key_vault_key.disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_managed_disk.data_disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_monitor_data_collection_rule.linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_monitor_data_collection_rule.windows ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_monitor_data_collection_rule_association.data_collection_rule ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_monitor_data_collection_rule_association.linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_monitor_diagnostic_setting.linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_monitor_diagnostic_setting.windows ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_network_security_rule.nsg_rule ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_role_assignment.keyvault_identity_user ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_role_assignment.log_identity_user ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_virtual_machine_data_disk_attachment.data_disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_virtual_machine_extension.ama_linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_virtual_machine_extension.ama_windows ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_virtual_machine_extension.dependency_agent_windows ; lifecycle { destroy = false } }

# ── fs-ccg-web1 ──────────────────────────────────────────────────────────────
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_disk_encryption_set.disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_key_vault_key.disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_managed_disk.data_disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_monitor_data_collection_rule.linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_monitor_data_collection_rule.windows ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_monitor_data_collection_rule_association.data_collection_rule ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_monitor_data_collection_rule_association.linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_monitor_diagnostic_setting.linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_monitor_diagnostic_setting.windows ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_network_security_rule.nsg_rule ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_role_assignment.keyvault_identity_user ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_role_assignment.log_identity_user ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_virtual_machine_data_disk_attachment.data_disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_virtual_machine_extension.ama_linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_virtual_machine_extension.ama_windows ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_virtual_machine_extension.dependency_agent_windows ; lifecycle { destroy = false } }

# ── fs-ccg-web2 ──────────────────────────────────────────────────────────────
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_disk_encryption_set.disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_key_vault_key.disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_managed_disk.data_disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_monitor_data_collection_rule.linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_monitor_data_collection_rule.windows ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_monitor_data_collection_rule_association.data_collection_rule ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_monitor_data_collection_rule_association.linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_monitor_diagnostic_setting.linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_monitor_diagnostic_setting.windows ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_network_security_rule.nsg_rule ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_role_assignment.keyvault_identity_user ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_role_assignment.log_identity_user ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_virtual_machine_data_disk_attachment.data_disk ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_virtual_machine_extension.ama_linux ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_virtual_machine_extension.ama_windows ; lifecycle { destroy = false } }
removed { from = module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_virtual_machine_extension.dependency_agent_windows ; lifecycle { destroy = false } }
