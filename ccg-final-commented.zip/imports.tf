# =================================================================================================
# File: terraform/env/ccg/imports.tf
# All resources have been imported via terraform import CLI.
# This file is intentionally empty.
# =================================================================================================
