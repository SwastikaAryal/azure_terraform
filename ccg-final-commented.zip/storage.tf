# =================================================================================================
# File: terraform/env/ccg/storage.tf
# =================================================================================================

module "application_storage_account" {
  source                          = "../../modules/storage_account"
  resource_group_name             = azurerm_resource_group.application_rg.name
  cloud_region                    = var.cloud_region
  custom_name_suffix              = var.storage_account_main_custom_suffix
  global_config                   = local.global_config_for_commons
  region_code                     = local.number_bump
  tags                            = local.merged_tags
  account_tier                    = var.storage_account_main_config.tier
  account_replication_type        = var.storage_account_main_config.replication_type
  account_kind                    = "StorageV2"
  allow_blob_public_access        = var.storage_account_main_config.allow_blob_public_access
  public_network_access_enabled   = var.enable_storage_private_endpoints ? true : var.storage_account_main_config.public_network_access_enabled
  shared_access_key_enabled       = var.storage_account_main_config.shared_access_key_enabled
  default_to_oauth_authentication = var.storage_account_main_config.default_to_oauth_authentication
  min_tls_version                 = var.storage_account_main_config.min_tls_version
  # FIX: enable_cmk = false — CMK not configured in CCG.
  # Keeps azurerm_key_vault_key.storage and azurerm_storage_account_customer_managed_key
  # from being created (those resources are NOT IN AZURE CCG)
  enable_cmk                      = false
  cmk_key_vault_id                = module.application_key_vault.id
  naming_file_json_tpl            = local.naming_json
  network_rules_config = var.enable_storage_private_endpoints ? null : {
    default_action             = contains(var.allowed_ips, "0.0.0.0/0") ? "Allow" : "Deny"
    bypass                     = ["AzureServices"]
    ip_rules                   = local.commons_allowed_ips
    virtual_network_subnet_ids = [data.azurerm_subnet.app_subnet.id]
  }
  create_diagnostic_settings = true
  log_analytics_workspace_id = module.application_log_analytics.log_analytics_id
  depends_on                 = [data.azurerm_subnet.app_subnet]
}

# =============================================================================
# COMMENTED OUT — BMW Storage module internals NOT IN AZURE CCG
# These resources are created by the BMW storage module when certain flags are set.
# None of them exist in the CCG Azure environment (confirmed from state file).
#
# NOT IN AZURE:
#   module.application_storage_account.module.bmw_storage_account.azurerm_key_vault_access_policy.storage
#   module.application_storage_account.module.bmw_storage_account.azurerm_key_vault_key.storage
#   module.application_storage_account.module.bmw_storage_account.azurerm_log_analytics_storage_insights.blob
#   module.application_storage_account.module.bmw_storage_account.azurerm_log_analytics_storage_insights.table
#   module.application_storage_account.module.bmw_storage_account.azurerm_private_endpoint.storage
#   module.application_storage_account.module.bmw_storage_account.azurerm_role_assignment.allow_storage_to_key_vault
#   module.application_storage_account.module.bmw_storage_account.azurerm_storage_account_customer_managed_key.customer_managed_key
#   module.application_storage_account.module.bmw_storage_account.azurerm_storage_account_local_user.this
# =============================================================================
removed {
  from = module.application_storage_account.module.bmw_storage_account.azurerm_key_vault_access_policy.storage
  lifecycle { destroy = false }
}
removed {
  from = module.application_storage_account.module.bmw_storage_account.azurerm_key_vault_key.storage
  lifecycle { destroy = false }
}
removed {
  from = module.application_storage_account.module.bmw_storage_account.azurerm_log_analytics_storage_insights.blob
  lifecycle { destroy = false }
}
removed {
  from = module.application_storage_account.module.bmw_storage_account.azurerm_log_analytics_storage_insights.table
  lifecycle { destroy = false }
}
removed {
  from = module.application_storage_account.module.bmw_storage_account.azurerm_private_endpoint.storage
  lifecycle { destroy = false }
}
removed {
  from = module.application_storage_account.module.bmw_storage_account.azurerm_role_assignment.allow_storage_to_key_vault
  lifecycle { destroy = false }
}
removed {
  from = module.application_storage_account.module.bmw_storage_account.azurerm_storage_account_customer_managed_key.customer_managed_key
  lifecycle { destroy = false }
}
removed {
  from = module.application_storage_account.module.bmw_storage_account.azurerm_storage_account_local_user.this
  lifecycle { destroy = false }
}
