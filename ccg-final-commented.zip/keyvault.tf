# =================================================================================================
# File: terraform/env/ccg/keyvault.tf
# =================================================================================================

module "application_key_vault" {
  source                      = "../../modules/keyvault"
  resource_group_name         = azurerm_resource_group.application_rg.name
  cloud_region                = var.cloud_region
  custom_name_suffix          = var.key_vault_custom_suffix
  sku_name                    = var.key_vault_sku_name
  enable_rbac_authorization   = false
  purge_protection_enabled    = var.key_vault_config_flags.purge_protection_enabled
  soft_delete_retention_days  = var.key_vault_config_flags.soft_delete_retention_days
  enabled_for_disk_encryption = var.key_vault_config_flags.enabled_for_disk_encryption
  global_config               = local.global_config_for_commons
  region_code                 = local.number_bump
  tags                        = local.merged_tags
  create_diagnostic_settings  = true
  log_analytics_workspace_id  = module.application_log_analytics.log_analytics_id
  naming_file_json_tpl        = local.naming_json
  allowed_subnet_ids          = [data.azurerm_subnet.app_subnet.id]
  allowed_ips                 = local.commons_allowed_ips
  network_acls_config = var.enable_keyvault_private_endpoint ? null : {
    default_action             = contains(var.allowed_ips, "0.0.0.0/0") ? "Allow" : "Deny"
    bypass                     = "AzureServices"
    ip_rules                   = local.commons_allowed_ips
    virtual_network_subnet_ids = [data.azurerm_subnet.app_subnet.id]
  }
  depends_on = [
    azurerm_resource_group.application_rg,
    module.central_managed_identity,
    module.application_log_analytics,
    data.azurerm_subnet.app_subnet
  ]
}

# =============================================================================
# COMMENTED OUT — BMW KV module internals NOT IN AZURE CCG
# The BMW KV module creates these resources internally when certain flags are set.
# None of them exist in the CCG Azure environment (confirmed from state file).
# They will show as "to add" in plan. Use removed{} blocks to suppress.
#
# NOT IN AZURE:
#   module.application_key_vault.module.bmw_key_vault.azurerm_key_vault_certificate_contacts.contacts
#   module.application_key_vault.module.bmw_key_vault.azurerm_private_endpoint.this
#   module.application_key_vault.module.bmw_key_vault.azurerm_role_assignment.cert_contacts
#   module.application_key_vault.module.bmw_key_vault.azurerm_role_assignment.this
#   module.application_key_vault.module.bmw_key_vault.azurerm_role_definition.cert_contacts
#   module.application_key_vault.module.bmw_key_vault.time_sleep.wait_for_role_cert_contacts
#   module.application_key_vault.module.bmw_key_vault.module.common.random_password.password
#   module.application_key_vault.module.bmw_key_vault.module.common.random_string.random_string_prefix
#   module.application_key_vault.module.bmw_key_vault.module.common.time_rotating.password
#
# ADD THESE removed{} BLOCKS to suppress:
# =============================================================================
removed {
  from = module.application_key_vault.module.bmw_key_vault.azurerm_key_vault_certificate_contacts.contacts
  lifecycle { destroy = false }
}
removed {
  from = module.application_key_vault.module.bmw_key_vault.azurerm_private_endpoint.this
  lifecycle { destroy = false }
}
removed {
  from = module.application_key_vault.module.bmw_key_vault.azurerm_role_assignment.cert_contacts
  lifecycle { destroy = false }
}
removed {
  from = module.application_key_vault.module.bmw_key_vault.azurerm_role_assignment.this
  lifecycle { destroy = false }
}
removed {
  from = module.application_key_vault.module.bmw_key_vault.azurerm_role_definition.cert_contacts
  lifecycle { destroy = false }
}
