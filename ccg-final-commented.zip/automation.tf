# =================================================================================================
# File: terraform/env/ccg/automation.tf
# =================================================================================================

module "application_automation_account" {
  source              = "../../modules/automation_account"
  resource_group_name = azurerm_resource_group.application_rg.name
  cloud_region        = var.cloud_region
  custom_name_suffix  = var.automation_account_custom_suffix
  global_config       = local.global_config_for_commons
  region_code         = local.number_bump
  tags                = local.merged_tags
  sku_name                           = var.automation_account_sku_name
  identity_type                      = "SystemAssigned, UserAssigned"
  user_assigned_identity_ids         = [module.central_managed_identity.id]
  # FIX: automation_module_names_to_install = [] prevents azurerm_automation_module.required_modules
  # from being created. That resource does NOT exist in CCG Azure environment.
  automation_module_names_to_install = var.automation_module_names
  depends_on = [azurerm_resource_group.application_rg, module.central_managed_identity]
}

# NOTE: azurerm_automation_module.required_modules — NOT IN AZURE CCG
# Controlled by automation_module_names = [] in terraform.tfvars
# As long as that variable is empty, this resource will not be planned.

resource "azurerm_automation_connection_type" "environment_connection_types" {
  for_each                = { for conn_type_conf in var.automation_account_connection_types_config : conn_type_conf.name => conn_type_conf }
  name                    = each.value.name
  automation_account_name = module.application_automation_account.name
  resource_group_name     = azurerm_resource_group.application_rg.name
  is_global               = each.value.is_global
  dynamic "field" {
    for_each = each.value.fields
    content {
      name         = field.value.name
      type         = field.value.type
      is_encrypted = field.value.is_encrypted
      is_optional  = field.value.is_optional
    }
  }
  depends_on = [module.application_automation_account]
  lifecycle {
    ignore_changes = [name, automation_account_name, resource_group_name, field]
  }
}
