# =================================================================================================
# File: terraform/env/ccg/managed_disks.tf
# =================================================================================================

module "standalone_managed_disks" {
  source               = "../../modules/managed_disk"
  for_each             = { for disk_conf in var.standalone_managed_disks_config : format("%s-%s", disk_conf.vm_custom_suffix, disk_conf.disk_custom_suffix) => disk_conf }
  resource_group_name  = azurerm_resource_group.application_rg.name
  cloud_region         = var.cloud_region
  vm_identifier_suffix = each.value.vm_custom_suffix
  disk_custom_suffix   = each.value.disk_custom_suffix
  global_config        = local.global_config_for_commons
  region_code          = local.number_bump
  tags                 = local.merged_tags
  disk_size_gb         = each.value.disk_size_gb
  storage_account_type = each.value.storage_account_type
  create_option        = "Empty"
  depends_on           = [module.application_vms]
}

resource "azurerm_virtual_machine_data_disk_attachment" "disk_attachments" {
  for_each           = { for disk_conf in var.standalone_managed_disks_config : format("%s-%s", disk_conf.vm_custom_suffix, disk_conf.disk_custom_suffix) => disk_conf }
  managed_disk_id    = module.standalone_managed_disks[each.key].id
  virtual_machine_id = module.application_vms[each.value.vm_custom_suffix].vm_resource_id_for_attachment
  lun                = each.value.lun
  caching            = each.value.caching
  create_option      = "Attach"
  depends_on         = [module.application_vms, module.standalone_managed_disks]
  lifecycle {
    # FIX: virtual_machine_id can change if VM is recreated — ignore to prevent re-attach
    ignore_changes = [virtual_machine_id]
  }
}
