# =================================================================================================
# File: terraform/env/dev/automation.tf
# =================================================================================================

module "application_automation_account" {
  source              = "../../modules/automation_account"
  resource_group_name = azurerm_resource_group.application_rg.name
  cloud_region        = var.cloud_region
  custom_name_suffix  = var.automation_account_custom_suffix
  # global_config       = local.resource_name_prefix
  global_config = local.global_config_for_commons
  region_code   = local.number_bump
  tags          = local.merged_tags

  sku_name                           = var.automation_account_sku_name
  identity_type                      = "SystemAssigned, UserAssigned"
  user_assigned_identity_ids         = [module.central_managed_identity.id]
  automation_module_names_to_install = var.automation_module_names // Renamed variable in module

  # runbooks_to_create = [ // Renamed variable in module
  #   { name = "Sample-PowerShell-Runbook", type = "PowerShell", description = "Sample PowerShell runbook for cleanconfig", content_path = "runbooks/sample_powershell_runbook.ps1", publish_content_uri = null, log_progress = true, log_verbose = true },
  #   { name = "Sample-Python3-Runbook", type = "Python3", description = "Sample Python 3 runbook for cleanconfig", content_path = "runbooks/sample_python_runbook.py", publish_content_uri = null, log_progress = true, log_verbose = true }
  # ]
  # webhooks_to_create = [ // Renamed variable in module
  #   { name = "SampleWebhookcleanconfig", runbook_name = "Sample-PowerShell-Runbook", expiry_time = "2035-01-19T11:03:04.329+00:00", enabled = true }
  # ]
  depends_on = [azurerm_resource_group.application_rg, module.central_managed_identity]
}

resource "azurerm_automation_connection_type" "environment_connection_types" {
  for_each                = { for conn_type_conf in var.automation_account_connection_types_config : conn_type_conf.name => conn_type_conf }
  name                    = each.value.name
  automation_account_name = module.application_automation_account.name
  resource_group_name     = azurerm_resource_group.application_rg.name
  is_global               = each.value.is_global
  dynamic "field" {
    for_each = each.value.fields
    content {
      name         = field.value.name
      type         = field.value.type
      is_encrypted = field.value.is_encrypted
      is_optional  = field.value.is_optional
    }
  }
  depends_on = [module.application_automation_account]
  lifecycle {
    ignore_changes = [name, automation_account_name, resource_group_name, field]
  }
}
