# =================================================================================================
# File: terraform/env/uat/monitoring.tf
# =================================================================================================

module "application_log_analytics" {
  source              = "../../modules/log_analytics_workspace"
  resource_group_name = azurerm_resource_group.application_rg.name
  cloud_region        = var.cloud_region
  custom_name_suffix  = var.log_analytics_custom_suffix
  global_config       = local.global_config_for_commons
  # global_config                      = local.resource_name_prefix
  region_code                        = local.number_bump
  tags                               = local.merged_tags
  sku                                = var.log_analytics_sku
  retention_in_days                  = var.log_analytics_retention_in_days
  create_app_insights_via_bmw_module = false
  app_insights_custom_suffix         = var.app_insights_custom_suffix
  app_insights_application_type      = var.app_insights_application_type
  // app_insights_retention_in_days = var.log_analytics_retention_in_days
  naming_file_json_tpl = local.naming_json
  depends_on           = [azurerm_resource_group.application_rg]
}

module "critical_alerts_action_group" {
  source              = "../../modules/action_group"
  resource_group_name = azurerm_resource_group.application_rg.name
  global_config       = local.global_config_for_commons
  # global_config      = local.resource_name_prefix
  custom_name_suffix = format("-critical")
  region_code        = local.number_bump
  short_name         = "crit-dev"
  tags               = local.merged_tags
  email_receivers    = [{ name = "critical-alerts-email-dev", email_address = "Shravan.Chiduruppa@bmwfs.com", use_common_alert_schema = true }]
  depends_on         = [azurerm_resource_group.application_rg]
}

module "warning_alerts_action_group" {
  source              = "../../modules/action_group"
  resource_group_name = azurerm_resource_group.application_rg.name
  global_config       = local.global_config_for_commons
  # global_config      = local.resource_name_prefix
  custom_name_suffix = format("-warning")
  region_code        = local.number_bump
  short_name         = "warn-dev"
  tags               = local.merged_tags
  email_receivers    = [{ name = "warning-alerts-email-dev", email_address = "Shravan.Chiduruppa@bmwfs.com", use_common_alert_schema = true }]
  depends_on         = [azurerm_resource_group.application_rg]
}

# resource "azurerm_eventgrid_system_topic" "storage_account_event_topic" {
#   name                   = format("%s-evst-%s-topic", local.resource_name_prefix, var.storage_account_main_custom_suffix)
#   location               = var.cloud_region
#   resource_group_name    = azurerm_resource_group.application_rg.name
#   source_arm_resource_id = module.application_storage_account.id
#   topic_type             = "Microsoft.Storage.StorageAccounts"
#   tags                   = local.merged_tags
#   depends_on             = [module.application_storage_account]
# }

# resource "azurerm_storage_queue" "storage_events_queue" {
#   # name                 = format("quev%s%s", lower(local.global_config_for_commons.customer_prefix), lower(local.global_config_for_commons.env))
#   name                 = format("%squev", lower(local.resource_name_prefix))
#   storage_account_name = module.application_storage_account.name
#   depends_on           = [module.application_storage_account]
# }

# resource "azurerm_eventgrid_event_subscription" "storage_blob_created_subscription" {
#   name                  = format("%s-evsub-blobcreated", local.resource_name_prefix)
#   scope                 = azurerm_eventgrid_system_topic.storage_account_event_topic.id
#   event_delivery_schema = "EventGridSchema"
#   storage_queue_endpoint {
#     storage_account_id = module.application_storage_account.id
#     queue_name         = azurerm_storage_queue.storage_events_queue.name
#   }
#   included_event_types = ["Microsoft.Storage.BlobCreated", "Microsoft.Storage.BlobDeleted"]
#   retry_policy {
#     max_delivery_attempts = 30
#     event_time_to_live    = 1440
#   }
#   depends_on = [azurerm_eventgrid_system_topic.storage_account_event_topic, azurerm_storage_queue.storage_events_queue]
# }
