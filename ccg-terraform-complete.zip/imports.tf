# =================================================================================================
# File: terraform/env/ccg/imports.tf
# All `to =` addresses derived from reading the actual module source files.
# All `id =` values taken directly from ARM export of FSAM-CLEANCONFIG-RG.
# =================================================================================================

# ── Resource Group ─────────────────────────────────────────────────────────────
import {
  to = azurerm_resource_group.application_rg
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG"
}

# ── Central Managed Identity ───────────────────────────────────────────────────
# module/managed_identity/main.tf → resource "azurerm_user_assigned_identity" "user_identity"
import {
  to = module.central_managed_identity.azurerm_user_assigned_identity.user_identity
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fsamccg2-uai"
}

# ── Automation Account ─────────────────────────────────────────────────────────
# modules/automation_account/main.tf → resource "azurerm_automation_account" "automation_account"
import {
  to = module.application_automation_account.azurerm_automation_account.automation_account
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto"
}

# ── Automation Connection Types ────────────────────────────────────────────────
# automation.tf → resource "azurerm_automation_connection_type" "environment_connection_types"
import {
  to = azurerm_automation_connection_type.environment_connection_types["Azure"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/connectionTypes/Azure"
}
import {
  to = azurerm_automation_connection_type.environment_connection_types["AzureClassicCertificate"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/connectionTypes/AzureClassicCertificate"
}
import {
  to = azurerm_automation_connection_type.environment_connection_types["AzureServicePrincipal"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Automation/automationAccounts/fsamccg2-aa-auto/connectionTypes/AzureServicePrincipal"
}

# ── Monitor Action Groups ──────────────────────────────────────────────────────
# modules/action_group/main.tf → resource "azurerm_monitor_action_group" "action_group"
import {
  to = module.critical_alerts_action_group.azurerm_monitor_action_group.action_group
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Insights/actionGroups/fsamccg2-critical-ag"
}
import {
  to = module.warning_alerts_action_group.azurerm_monitor_action_group.action_group
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Insights/actionGroups/fsamccg2-warning-ag"
}

# ── Application Insights ───────────────────────────────────────────────────────
# modules/log_analytics_workspace/main.tf → resource "azurerm_application_insights" "explicit_app_insights"[0]
# (create_app_insights_via_bmw_module = false in monitoring.tf)
import {
  to = module.application_log_analytics.azurerm_application_insights.explicit_app_insights[0]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Insights/components/fsam-ccg-2-aapin"
}

# ── Load Balancer ──────────────────────────────────────────────────────────────
# modules/load_balancer/main.tf
import {
  to = module.application_load_balancer.azurerm_lb.load_balancer
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app"
}
import {
  to = module.application_load_balancer.azurerm_lb_backend_address_pool.backend_pool["bepool-fsamccg2-vm"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/backendAddressPools/bepool-fsamccg2-vm"
}
import {
  to = module.application_load_balancer.azurerm_lb_probe.probe["probe-http-fsamccg2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/probes/probe-http-fsamccg2"
}
import {
  to = module.application_load_balancer.azurerm_lb_probe.probe["probe-https-fsamccg2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/probes/probe-https-fsamccg2"
}
import {
  to = module.application_load_balancer.azurerm_lb_rule.rule["lbrul-http-fsamccg2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/loadBalancingRules/lbrul-http-fsamccg2"
}
import {
  to = module.application_load_balancer.azurerm_lb_rule.rule["lbrul-https-fsamccg2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/loadBalancingRules/lbrul-https-fsamccg2"
}
import {
  to = module.application_load_balancer.azurerm_network_interface_backend_address_pool_association.lb_backend_assoc["fs-ccg-web1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkInterfaces/nic-fsamfs-ccg-web1winvm|/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/backendAddressPools/bepool-fsamccg2-vm"
}
import {
  to = module.application_load_balancer.azurerm_network_interface_backend_address_pool_association.lb_backend_assoc["fs-ccg-web2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkInterfaces/nic-fsamfs-ccg-web2winvm|/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/loadBalancers/fsamccg2-lb-app/backendAddressPools/bepool-fsamccg2-vm"
}

# ── Private Endpoints ──────────────────────────────────────────────────────────
# modules/private_endpoint/main.tf → resource "azurerm_private_endpoint" "pe"
# Storage: only "file" exists
import {
  to = module.application_storage_private_endpoints["file"].azurerm_private_endpoint.pe
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/privateEndpoints/fsamccgstprivatebmw-pe-file"
}
# Automation: "Webhook" exists
import {
  to = module.automation_agentsvc_private_endpoint["Webhook"].azurerm_private_endpoint.pe
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/privateEndpoints/fsamccg2-aa-auto-pe-agentsvc-Webhook"
}

# ── Managed Disks ──────────────────────────────────────────────────────────────
# modules/managed_disk/main.tf → resource "azurerm_managed_disk" "disk"
# for_each key = "{vm_suffix}-{disk_suffix}"
import {
  to = module.standalone_managed_disks["fs-ccg-app1-datadisk"].azurerm_managed_disk.disk
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/disks/fsamdatadiskfs-ccg-app1winvm"
}
import {
  to = module.standalone_managed_disks["fs-ccg-app2-datadisk"].azurerm_managed_disk.disk
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/disks/fsamdatadiskfs-ccg-app2winvm"
}
import {
  to = module.standalone_managed_disks["fs-ccg-web1-datadisk"].azurerm_managed_disk.disk
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/disks/fsamdatadiskfs-ccg-web1winvm"
}
import {
  to = module.standalone_managed_disks["fs-ccg-web2-datadisk"].azurerm_managed_disk.disk
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/disks/fsamdatadiskfs-ccg-web2winvm"
}

# ── Data Disk Attachments ──────────────────────────────────────────────────────
# managed_disks.tf → resource "azurerm_virtual_machine_data_disk_attachment" "disk_attachments"
import {
  to = azurerm_virtual_machine_data_disk_attachment.disk_attachments["fs-ccg-app1-datadisk"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1/dataDisks/fsamdatadiskfs-ccg-app1winvm"
}
import {
  to = azurerm_virtual_machine_data_disk_attachment.disk_attachments["fs-ccg-app2-datadisk"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app2/dataDisks/fsamdatadiskfs-ccg-app2winvm"
}
import {
  to = azurerm_virtual_machine_data_disk_attachment.disk_attachments["fs-ccg-web1-datadisk"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1/dataDisks/fsamdatadiskfs-ccg-web1winvm"
}
import {
  to = azurerm_virtual_machine_data_disk_attachment.disk_attachments["fs-ccg-web2-datadisk"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2/dataDisks/fsamdatadiskfs-ccg-web2winvm"
}

# ── VM Extensions ──────────────────────────────────────────────────────────────

# enablevmAccess — app1 ONLY
import {
  to = azurerm_virtual_machine_extension.enable_vm_access["fs-ccg-app1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1/extensions/enablevmAccess"
}

# AADLogin — all 4 VMs (Azure portal name is "AADLogin")
import {
  to = azurerm_virtual_machine_extension.aad_login["fs-ccg-app1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1/extensions/AADLogin"
}
import {
  to = azurerm_virtual_machine_extension.aad_login["fs-ccg-app2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app2/extensions/AADLogin"
}
import {
  to = azurerm_virtual_machine_extension.aad_login["fs-ccg-web1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1/extensions/AADLogin"
}
import {
  to = azurerm_virtual_machine_extension.aad_login["fs-ccg-web2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2/extensions/AADLogin"
}

# IIS — web1 and web2 only
import {
  to = azurerm_virtual_machine_extension.iis_installer["fs-ccg-web1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1/extensions/IIS"
}
import {
  to = azurerm_virtual_machine_extension.iis_installer["fs-ccg-web2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2/extensions/IIS"
}

# MDE.Windows — all 4 VMs
import {
  to = azurerm_virtual_machine_extension.mde_windows["fs-ccg-app1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1/extensions/MDE.Windows"
}
import {
  to = azurerm_virtual_machine_extension.mde_windows["fs-ccg-app2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app2/extensions/MDE.Windows"
}
import {
  to = azurerm_virtual_machine_extension.mde_windows["fs-ccg-web1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1/extensions/MDE.Windows"
}
import {
  to = azurerm_virtual_machine_extension.mde_windows["fs-ccg-web2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2/extensions/MDE.Windows"
}

# AzurePolicyforWindows — all 4 VMs (deployed by Azure Policy)
import {
  to = azurerm_virtual_machine_extension.azure_policy["fs-ccg-app1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1/extensions/AzurePolicyforWindows"
}
import {
  to = azurerm_virtual_machine_extension.azure_policy["fs-ccg-app2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app2/extensions/AzurePolicyforWindows"
}
import {
  to = azurerm_virtual_machine_extension.azure_policy["fs-ccg-web1"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1/extensions/AzurePolicyforWindows"
}
import {
  to = azurerm_virtual_machine_extension.azure_policy["fs-ccg-web2"]
  id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2/extensions/AzurePolicyforWindows"
}

# =============================================================================
# BMW NESTED SUB-MODULE RESOURCES
# Cannot use import blocks — must use CLI after terraform apply above completes.
#
# Run these commands after the import blocks are successfully applied:
#
# terraform import \
#   'module.application_log_analytics.module.bmw_log_analytics_workspace.azurerm_log_analytics_workspace.this[0]' \
#   '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.OperationalInsights/workspaces/fsamccg-law'
#
# terraform import \
#   'module.application_storage_account.module.bmw_storage_account.azurerm_storage_account.this[0]' \
#   '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Storage/storageAccounts/fsamccgstprivatebmw'
#
# terraform import \
#   'module.application_storage_account.module.bmw_storage_account.azurerm_user_assigned_identity.storage_uai[0]' \
#   '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.ManagedIdentity/userAssignedIdentities/fsam-ccg-eus1-af-appdata-uamid-str'
#
# terraform import \
#   'module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_windows_virtual_machine.this[0]' \
#   '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app1'
#
# terraform import \
#   'module.application_vms["fs-ccg-app2"].module.bmw_vm.azurerm_windows_virtual_machine.this[0]' \
#   '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-app2'
#
# terraform import \
#   'module.application_vms["fs-ccg-web1"].module.bmw_vm.azurerm_windows_virtual_machine.this[0]' \
#   '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web1'
#
# terraform import \
#   'module.application_vms["fs-ccg-web2"].module.bmw_vm.azurerm_windows_virtual_machine.this[0]' \
#   '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/virtualMachines/fs-ccg-web2'
#
# For NICs (repeat for app2, web1, web2):
# terraform import \
#   'module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_network_interface.this[0]' \
#   '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkInterfaces/nic-fsamfs-ccg-app1winvm'
#
# For NSGs (repeat for app2, web1, web2):
# terraform import \
#   'module.application_vms["fs-ccg-app1"].module.bmw_vm.azurerm_network_security_group.this[0]' \
#   '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Network/networkSecurityGroups/nsg-fsamfs-ccg-app1winvm'
#
# terraform import \
#   'module.application_key_vault.module.bmw_key_vault.azurerm_key_vault.this[0]' \
#   '/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.KeyVault/vaults/fsamccg2-kv'
# =============================================================================
