# =================================================================================================
# File: terraform/env/uat/keyvault.tf
# =================================================================================================

module "application_key_vault" {
  source                      = "../../modules/keyvault"
  resource_group_name         = azurerm_resource_group.application_rg.name
  cloud_region                = var.cloud_region
  custom_name_suffix          = var.key_vault_custom_suffix
  sku_name                    = var.key_vault_sku_name
  enable_rbac_authorization   = false # Make it true if you have access to RBAC
  purge_protection_enabled    = var.key_vault_config_flags.purge_protection_enabled
  soft_delete_retention_days  = var.key_vault_config_flags.soft_delete_retention_days
  enabled_for_disk_encryption = var.key_vault_config_flags.enabled_for_disk_encryption
  global_config               = local.global_config_for_commons
  # global_config              = local.resource_name_prefix
  region_code                = local.number_bump
  tags                       = local.merged_tags
  create_diagnostic_settings = true
  log_analytics_workspace_id = module.application_log_analytics.log_analytics_id
  naming_file_json_tpl       = local.naming_json

  allowed_subnet_ids = [data.azurerm_subnet.app_subnet.id] #, data.azurerm_subnet.db_subnet.id]
  allowed_ips        = local.commons_allowed_ips

  network_acls_config = var.enable_keyvault_private_endpoint ? null : {
    default_action = contains(var.allowed_ips, "0.0.0.0/0") ? "Allow" : "Deny"
    bypass         = "AzureServices"
    ip_rules       = local.commons_allowed_ips
    virtual_network_subnet_ids = [
      data.azurerm_subnet.app_subnet.id
      # data.azurerm_subnet.db_subnet.id
    ]
  }

  depends_on = [
    azurerm_resource_group.application_rg,
    module.central_managed_identity,
    module.application_log_analytics,
    data.azurerm_subnet.app_subnet
  ]
}

# resource "azurerm_key_vault_secret" "vm_admin_password" {
#   count        = local.vm_password_is_from_kv ? 1 : 0
#   name         = var.vm_admin_password_kv_secret_name
#   value        = random_password.vm_admin_password_generator[0].result
#   key_vault_id = module.application_key_vault.id
#   tags         = local.merged_tags
#   content_type = "password"
#   depends_on   = [module.application_key_vault, random_password.vm_admin_password_generator, time_sleep.wait_for_kv_rbac_propagation]
# }

# resource "azurerm_key_vault_secret" "sql_mi_admin_password" {
#   count        = 1
#   name         = format("sqlMiAdminPassword-%s", var.sql_mi_custom_suffix)
#   value        = var.sql_mi_administrator_password
#   key_vault_id = module.application_key_vault.id
#   tags         = local.merged_tags
#   content_type = "password"
#   depends_on   = [module.application_key_vault, time_sleep.wait_for_kv_rbac_propagation]
# }

# resource "azurerm_key_vault_key" "storage_cmk" {
#   name         = format("cmk-%s-st-%s", local.resource_name_prefix, var.storage_account_main_custom_suffix)
#   key_vault_id = module.application_key_vault.id
#   key_type     = "RSA"
#   key_size     = 2048
#   key_opts     = ["unwrapKey", "wrapKey"]
#   tags         = local.merged_tags
#   depends_on   = [module.application_key_vault]
# }

# resource "azurerm_key_vault_key" "sql_mi_tde_cmk" {
#   count        = var.sql_mi_tde_key_vault_key_id == null ? 1 : 0
#   name         = format("cmk-%s-sqlmi-%s-tde", local.resource_name_prefix, var.sql_mi_custom_suffix)
#   key_vault_id = module.application_key_vault.id
#   key_type     = "RSA"
#   key_size     = 2048
#   key_opts     = ["unwrapKey", "wrapKey"]
#   tags         = local.merged_tags
#   depends_on   = [module.application_key_vault]
# }

# resource "time_sleep" "wait_for_kv_rbac_propagation" {
#   depends_on      = [module.application_key_vault] #, azurerm_role_assignment.deployer_kv_admin_roles]
#   create_duration = "30s"
# }
