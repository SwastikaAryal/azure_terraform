# =================================================================================================
# File: terraform/env/uat/sql.tf
# =================================================================================================

# module "application_sql_managed_instance" {
#   source              = "../../modules/sql_managed_instance"
#   resource_group_name = azurerm_resource_group.application_rg.name
#   cloud_region        = var.cloud_region
#   custom_name_suffix  = var.sql_mi_custom_suffix
#   global_config       = local.global_config_for_commons
#   region_code         = local.number_bump
#   tags                = local.merged_tags

#   administrator_login    = var.sql_mi_administrator_login
#   administrator_password = var.sql_mi_administrator_password

#   sku_name                         = var.sql_mi_config_details.sku_name
#   vcores                           = var.sql_mi_config_details.vcores
#   storage_size_in_gb               = var.sql_mi_config_details.storage_size_in_gb
#   license_type                     = var.sql_mi_config_details.license_type
#   subnet_id                        = data.azurerm_subnet.db_subnet.id
#   maintenance_configuration_name   = var.sql_mi_config_details.maintenance_configuration_name
#   databases_to_create              = var.sql_mi_config_details.databases
#   user_assigned_identity_ids       = [module.central_managed_identity.id]
#   collation                        = var.sql_mi_config_details.collation
#   proxy_override                   = var.sql_mi_config_details.proxy_override
#   public_data_endpoint_enabled     = var.sql_mi_config_details.public_data_endpoint_enabled
#   timezone_id                      = var.sql_mi_config_details.timezone_id
#   storage_account_type_for_backups = var.sql_mi_config_details.storage_account_type

#   vulnerability_assessment_enabled                 = true
#   vulnerability_assessment_storage_container_path  = format("https://%s.blob.core.windows.net/sqlvulnerabilityassessment/", module.application_storage_account.name)
#   vulnerability_assessment_recurring_scans_enabled = true
#   vulnerability_assessment_emails                  = ["Shravan.Chiduruppa@bmwfs.com"]
#   vulnerability_assessment_email_admins            = true

#   ad_admin_login_username     = var.sql_mi_ad_admin_config.login_username
#   ad_admin_object_id          = var.sql_mi_ad_admin_config.object_id
#   ad_admin_tenant_id          = var.sql_mi_ad_admin_config.login_username != null ? data.azurerm_client_config.current.tenant_id : null
#   azuread_authentication_only = var.sql_mi_ad_admin_config.azuread_authentication_only
#   # enable_tde_cmk                      = var.sql_mi_tde_key_vault_key_id != null || (length(azurerm_key_vault_key.sql_mi_tde_cmk) > 0 && var.sql_mi_tde_key_vault_key_id == null)
#   # tde_cmk_key_vault_key_id_for_module = var.sql_mi_tde_key_vault_key_id != null ? var.sql_mi_tde_key_vault_key_id : (length(azurerm_key_vault_key.sql_mi_tde_cmk) > 0 ? azurerm_key_vault_key.sql_mi_tde_cmk[0].id : null)
#   tde_cmk_auto_rotation_enabled = true

#   depends_on = [
#     # module.application_storage_account,
#     module.central_managed_identity,
#     data.azurerm_subnet.db_subnet,
#     module.application_key_vault,
#     # azurerm_key_vault_key.sql_mi_tde_cmk
#   ]
# }

# resource "azurerm_database_migration_service" "dms" {
#   count               = var.enable_database_migration_service ? 1 : 0
#   name                = format("%s-%s", local.resource_name_prefix, "adms")
#   resource_group_name = azurerm_resource_group.application_rg.name
#   location            = var.cloud_region
#   sku_name            = "Standard_1vCores"
#   subnet_id           = data.azurerm_subnet.app_subnet.id
#   tags                = local.merged_tags
#   lifecycle {
#     ignore_changes = [tags] # Temp to all
#   }
#   depends_on = [azurerm_resource_group.application_rg, data.azurerm_subnet.app_subnet]
# }
