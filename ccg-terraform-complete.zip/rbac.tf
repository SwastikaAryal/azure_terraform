# =================================================================================================
# File: terraform/env/ccg/rbac.tf
# =================================================================================================
# Role assignments are NOT present in the ARM export of FSAM-CLEANCONFIG-RG.
# All resource blocks are commented out to prevent 24+ "to add" role assignments in plan.
# Uncomment only after verifying these roles are actually needed and don't already exist.
# =================================================================================================

locals {
  central_identity_kv_roles = [
    "Key Vault Secrets Officer", "Key Vault Crypto Service Encryption User",
    "Key Vault Secrets User", "Key Vault Reader",
    "Key Vault Certificates Officer"
  ]
  central_identity_storage_roles = [
    "Storage Blob Data Reader", "Storage Blob Data Contributor", "Storage Account Backup Contributor",
    "Storage Account Contributor", "Storage Blob Data Owner", "Storage Blob Delegator",
    "Storage File Data SMB Share Contributor", "Storage File Data SMB Share Reader",
    "Storage Queue Data Contributor", "Storage Queue Data Message Processor",
    "Storage Queue Data Message Sender", "Storage Queue Data Reader",
    "Storage Table Data Contributor", "Storage Table Data Reader"
  ]
  deployer_kv_management_roles = ["Key Vault Administrator", "Key Vault Contributor"]
  central_identity_rg_roles = {
    "Reader"                      = "Reader"
    "Virtual Machine Contributor" = "Virtual Machine Contributor"
    "Virtual Machine User Login"  = "Virtual Machine User Login"
    "Contributor"                 = "Contributor"
    "Log Analytics Contributor"   = "Log Analytics Contributor"
  }
}

# resource "azurerm_role_assignment" "central_identity_kv_access" {
#   for_each             = toset(local.central_identity_kv_roles)
#   scope                = module.application_key_vault.id
#   role_definition_name = each.value
#   principal_id         = module.central_managed_identity.principal_id
#   depends_on           = [module.application_key_vault, module.central_managed_identity]
# }

# resource "azurerm_role_assignment" "central_identity_storage_access" {
#   for_each             = toset(local.central_identity_storage_roles)
#   scope                = module.application_storage_account.id
#   role_definition_name = each.value
#   principal_id         = module.central_managed_identity.principal_id
#   depends_on           = [module.application_storage_account, module.central_managed_identity]
# }

# resource "azurerm_role_assignment" "central_identity_rg_scoped_roles" {
#   for_each             = local.central_identity_rg_roles
#   scope                = azurerm_resource_group.application_rg.id
#   role_definition_name = each.value
#   principal_id         = module.central_managed_identity.principal_id
#   depends_on           = [azurerm_resource_group.application_rg, module.central_managed_identity]
# }

# resource "azurerm_role_assignment" "deployer_kv_admin_roles" {
#   for_each             = toset(local.deployer_kv_management_roles)
#   scope                = module.application_key_vault.id
#   role_definition_name = each.value
#   principal_id         = data.azurerm_client_config.current.object_id
#   depends_on           = [module.application_key_vault, data.azurerm_client_config.current]
# }
