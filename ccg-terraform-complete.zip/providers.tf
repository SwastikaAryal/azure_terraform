# =================================================================================================
# File: terraform/env/uat/provider.tf
# Environment: UAT
# =================================================================================================

terraform {
  required_version = ">= 1.7.2"

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.27.0"
    }
    random = {
      source  = "hashicorp/random"
      version = ">= 3.7.1"
    }
    time = {
      source  = "hashicorp/time"
      version = ">= 0.13.1"
    }
    azuread = {
      source  = "hashicorp/azuread"
      version = ">= 3.2.0"
    }
  }

  # Backend configuration for remote state.
  # IMPORTANT: The Resource Group, Storage Account, and Container specified below
  # MUST exist BEFORE you run 'terraform init'. Terraform does not create these backend resources as part of the same configuration that uses them.  
  backend "azurerm" {
    resource_group_name  = "FSAM-DEV-BACKEND-RG"
    storage_account_name = "fsamdevbeprivatebmw"
    container_name       = "tfstate"
    key                  = "terraform-ccg.tfstate"
  }
}


provider "azurerm" {
  features {
    key_vault {
      purge_soft_delete_on_destroy               = true
      recover_soft_deleted_key_vaults            = true
      purge_soft_deleted_keys_on_destroy         = true
      purge_soft_deleted_secrets_on_destroy      = true
      purge_soft_deleted_certificates_on_destroy = true
    }
    resource_group {
      prevent_deletion_if_contains_resources = true
    }
  }
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id
  use_oidc        = true
}

provider "azuread" {}
