# =================================================================================================
# File: terraform/env/ccg/vm_automations.tf
# =================================================================================================
# The external module "azurerm-vm-automation-runbooks" creates runbooks, schedules, variables,
# webhooks, and action groups that ALREADY EXIST in Azure portal (from ARM export).
#
# Leaving this active causes Terraform to either create duplicates (adds) or conflict
# with the existing resources. Commented out for the import phase.
#
# After all imports complete and plan shows zero changes, this can be re-evaluated.
# =================================================================================================

# module "vm_automation_idle_resources" {
#   source = "git::https://atc-github.azure.cloud.bmw/fsam-sa/azurerm-vm-automation-runbooks.git"
#
#   resource_group_name          = azurerm_resource_group.application_rg.name
#   location                     = var.cloud_region
#   automation_account_name      = module.application_automation_account.name
#   log_analytics_workspace_name = module.application_log_analytics.log_analytics_name
#   action_group_name            = "ag-vm-automation"
#   action_group_short_name      = "vmauto"
#   vm_idle_threshold_hours      = 2
#   vm_cpu_threshold             = 5
#   vm_network_threshold_mb      = 10
#   vm_disk_threshold_mb         = 50
#   business_hours_start         = "08:00"
#   business_hours_end           = "18:00"
#   business_days                = [1, 2, 3, 4, 5]
#   timezone                     = "America/New_York"
#   enable_idle_detection        = true
#   enable_scheduled_shutdown    = true
#   excluded_vm_tags = {
#     "AutoShutdown"   = "Disabled"
#     "Environment"    = "Gold"
#     "AlwaysOn"       = "true"
#     "DatabaseServer" = "true"
#   }
#   required_vm_tags             = { "CostCenter" = "*" }
#   exclude_vm_sizes             = ["Standard_M*", "Standard_N*"]
#   target_vm_sizes              = ["Standard_F*"]
#   target_resource_groups       = [azurerm_resource_group.application_rg.name]
#   notification_emails          = ["Miguel.MA.Araujo@partner.bmwgroup.com", "Shaikh.Islam@partner.bmwfs.com"]
#   enable_vm_deallocate         = true
#   vm_grace_period_minutes      = 15
#   vm_shutdown_timeout_minutes  = 10
#   enable_startup_automation    = true
#   startup_delay_minutes        = 5
#   enable_cost_analysis         = true
#   cost_analysis_retention_days = 90
#   dry_run_mode                 = true
#   tags = {
#     Environment = "CleanConfig"
#     Purpose     = "VMCostOptimization"
#     ManagedBy   = "Terraform"
#     Team        = "FSCloudTeam"
#   }
#   depends_on = [module.application_vms]
# }
