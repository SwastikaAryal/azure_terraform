# =================================================================================================
# File: terraform/env/ccg/vm.tf
# =================================================================================================

module "application_vms" {
  source   = "../../modules/virtual_machine"
  for_each = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf }

  resource_group_name                  = azurerm_resource_group.application_rg.name
  cloud_region                         = var.cloud_region
  custom_name_suffix                   = each.value.custom_suffix
  global_config                        = local.global_config_for_commons
  region_code                          = local.number_bump
  tags                                 = local.merged_tags
  subnet_id                            = data.azurerm_subnet.app_subnet.id
  app_subnet_name                      = var.app_subnet_name
  virtual_network_name                 = var.virtual_network_name
  vnet_resource_group_name             = var.vnet_resource_group_name
  vm_size                              = each.value.size
  admin_username                       = var.vm_admin_username
  os_type                              = "Windows"
  source_image_id                      = var.vm_image_source_id
  admin_password_key_vault_secret_id   = var.admin_password_key_vault_secret_id
  admin_password_direct_for_bmw_module = null
  enable_system_assigned_identity      = false
  user_assigned_identity_ids           = [module.central_managed_identity.id]
  log_analytics_workspace_id           = module.application_log_analytics.log_analytics_id
  log_analytics_primary_shared_key     = module.application_log_analytics.log_analytics_primary_shared_key
  boot_diagnostics_enabled             = true
  windows_patch_mode                   = var.windows_patch_mode
  naming_file_json_tpl                 = local.naming_json
  secure_boot_enabled                  = var.secure_boot_enabled
  vtpm_enabled                         = var.vtpm_enabled
}

# =============================================================================
# VM EXTENSIONS
# IMPORTANT: Extension names below match EXACTLY what is in Azure portal
# (confirmed from ARM export). Do NOT rename — wrong name = destroy + recreate.
# =============================================================================

# enablevmAccess — exists on app1 ONLY (not on app2, web1, web2)
resource "azurerm_virtual_machine_extension" "enable_vm_access" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if vm_conf.custom_suffix == "fs-ccg-app1" }
  name                       = "enablevmAccess"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Compute"
  type                       = "VMAccessAgent"
  type_handler_version       = "2.0"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = false
  settings = jsonencode({
    "UserName" = var.vm_admin_username
  })
  tags       = local.merged_tags
  depends_on = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, type_handler_version, settings, protected_settings]
  }
}

# AADLogin — all 4 VMs. Azure portal name is "AADLogin" (not "AADLoginForWindows")
resource "azurerm_virtual_machine_extension" "aad_login" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "AADLogin") }
  name                       = "AADLogin"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Azure.ActiveDirectory"
  type                       = "AADLoginForWindows"
  type_handler_version       = "2.2"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = false
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, type_handler_version, settings, protected_settings]
  }
}

# IIS — web1 and web2 only
resource "azurerm_virtual_machine_extension" "iis_installer" {
  for_each             = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "IIS") }
  name                 = "IIS"
  virtual_machine_id   = module.application_vms[each.key].id
  publisher            = "Microsoft.Compute"
  type                 = "CustomScriptExtension"
  type_handler_version = "1.10"
  settings = jsonencode({
    commandToExecute = "powershell -ExecutionPolicy Bypass -Command \"Install-WindowsFeature Web-Server -IncludeManagementTools; Install-WindowsFeature Web-Asp-Net45\""
  })
  tags       = local.merged_tags
  depends_on = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, type_handler_version, settings, protected_settings]
  }
}

# MDE.Windows — all 4 VMs
resource "azurerm_virtual_machine_extension" "mde_windows" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "MDE") }
  name                       = "MDE.Windows"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Azure.AzureDefenderForServers"
  type                       = "MDE.Windows"
  type_handler_version       = "1.0"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = true
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, type_handler_version, settings, protected_settings]
  }
}

# AzurePolicyforWindows — deployed automatically by Azure Policy on all 4 VMs.
# Declared here so it can be imported and stop showing as drift.
resource "azurerm_virtual_machine_extension" "azure_policy" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf }
  name                       = "AzurePolicyforWindows"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.GuestConfiguration"
  type                       = "ConfigurationforWindows"
  type_handler_version       = "1.29"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = true
  settings                   = jsonencode({})
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, type_handler_version, settings, protected_settings]
  }
}

# VMSS — NOT deployed in CCG. create_vmss = false so for_each is empty.
module "application_vmss" {
  for_each            = var.create_vmss ? { "vmss1" = {} } : {}
  source              = "../../modules/vm_scale_set"
  resource_group_name = azurerm_resource_group.application_rg.name
  location            = var.cloud_region
  custom_name_suffix  = var.vmss_custom_suffix
  global_config       = local.global_config_for_commons
  region_code         = local.number_bump
  tags                = local.merged_tags
  subnet_id           = [data.azurerm_subnet.app_subnet.id]
  vm_sku              = var.vmss_sku_name
  instances_count     = var.vmss_instances_count
  admin_username      = var.vm_admin_username
  os_type             = "Windows"
  source_image_id     = var.vm_image_source_id
  key_vault_id        = module.application_key_vault.id
  admin_password_key_vault_secret_id = "$vmscale@123"
  user_assigned_identity_ids         = [module.central_managed_identity.id]
  virtual_network_name               = var.virtual_network_name
  vnet_resource_group_name           = var.vnet_resource_group_name
  des_key_expiration_date            = "2027-12-31T23:59:59Z"
  depends_on                         = [data.azurerm_subnet.app_subnet, module.central_managed_identity]
}
