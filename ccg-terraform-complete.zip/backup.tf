# # =================================================================================================
# # File: terraform/env/uat/backup.tf
# # =================================================================================================

# module "application_recovery_services_vault" {
#   source              = "../../modules/recovery_services_vault"
#   resource_group_name = azurerm_resource_group.application_rg.name
#   cloud_region        = var.cloud_region
#   custom_name_suffix  = var.recovery_services_vault_custom_suffix
#   global_config       = local.global_config_for_commons
#   # global_config = local.resource_name_prefix
#   region_code = local.number_bump
#   tags        = local.merged_tags

#   sku                 = var.recovery_services_vault_sku
#   soft_delete_enabled = var.recovery_services_vault_config_flags.soft_delete_enabled
#   storage_mode_type   = var.recovery_services_vault_config_flags.storage_mode_type

#   vm_backup_policies = {
#     (var.vm_backup_policy_default_config.name) = {
#       frequency       = var.vm_backup_policy_default_config.frequency
#       time            = var.vm_backup_policy_default_config.time
#       timezone        = var.vm_backup_policy_default_config.timezone
#       retention_daily = { count = var.vm_backup_policy_default_config.retention_daily_count }
#     }
#   }
#   depends_on = [azurerm_resource_group.application_rg]
# }

# module "uat_backup_vault" {
#   source              = "../../modules/backup_vault"
#   enable_backup_vault = true
#   global_config       = local.global_config_for_commons # Or appropriate common config
#   # global_config              = local.resource_name_prefix
#   location                   = var.cloud_region # e.g., "eastus"
#   resource_group_name        = azurerm_resource_group.application_rg.name
#   region_code                = local.number_bump         # e.g., "eus1"
#   custom_name_suffix         = var.custom_name_suffix_bv # e.g., "uat" or specific identifier
#   datastore_type             = "VaultStore"              # Or "ArchiveStore"
#   redundancy                 = "GeoRedundant"            # Or "LocallyRedundant"
#   soft_delete_state          = "On"                      # Or "Off"
#   retention_duration_in_days = var.backup_vault_retention_days
#   tags                       = local.merged_tags
#   naming_file_json_tpl       = local.naming_json
# }
