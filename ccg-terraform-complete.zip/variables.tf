# =================================================================================================
# File: terraform/env/ccg/variables.tf
# =================================================================================================

variable "environment" {
  description = "The deployment environment."
  type        = string
}

variable "subscription_id" {
  description = "Azure Subscription ID."
  type        = string
  sensitive   = true
}

variable "tenant_id" {
  description = "Azure Tenant ID."
  type        = string
  sensitive   = true
}

variable "cloud_region" {
  description = "Azure region for the deployment."
  type        = string
}

variable "global_config_base" {
  description = "Base global configuration for BMW modules."
  type = object({
    customer_prefix = string
    env             = string
    product_id      = string
    appd_id         = string
    app_name        = string
    costcenter      = string
    tags            = map(string)
  })
}

variable "custom_tags_override" {
  description = "Custom tags to merge."
  type        = map(string)
  default     = {}
}

variable "resource_group_name_override" {
  description = "Optional override for the resource group name."
  type        = string
  default     = ""
}

variable "virtual_network_name" {
  description = "Name of the existing Virtual Network."
  type        = string
  default     = "VNET-SPOKE-EUS-10882"
}

variable "vnet_resource_group_name" {
  description = "Resource group of the existing Virtual Network."
  type        = string
}

variable "app_subnet_name" {
  description = "Name of the existing application subnet."
  type        = string
}

variable "allowed_ips" {
  description = "List of allowed IP CIDRs."
  type        = list(string)
}

variable "vm_image_source_id" {
  description = "Source image ID for Windows VMs."
  type        = string
}

variable "vm_admin_username" {
  description = "Admin username for VMs."
  type        = string
}

variable "vm_admin_password_kv_secret_name" {
  description = "Name of the Key Vault secret for VM admin password."
  type        = string
  default     = "vmAdminPassword"
}

variable "admin_password_key_vault_secret_id" {
  description = "Password for the VMs."
  type        = string
  default     = "$vmcompute@123"
}

variable "vm_configurations" {
  description = "Configuration for the virtual machines."
  type = list(object({
    custom_suffix         = string
    size                  = string
    extensions_to_install = optional(list(string), [])
  }))
  default = [
    { custom_suffix = "fs-ccg-app1", size = "Standard_F8s_v2", extensions_to_install = ["AADLogin", "MDE"] },
    { custom_suffix = "fs-ccg-app2", size = "Standard_F8s_v2", extensions_to_install = ["AADLogin", "MDE"] },
    { custom_suffix = "fs-ccg-web1", size = "Standard_F8s_v2", extensions_to_install = ["IIS", "AADLogin", "MDE"] },
    { custom_suffix = "fs-ccg-web2", size = "Standard_F8s_v2", extensions_to_install = ["IIS", "AADLogin", "MDE"] }
  ]
}

variable "windows_patch_mode" {
  type        = string
  description = "In-guest patching mode. Possible values: Manual, AutomaticByOS, AutomaticByPlatform."
  default     = "AutomaticByOS"
}

variable "secure_boot_enabled" {
  description = "Whether secure boot is enabled on the virtual machine."
  type        = bool
  default     = false
}

variable "vtpm_enabled" {
  description = "Whether vTPM is enabled on the virtual machine."
  type        = bool
  default     = false
}

variable "standalone_managed_disks_config" {
  description = "Configuration for standalone managed disks."
  type = list(object({
    vm_custom_suffix     = string
    disk_custom_suffix   = string
    disk_size_gb         = number
    lun                  = number
    caching              = string
    storage_account_type = string
  }))
  default = [
    { vm_custom_suffix = "fs-ccg-app1", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
    { vm_custom_suffix = "fs-ccg-app2", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
    { vm_custom_suffix = "fs-ccg-web1", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" },
    { vm_custom_suffix = "fs-ccg-web2", disk_custom_suffix = "datadisk", disk_size_gb = 100, lun = 0, caching = "ReadWrite", storage_account_type = "StandardSSD_ZRS" }
  ]
}

variable "key_vault_custom_suffix" {
  type    = string
  default = "kv"
}

variable "key_vault_sku_name" {
  type    = string
  default = "standard"
}

variable "key_vault_config_flags" {
  type = object({
    enabled_for_disk_encryption = optional(bool, true)
    purge_protection_enabled    = optional(bool, true)
    soft_delete_retention_days  = optional(number, 90)
  })
  default = { enabled_for_disk_encryption = true, purge_protection_enabled = true, soft_delete_retention_days = 90 }
}

variable "storage_account_main_custom_suffix" {
  type    = string
  default = "appdata"
}

variable "storage_account_main_config" {
  type = object({
    tier                            = string
    replication_type                = string
    allow_blob_public_access        = optional(bool, false)
    public_network_access_enabled   = optional(bool, false)
    shared_access_key_enabled       = optional(bool, true)
    min_tls_version                 = optional(string, "TLS1_2")
    default_to_oauth_authentication = optional(bool, true)
  })
  default = { tier = "Standard", replication_type = "ZRS", allow_blob_public_access = false, public_network_access_enabled = false, shared_access_key_enabled = true, min_tls_version = "TLS1_2", default_to_oauth_authentication = true }
}

variable "enable_storage_private_endpoints" {
  type    = bool
  default = true
}

variable "log_analytics_custom_suffix" {
  type    = string
  default = "log"
}

variable "log_analytics_sku" {
  type    = string
  default = "PerGB2018"
}

variable "log_analytics_retention_in_days" {
  type    = number
  default = 90
}

variable "app_insights_custom_suffix" {
  type    = string
  default = "aapin"
}

variable "app_insights_application_type" {
  type    = string
  default = "web"
}

variable "automation_account_custom_suffix" {
  type    = string
  default = "auto"
}

variable "automation_account_sku_name" {
  type    = string
  default = "Basic"
}

variable "automation_module_names" {
  type    = list(string)
  default = []
}

variable "automation_account_connection_types_config" {
  type = list(object({
    name      = string
    is_global = bool
    fields = list(object({
      name         = string
      type         = string
      is_encrypted = bool
      is_optional  = bool
    }))
  }))
  default = []
}

variable "recovery_services_vault_custom_suffix" {
  type    = string
  default = "rsv"
}

variable "recovery_services_vault_sku" {
  type    = string
  default = "RS0"
}

variable "recovery_services_vault_config_flags" {
  type = object({
    soft_delete_enabled = optional(bool, true)
    storage_mode_type   = optional(string, "GeoRedundant")
  })
  default = { soft_delete_enabled = true, storage_mode_type = "GeoRedundant" }
}

variable "vm_backup_policy_default_config" {
  type = object({
    name                  = string
    frequency             = string
    time                  = string
    timezone              = string
    retention_daily_count = number
  })
  default = {
    name                  = "DefaultBackupPolicy"
    frequency             = "Daily"
    time                  = "23:00"
    timezone              = "UTC"
    retention_daily_count = 30
  }
}

variable "central_managed_identity_custom_suffix" {
  type    = string
  default = "central"
}

variable "load_balancer_custom_suffix" {
  type    = string
  default = "app"
}

variable "create_vmss" {
  type    = bool
  default = false
}

variable "vmss_custom_suffix" {
  type    = string
  default = "vmss"
}

variable "vmss_sku_name" {
  type    = string
  default = "Standard_F4s_v2"
}

variable "vmss_instances_count" {
  type    = number
  default = 2
}

variable "vmss_admin_password_kv_secret_name" {
  type    = string
  default = "vmssAdminPassword"
}

variable "enable_keyvault_private_endpoint" {
  type    = bool
  default = false
}

variable "enable_automation_private_endpoint" {
  type    = bool
  default = false
}

variable "enable_network_private_endpoint" {
  type    = bool
  default = false
}

variable "enable_database_migration_service" {
  type    = bool
  default = false
}

variable "user_assigned_identity_id" {
  type    = string
  default = null
}

variable "os_type" {
  description = "The operating system type for the VM."
  type        = string
  default     = "Windows"
}

variable "backup_vault_retention_days" {
  type    = string
  default = 14
}

variable "custom_name_suffix_bv" {
  type    = string
  default = "bv"
}

variable "queue_properties" {
  type    = any
  default = null
}

variable "blob_properties" {
  type    = any
  default = null
}

variable "share_properties" {
  type    = any
  default = null
}

variable "private_link_access" {
  type = map(object({
    endpoint_resource_id = string
    endpoint_tenant_id   = string
  }))
  default     = {}
  description = "Private link access configuration"
}
