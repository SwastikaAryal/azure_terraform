# =================================================================================================
# File: terraform/env/uat/data.tf
# =================================================================================================

data "azurerm_client_config" "current" {}

data "azurerm_subscription" "current_subscription" {}

data "azurerm_subnet" "app_subnet" {
  name                 = var.app_subnet_name
  virtual_network_name = var.virtual_network_name
  resource_group_name  = var.vnet_resource_group_name
  depends_on           = [azurerm_resource_group.application_rg]
}

# data "azurerm_subnet" "db_subnet" {
#   name                 = var.db_subnet_name
#   virtual_network_name = var.virtual_network_name
#   resource_group_name  = var.vnet_resource_group_name
#   depends_on           = [azurerm_resource_group.application_rg]
# }
