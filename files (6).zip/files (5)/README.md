# MINITRUE Backup & Recovery – Terraform Module

## File Structure

| File | MINITRUE Ticket | Purpose |
|------|----------------|---------|
| `main.tf` | All | Provider, terraform config, locals |
| `variables.tf` | All | Input variables |
| `rsv_vault.tf` | **9348** | Recovery Services Vault, Standard & Enhanced backup policies, VM protection |
| `backup_policies.tf` | **9418** | Selective disk backup (temp disk exclusion), policy outputs |
| `restore_testing.tf` | **9414** | Automation Account + 3 PowerShell runbooks for restore validation |
| `disk_snapshots.tf` | **9416** | Data Protection Backup Vault, disk snapshot policies, cross-region copy, cleanup policy |
| `monitoring.tf` | **Sprint 3** | Log Analytics, diagnostic settings, metric/query alerts, saved queries, workbook |
| `outputs.tf` | All | Key resource IDs |
| `terraform.tfvars.example` | - | Fill in your values |

---

## Prerequisites

1. Azure CLI authenticated: `az login`
2. Terraform >= 1.5.0
3. Resource group already created (or add `azurerm_resource_group` to `main.tf`)
4. Snapshot resource group already created

---

## Deploy

```bash
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your VM IDs, emails, etc.

terraform init
terraform plan -out=tfplan
terraform apply tfplan
```

---

## MINITRUE-9414 – Restore Validation Runbook Usage

After deployment, the runbooks are in the Automation Account. Trigger them manually or via schedule:

### Task 1: Full restore to original location
```powershell
Start-AzAutomationRunbook `
  -AutomationAccountName "aa-minitrue-backup-restore" `
  -ResourceGroupName     "rg-minitrue-backup" `
  -Name                  "Invoke-FullVMRestore" `
  -Parameters @{
    VaultName         = "rsv-minitrue-backup"
    ResourceGroupName = "rg-minitrue-backup"
    VMName            = "app-vm-01"
    RestoreMode       = "OriginalLocation"
  }
```

### Task 2: Full restore to alternate location
```powershell
Start-AzAutomationRunbook `
  -AutomationAccountName "aa-minitrue-backup-restore" `
  -ResourceGroupName     "rg-minitrue-backup" `
  -Name                  "Invoke-FullVMRestore" `
  -Parameters @{
    VaultName             = "rsv-minitrue-backup"
    ResourceGroupName     = "rg-minitrue-backup"
    VMName                = "app-vm-01"
    RestoreMode           = "AlternateLocation"
    TargetResourceGroup   = "rg-minitrue-dr"
    TargetVNetName        = "vnet-dr"
    TargetSubnetName      = "snet-restore"
  }
```

### Task 3: Individual disk restore
```powershell
Start-AzAutomationRunbook `
  -AutomationAccountName "aa-minitrue-backup-restore" `
  -ResourceGroupName     "rg-minitrue-backup" `
  -Name                  "Invoke-DiskRestore" `
  -Parameters @{
    VaultName                    = "rsv-minitrue-backup"
    ResourceGroupName            = "rg-minitrue-backup"
    VMName                       = "app-vm-01"
    TargetStorageAccountName     = "saminitruerestore"
    TargetStorageAccountRG       = "rg-minitrue-backup"
  }
```

### Task 4: File-level recovery (ILR)
```powershell
Start-AzAutomationRunbook `
  -AutomationAccountName "aa-minitrue-backup-restore" `
  -ResourceGroupName     "rg-minitrue-backup" `
  -Name                  "Invoke-FileLevelRecovery" `
  -Parameters @{
    VaultName        = "rsv-minitrue-backup"
    ResourceGroupName = "rg-minitrue-backup"
    VMName           = "app-vm-01"
    ScriptOutputPath = "C:\Temp\ILR-script.ps1"
  }
```

---

## Backup Policy Summary

| Policy | Type | Frequency | Daily | Weekly | Monthly | Yearly | Instant Restore |
|--------|------|-----------|-------|--------|---------|--------|-----------------|
| Standard | V1 | Daily 23:00 | 30d | 12w | 12m | 3y | 5d |
| Enhanced | V2 | Hourly/4h | 30d | 12w | 12m | 3y | 7d |
| OS Disk Snapshot | Disk | Every 4h | — | 4w | — | — | 7d |
| Data Disk Snapshot | Disk | Daily 23:00 | — | 4w | — | — | 7d |

---

## Alert Summary (Sprint 3)

| Alert | Trigger | Severity |
|-------|---------|----------|
| Backup Job Failure | Any backup job fails | Critical (1) |
| Backup Stale | No backup in 24h | Warning (2) |
| Vault Health Degraded | BackupHealthEvent > 0 | Critical (1) |
