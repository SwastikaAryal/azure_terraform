# =================================================================================================
# File: terraform/env/ccg/vm.tf
# Fixes applied (from CCG_Plan_Analysis.xlsx):
#   Step 1  — lifecycle ignore_changes = [virtual_machine_id] on all 5 extension resources
#   Step 2  — os_disk_storage_account_type = "StandardSSD_LRS" (state=LRS, default=ZRS → REPLACE)
#   Step 2  — enable_encryption_at_host = false (state=false, default=true → REPLACE)
#   Step 2  — proximity_placement_group_id passed (exists in state, was missing → REPLACE)
#   Step 8  — accelerated_networking_enabled = true (state=true, default=false → UPDATE)
# =================================================================================================

module "application_vms" {
  source   = "../../modules/virtual_machine"
  for_each = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf }

  resource_group_name                  = azurerm_resource_group.application_rg.name
  cloud_region                         = var.cloud_region
  custom_name_suffix                   = each.value.custom_suffix
  global_config                        = local.global_config_for_commons
  region_code                          = local.number_bump
  tags                                 = local.merged_tags
  subnet_id                            = data.azurerm_subnet.app_subnet.id
  app_subnet_name                      = var.app_subnet_name
  virtual_network_name                 = var.virtual_network_name
  vnet_resource_group_name             = var.vnet_resource_group_name
  vm_size                              = each.value.size
  admin_username                       = var.vm_admin_username
  os_type                              = "Windows"
  source_image_id                      = var.vm_image_source_id
  admin_password_key_vault_secret_id   = var.admin_password_key_vault_secret_id
  admin_password_direct_for_bmw_module = null
  enable_system_assigned_identity      = false
  user_assigned_identity_ids           = [module.central_managed_identity.id]
  log_analytics_workspace_id           = module.application_log_analytics.log_analytics_id
  log_analytics_primary_shared_key     = module.application_log_analytics.log_analytics_primary_shared_key
  boot_diagnostics_enabled             = true
  windows_patch_mode                   = var.windows_patch_mode
  naming_file_json_tpl                 = local.naming_json
  secure_boot_enabled                  = var.secure_boot_enabled
  vtpm_enabled                         = var.vtpm_enabled

  # ── Values confirmed from ARM state to prevent REPLACE on all 4 VMs ──────────
  # OS disk: state = StandardSSD_LRS; module default = StandardSSD_ZRS → forces replacement
  os_disk_storage_account_type = "StandardSSD_LRS"
  # Encryption at host: state = false; module default = true → forces replacement
  enable_encryption_at_host = false
  # Accelerated networking: state = true; module default = false → in-place update (NIC)
  accelerated_networking_enabled = true
  # Proximity Placement Group: exists in state for all 4 VMs → must be passed to avoid REPLACE
  proximity_placement_group_id = "/subscriptions/4cda8977-68ea-4ca5-aa6a-fae45e7e98f3/resourceGroups/FSAM-CLEANCONFIG-RG/providers/Microsoft.Compute/proximityPlacementGroups/fsamccg-ppg"
}

# =============================================================================
# VM EXTENSIONS
# IMPORTANT: Extension names match EXACTLY what is in Azure portal (from ARM export).
# Do NOT rename — wrong name = destroy + recreate.
#
# virtual_machine_id in ignore_changes: prevents forced replacement when the BMW
# VM module's internal resource path is "(known after apply)" during plan.
# =============================================================================

# enablevmAccess — app1 ONLY
resource "azurerm_virtual_machine_extension" "enable_vm_access" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if vm_conf.custom_suffix == "fs-ccg-app1" }
  name                       = "enablevmAccess"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Compute"
  type                       = "VMAccessAgent"
  type_handler_version       = "2.0"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = false
  settings = jsonencode({
    "UserName" = var.vm_admin_username
  })
  tags       = local.merged_tags
  depends_on = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, type_handler_version, settings, protected_settings, virtual_machine_id]
  }
}

# AADLogin — all 4 VMs
resource "azurerm_virtual_machine_extension" "aad_login" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "AADLogin") }
  name                       = "AADLogin"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Azure.ActiveDirectory"
  type                       = "AADLoginForWindows"
  type_handler_version       = "2.2"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = false
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, type_handler_version, settings, protected_settings, virtual_machine_id]
  }
}

# IIS — web1 and web2 only
resource "azurerm_virtual_machine_extension" "iis_installer" {
  for_each             = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "IIS") }
  name                 = "IIS"
  virtual_machine_id   = module.application_vms[each.key].id
  publisher            = "Microsoft.Compute"
  type                 = "CustomScriptExtension"
  type_handler_version = "1.10"
  settings = jsonencode({
    commandToExecute = "powershell -ExecutionPolicy Bypass -Command \"Install-WindowsFeature Web-Server -IncludeManagementTools; Install-WindowsFeature Web-Asp-Net45\""
  })
  tags       = local.merged_tags
  depends_on = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, type_handler_version, settings, protected_settings, virtual_machine_id]
  }
}

# MDE.Windows — all 4 VMs
resource "azurerm_virtual_machine_extension" "mde_windows" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf if contains(vm_conf.extensions_to_install, "MDE") }
  name                       = "MDE.Windows"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.Azure.AzureDefenderForServers"
  type                       = "MDE.Windows"
  type_handler_version       = "1.0"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = true
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, type_handler_version, settings, protected_settings, virtual_machine_id]
  }
}

# AzurePolicyforWindows — all 4 VMs (deployed automatically by Azure Policy)
resource "azurerm_virtual_machine_extension" "azure_policy" {
  for_each                   = { for vm_conf in var.vm_configurations : vm_conf.custom_suffix => vm_conf }
  name                       = "AzurePolicyforWindows"
  virtual_machine_id         = module.application_vms[each.key].id
  publisher                  = "Microsoft.GuestConfiguration"
  type                       = "ConfigurationforWindows"
  type_handler_version       = "1.29"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = true
  settings                   = jsonencode({})
  tags                       = local.merged_tags
  depends_on                 = [module.application_vms]
  lifecycle {
    ignore_changes = [tags, type_handler_version, settings, protected_settings, virtual_machine_id]
  }
}
