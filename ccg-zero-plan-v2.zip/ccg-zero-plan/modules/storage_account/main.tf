# =================================================================================================
# File: terraform/modules/storage_account/main.tf
# Fixes applied (Step 11):
#   - azure_files_default_share_level_permission variable added (defaults to
#     "StorageFileDataSmbShareElevatedContributor" to match Azure state).
#     Previously hardcoded "StorageFileDataSmbShareContributor" → caused UPDATE.
#   - Tags drift resolved upstream: DeploymentTimestamp removed from merged_tags in main.tf.
#   - identity_ids drift: BMW module creates new UAI — enable_cmk=false so UAI is unused.
#     Accept the 1 CREATE for azurerm_user_assigned_identity.storage[0] (Step 14 = LOW/accept).
# =================================================================================================

locals {
  naming_template = var.naming_file_json_tpl
}

# Note: You need FPC Owner Role to deploy Storage Account
module "bmw_storage_account" {
  source                          = "git::https://atc-github.azure.cloud.bmw/cgbp/terraform-azure-bmw-storage.git?ref=5.0.5"
  global_config                   = var.global_config
  cloud_region                    = var.cloud_region
  resource_group_name             = var.resource_group_name
  account_tier                    = var.account_tier
  account_replication_type        = var.account_replication_type
  account_kind                    = var.account_kind
  public_network_access_enabled   = var.public_network_access_enabled
  shared_access_key_enabled       = var.shared_access_key_enabled
  default_to_oauth_authentication = var.default_to_oauth_authentication
  enable_cmek_key                 = var.enable_cmk
  customer_managed_key_name       = var.enable_cmk ? var.cmk_key_name : null
  customer_managed_key_vault_id   = var.enable_cmk ? var.cmk_key_vault_id : null
  user_assigned_identity_id       = var.enable_cmk ? var.cmk_user_assigned_identity_id : null
  create_user_assigned_identity   = true
  enable_logging                  = var.create_diagnostic_settings
  log_analytics_workspace_id      = var.create_diagnostic_settings ? var.log_analytics_workspace_id : null
  queue_properties                = var.queue_properties
  blob_properties                 = var.blob_properties
  share_properties                = var.share_properties
  custom_name                     = var.custom_name_suffix
  custom_tags                     = var.tags
  naming_file_json_tpl            = var.naming_file_json_tpl
  allowed_ips                     = var.allowed_ips
  allowed_subnet_ids              = var.allowed_subnet_ids
  create_private_endpoint         = var.create_private_endpoint
  # default_share_level_permission: pass matching value from Azure state to prevent UPDATE.
  # State = "StorageFileDataSmbShareElevatedContributor"; BMW module default = "Contributor".
  azure_files_authentication = {
    directory_type                 = "AADKERB"
    default_share_level_permission = var.azure_files_default_share_level_permission
  }
}
