# =================================================================================================
# File: terraform/modules/storage_account/variables.tf
# Added: azure_files_default_share_level_permission (Step 11 fix)
# =================================================================================================

variable "resource_group_name" {
  type        = string
  description = "Name of the resource group."
}

variable "cloud_region" {
  type        = string
  description = "Azure region."
}

variable "global_config" {
  type        = any
  description = "Global config object passed to BMW module."
}

variable "custom_name_suffix" {
  type        = string
  description = "Custom suffix for the storage account name."
}

variable "region_code" {
  type        = string
  description = "Region code used in naming."
}

variable "tags" {
  type        = map(string)
  default     = {}
  description = "Tags to apply."
}

variable "account_tier" {
  type        = string
  default     = "Standard"
  description = "Storage account tier."
}

variable "account_replication_type" {
  type        = string
  default     = "ZRS"
  description = "Storage account replication type."
}

variable "account_kind" {
  type        = string
  default     = "StorageV2"
  description = "Storage account kind."
}

variable "allow_blob_public_access" {
  type        = bool
  default     = false
  description = "Whether to allow public access to blobs."
}

variable "public_network_access_enabled" {
  type        = bool
  default     = false
  description = "Whether public network access is enabled."
}

variable "shared_access_key_enabled" {
  type        = bool
  default     = true
  description = "Whether shared access key is enabled."
}

variable "default_to_oauth_authentication" {
  type        = bool
  default     = false
  description = "Whether OAuth is the default authentication method."
}

variable "min_tls_version" {
  type        = string
  default     = "TLS1_2"
  description = "Minimum TLS version."
}

variable "enable_cmk" {
  type        = bool
  default     = false
  description = "Whether to enable customer-managed keys."
}

variable "cmk_key_name" {
  type        = string
  default     = null
  description = "CMK key name (required if enable_cmk = true)."
}

variable "cmk_key_vault_id" {
  type        = string
  default     = null
  description = "CMK key vault ID (required if enable_cmk = true)."
}

variable "cmk_user_assigned_identity_id" {
  type        = string
  default     = null
  description = "UAI ID for CMK (required if enable_cmk = true)."
}

variable "create_diagnostic_settings" {
  type        = bool
  default     = false
  description = "Whether to create diagnostic settings for the storage account."
}

variable "log_analytics_workspace_id" {
  type        = string
  default     = null
  description = "Log Analytics workspace ID for diagnostics."
}

variable "network_rules_config" {
  type        = any
  default     = null
  description = "Network rules configuration block."
}

variable "queue_properties" {
  type        = any
  default     = null
  description = "Queue properties."
}

variable "blob_properties" {
  type        = any
  default     = null
  description = "Blob properties."
}

variable "share_properties" {
  type        = any
  default     = null
  description = "Share properties."
}

variable "allowed_ips" {
  type        = list(string)
  default     = []
  description = "Allowed IP addresses."
}

variable "allowed_subnet_ids" {
  type        = list(string)
  default     = []
  description = "Allowed subnet IDs."
}

variable "create_private_endpoint" {
  type        = bool
  default     = false
  description = "Whether to create a private endpoint inside the BMW storage module."
}

variable "naming_file_json_tpl" {
  type        = string
  default     = null
  description = "Path to naming JSON template file."
}

variable "azure_files_default_share_level_permission" {
  type        = string
  default     = "StorageFileDataSmbShareElevatedContributor"
  description = <<-EOT
    Default share-level permission for Azure Files authentication.
    Defaults to "StorageFileDataSmbShareElevatedContributor" to match what is
    already deployed in Azure (CCG state). BMW module previously hardcoded
    "StorageFileDataSmbShareContributor" which caused an in-place UPDATE on every plan.
  EOT
}
