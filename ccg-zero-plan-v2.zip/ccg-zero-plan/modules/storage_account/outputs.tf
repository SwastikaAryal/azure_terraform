# =================================================================================================
# File: terraform/modules/storage_account/outputs.tf
# =================================================================================================

output "id" {
  description = "The ID of the storage account."
  value       = module.bmw_storage_account.id
}

output "name" {
  description = "The name of the storage account."
  value       = module.bmw_storage_account.name
}


output "cmk_user_assigned_identity_principal_id" {
  description = "The principal ID of the user-assigned identity used for CMK, if applicable."
  value       = try(module.bmw_storage_account.user_assigned_identity_principal_id, null)
}
