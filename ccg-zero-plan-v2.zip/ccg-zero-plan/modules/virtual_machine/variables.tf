# =================================================================================================
# File: terraform/modules/virtual_machine/variables.tf
# =================================================================================================

variable "global_config" {
  type        = any
  description = "Global configuration object containing customer_prefix, env, etc."
}

variable "region_code" {
  type        = string
  description = "Short region code used for naming (e.g., 'eus1')."
}

variable "cloud_region" {
  type        = string
  description = "Azure region where the virtual machine will be deployed."
}

variable "resource_group_name" {
  type        = string
  description = "Name of the resource group for the virtual machine."
}

variable "custom_name_suffix" {
  type        = any
  description = "Custom suffix to append to the virtual machine name."
}

variable "tags" {
  type        = map(string)
  default     = {}
  description = "Tags to apply to the virtual machine and related resources."
}

variable "subnet_id" {
  type        = string
  description = "ID of the subnet where the virtual machine will be deployed."
}

variable "vnet_resource_group_name" {
  type        = string
  description = "Name of the resource group containing the virtual network."
}

variable "vm_size" {
  type        = string
  description = "Size of the virtual machine (e.g., 'Standard_DS2_v2')."
}

variable "admin_username" {
  type        = string
  description = "Administrator username for the virtual machine."
}

variable "admin_password_key_vault_secret_id" {
  type        = string
  default     = null
  sensitive   = true
  description = "Key Vault secret ID containing the admin password."
}

variable "os_type" {
  type        = string
  description = "Operating system type for the VM. Must be 'Windows' or 'Linux'."
  validation {
    condition     = contains(["Windows", "Linux"], var.os_type)
    error_message = "Must be Windows or Linux."
  }
}

variable "source_image_id" {
  type        = string
  description = "ID of the custom image to use for the virtual machine."
}

variable "enable_system_assigned_identity" {
  type        = bool
  default     = false
  description = "Whether to enable a system-assigned managed identity."
}

variable "user_assigned_identity_ids" {
  type        = list(string)
  default     = []
  description = "List of user-assigned identity IDs to associate with the VM."
}

variable "recovery_services_vault_name" {
  type        = string
  default     = null
  description = "Name of the Recovery Services Vault for VM backup."
}

variable "backup_policy_name" {
  type        = string
  default     = null
  description = "Name of the backup policy to apply to the VM."
}

variable "log_analytics_workspace_id" {
  type        = string
  default     = null
  description = "Log Analytics Workspace ID for diagnostics."
}

variable "log_analytics_primary_shared_key" {
  type        = string
  default     = null
  sensitive   = true
  description = "Primary shared key for the Log Analytics Workspace."
}

variable "boot_diagnostics_enabled" {
  type        = bool
  default     = true
  description = "Whether to enable boot diagnostics for the virtual machine."
}

variable "boot_diagnostics_storage_account_uri" {
  type        = string
  default     = null
  description = "URI of the storage account to store boot diagnostics logs."
}

variable "admin_password_direct_for_bmw_module" {
  description = "Direct admin password to pass to the BMW module. Used as a workaround if admin_password_secret_id is set, to make BMW module's internal admin_password non-null."
  type        = string
  default     = null
  sensitive   = true
}

variable "use_kv_for_vm_password" {
  description = "Boolean flag indicating if the VM password is to be sourced from Key Vault (via admin_password_key_vault_secret_id)."
  type        = bool
  default     = false
}

variable "virtual_network_name" {
  type        = string
  description = "Name of the virtual network"
}
variable "app_subnet_name" {
  type        = string
  description = "Name of the application subnet"
}

variable "naming_file_json_tpl" {
  type        = any
  description = "The common naming template file"
  default     = null
}

# variable "vm_configurations" {
#   description = "Configuration for the virtual machines."
#   type = list(object({
#     custom_suffix         = string
#     size                  = string
#     extensions_to_install = optional(list(string), [])
#   }))
# }


# variable "network_interface_ids" {
#   type        = list(string)
#   description = " (Required). A list of Network Interface IDs which should be attached to this Virtual Machine. The first Network Interface ID in this list will be the Primary Network Interface on the Virtual Machine."
# }

variable "windows_patch_mode" {
  type        = string
  description = "Specifies the mode of in-guest patching to this Windows Virtual Machine. Possible values are `Manual`, `AutomaticByOS` and `AutomaticByPlatform`"
  default     = "AutomaticByPlatform"
}

variable "key_vault_certificate_secret_url" {
  type    = any
  default = null
}

variable "availability_zone" {
  type        = string
  description = "The Zone in which this Virtual Machine should be created. Conflicts with availability set and shouldn't use both"
  default     = null
}

variable "enable_automatic_updates" {
  type        = bool
  description = "Specifies if Automatic Updates are Enabled for the Windows Virtual Machine."
  default     = true
}

variable "enable_encryption_at_host" {
  type        = bool
  description = "Should all of the disks (including the temp disk) attached to this Virtual Machine be encrypted by enabling Encryption at Host?"
  default     = true
}

variable "encryption_at_host_enabled" {
  type        = bool
  description = "Should all of the disks (including the temp disk) attached to this Virtual Machine be encrypted by enabling Encryption at Host?"
  default     = true
}

variable "enable_disk_encryption_set" {
  type        = bool
  description = "Specifying, whether disk encryption should be configured or not."
  default     = true
}

variable "os_disk_storage_account_type" {
  type        = string
  description = "The Type of Storage Account which should back this the Internal OS Disk. Possible values include `Standard_LRS`, `StandardSSD_LRS` and `Premium_LRS`."
  default     = "StandardSSD_ZRS"
}

variable "secure_boot_enabled" {
  description = "Specifies whether secure boot is enabled on the virtual machine."
  type        = bool
  # default     = true
}

variable "vtpm_enabled" {
  description = "Specifies whether virtual TPM is enabled on the virtual machine."
  type        = bool
  # default     = true
}

# variable "capacity_reservation_group_id" {
#   description = "The ID of the Capacity Reservation Group to associate with the VM."
#   type        = string
# }

variable "accelerated_networking_enabled" {
  description = "Whether to enable accelerated networking for the VM's primary NIC."
  type        = bool
  default     = false
}

variable "proximity_placement_group_id" {
  description = "The ID of the Proximity Placement Group to assign the VM to."
  type        = string
  default     = null
}

variable "enable_ultra_ssd_data_disk_storage_support" {
  description = "Enable Ultra SSD capability on the VM."
  type        = bool
  default     = false
}
