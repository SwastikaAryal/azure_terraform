# # =================================================================================================
# # File: terraform/modules/virtual_machine/outputs.tf
# # =================================================================================================

# output "id" {
#   description = "The ID of the deployed virtual machine."
#   value       = try(module.bmw_vm.virtual_machine_id, null)
# }

# output "name" {
#   description = "The name of the deployed virtual machine."
#   value       = try(module.bmw_vm.virtual_machine_name, null)
# }

# output "os_hostname" {
#   description = "The hostname of the virtual machine."
#   value       = local.os_hostname
# }

# output "identity_principal_id" {
#   description = "The principal ID of the virtual machine's managed identity."
#   value       = try(module.bmw_vm.virtual_machine_identity[0].principal_id, null)
# }

# output "vm_resource_id_for_attachment" {
#   description = "Resource ID of the virtual machine, used for attaching extensions or other resources."
#   value       = module.bmw_vm.virtual_machine_id
# }

# output "nic_id" {
#   description = "The ID of the NIC created for the VM"
#   value       = try(module.bmw_vm.network_interface_id, null)
# }

# output "nic_name" {
#   description = "The name of the NIC created for the VM"
#   value       = try(module.bmw_vm.network_interface_name, null)
# }


# # output "id" {
# #   description = "The ID of the deployed virtual machine."
# #   value       = try(module.bmw_vm[var.custom_name_suffix].virtual_machine_id, null)
# # }

# # output "name" {
# #   description = "The name of the deployed virtual machine."
# #   value       = try(module.bmw_vm[var.custom_name_suffix].virtual_machine_name, null)
# # }

# # output "os_hostname" {
# #   description = "The hostname of the virtual machine."
# #   // Ensure local.os_hostname is correctly derived,
# #   // potentially from module.bmw_vm[var.custom_name_suffix].virtual_machine_name
# #   value = local.os_hostname
# # }

# # output "identity_principal_id" {
# #   description = "The principal ID of the virtual machine's managed identity."
# #   value       = try(module.bmw_vm[var.custom_name_suffix].virtual_machine_identity[0].principal_id, null)
# # }

# # output "vm_resource_id_for_attachment" {
# #   description = "Resource ID of the virtual machine, used for attaching extensions or other resources."
# #   value       = module.bmw_vm[var.custom_name_suffix].virtual_machine_id
# # }

# # output "nic_id" {
# #   description = "The ID of the NIC created for the VM"
# #   value       = try(module.bmw_vm[var.custom_name_suffix].network_interface_id, null)
# # }

# # output "nic_name" {
# #   description = "The name of the NIC created for the VM"
# #   value       = try(module.bmw_vm[var.custom_name_suffix].network_interface_name, null)
# # }


# # output "identity_principal_id" {
# #   description = "The principal ID of the virtual machine's managed identity."
# #   value       = try(module.bmw_vm[var.custom_name_suffix].virtual_machine_identity[0].principal_id, null)
# # }

# # output "id" {
# #   description = "The ID of the deployed virtual machine."
# #   value       = module.bmw_vm[var.custom_name_suffix].virtual_machine_id
# # }

# # output "name" {
# #   description = "The name of the deployed virtual machine."
# #   value       = module.bmw_vm[var.custom_name_suffix].virtual_machine_name
# # }

# # output "vm_resource_id_for_attachment" {
# #   description = "Resource ID of the virtual machine for attachment."
# #   value       = module.bmw_vm[var.custom_name_suffix].virtual_machine_id
# # }



# =================================================================================================
# File: terraform/modules/virtual_machine/outputs.tf
# =================================================================================================

output "id" {
  description = "The ID of the deployed virtual machine."
  value       = try(module.bmw_vm.virtual_machine_id, null)
}

output "name" {
  description = "The name of the deployed virtual machine."
  value       = try(module.bmw_vm.virtual_machine_name, null)
}

output "os_hostname" {
  description = "The hostname of the virtual machine."
  value       = local.os_hostname
}

output "identity_principal_id" {
  description = "The principal ID of the virtual machine's managed identity."
  value       = try(module.bmw_vm.virtual_machine_identity[0].principal_id, null)
}

output "vm_resource_id_for_attachment" {
  description = "Resource ID of the virtual machine, used for attaching extensions or other resources."
  value       = module.bmw_vm.virtual_machine_id
}

output "nic_id" {
  description = "The ID of the NIC created for the VM"
  value       = module.bmw_vm.virtual_machine_primary_nic_id
}

output "nic_id_ip_config" {
  description = "The ID of the NIC created for the VM"
  value       = module.bmw_vm.primary_ip_configuration_name
}

output "nic_name" {
  description = "The name of the NIC created for the VM"
  value       = try(module.bmw_vm.network_interface_name, null)
}

output "nic_private_ip" {
  description = "The primary private IP of the NIC created for the VM."
  value       = module.bmw_vm.virtual_machine_private_ip_address
}

output "identity_client_id" {
  description = "The Client ID of the virtual machine's managed identity."
  value       = try(module.bmw_vm.virtual_machine_client_id, null)
}
