# =================================================================================================
# File: terraform/modules/virtual_machine/main.tf
# Fix Step 2: proximity_placement_group_id uncommented and passed through to BMW VM module.
#   VMs in CCG are assigned to fsamccg-ppg. Terraform omitting this caused REPLACE.
# =================================================================================================

locals {
  vm_name     = format("%s%s%s%svm", lower(var.global_config.customer_prefix), lower(var.global_config.env), var.region_code, lower(var.custom_name_suffix))
  os_hostname = format("%scn", lower(var.custom_name_suffix))
}

module "bmw_vm" {
  source = "git::https://atc-github.azure.cloud.bmw/fsam-sa/terraform-azure-bmw-vm?ref=securityfix"

  global_config        = var.global_config
  cloud_region         = var.cloud_region
  resource_group_name  = var.resource_group_name
  custom_name          = var.custom_name_suffix
  computer_name        = local.os_hostname
  virtual_machine_size = var.vm_size
  admin_username       = var.admin_username
  source_image_id      = var.source_image_id
  deploy_windows_vm    = var.os_type == "Windows"
  admin_password           = var.admin_password_key_vault_secret_id
  virtual_network_name     = var.virtual_network_name
  subnet_name              = var.app_subnet_name
  vnet_resource_group_name = var.vnet_resource_group_name
  managed_identity_type    = length(var.user_assigned_identity_ids) > 0 ? "SystemAssigned, UserAssigned" : (var.enable_system_assigned_identity ? "SystemAssigned" : null)
  enable_boot_diagnostics  = var.boot_diagnostics_enabled
  storage_account_uri      = var.boot_diagnostics_storage_account_uri
  custom_tags              = var.tags
  naming_file_json_tpl     = var.naming_file_json_tpl
  windows_patch_mode           = var.windows_patch_mode
  enable_automatic_updates     = var.enable_automatic_updates
  availability_zone            = var.availability_zone
  enable_encryption_at_host    = var.enable_encryption_at_host
  os_disk_storage_account_type = var.os_disk_storage_account_type
  secure_boot_enabled                        = var.secure_boot_enabled
  vtpm_enabled                               = var.vtpm_enabled
  accelerated_networking_enabled             = var.accelerated_networking_enabled
  enable_ultra_ssd_data_disk_storage_support = var.enable_ultra_ssd_data_disk_storage_support
  # Proximity Placement Group — must be passed; exists on all 4 CCG VMs in Azure state.
  # Omitting this caused Terraform to plan REPLACE on all VMs.
  proximity_placement_group_id = var.proximity_placement_group_id
}
