// =========================================================================
// File: terraform/modules/private_endpoint/main.tf
// Fix Step 7: Added psc_name_override variable support.
//   When set, uses the override value for private_service_connection.name
//   instead of the default "psc-{base_name}" pattern.
//   Required because storage PE in CCG state has no "psc-" prefix.
// =========================================================================

resource "azurerm_private_endpoint" "pe" {
  name                          = var.base_name
  resource_group_name           = var.resource_group_name
  location                      = var.cloud_region
  subnet_id                     = var.subnet_id
  tags                          = var.tags
  custom_network_interface_name = var.custom_nic_name != null ? var.custom_nic_name : null

  private_service_connection {
    name                           = var.psc_name_override != null ? var.psc_name_override : format("psc-%s", var.base_name)
    private_connection_resource_id = var.private_connection_resource_id
    is_manual_connection           = var.is_manual_connection
    subresource_names              = var.subresource_names
    request_message                = var.is_manual_connection ? var.request_message : null
  }

  lifecycle {
    ignore_changes = [tags]
  }
}
