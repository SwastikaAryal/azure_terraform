// =========================================================================
// File: terraform/modules/private_endpoint/outputs.tf
// =========================================================================

output "id" {
  description = "The ID of the private endpoint."
  value       = azurerm_private_endpoint.pe.id
}

output "name" {
  description = "The name of the private endpoint."
  value       = azurerm_private_endpoint.pe.name
}

output "network_interface_id" {
  description = "The ID of the network interface associated with the private endpoint."
  value       = try(azurerm_private_endpoint.pe.network_interface[0].id, null)
}

output "private_ip_address" {
  description = "The private IP address of the private endpoint's network interface. May require a data source on the NIC to reliably fetch after creation."
  value       = try(azurerm_private_endpoint.pe.private_service_connection[0].private_ip_address, null)
}

