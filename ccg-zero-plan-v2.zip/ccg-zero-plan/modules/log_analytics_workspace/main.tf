# =================================================================================================
# File: terraform/modules/log_analytics_workspace/main.tf
# Fix Step 6: Added `name` to ignore_changes on azurerm_application_insights.
#   Azure name = "fsam-ccg-2-aapin"; module now generates "fsamccg2-aapin" (naming convention
#   changed between module versions). Ignoring name prevents forced REPLACE of App Insights.
# =================================================================================================

locals {
  effective_ai_name = format("%s%s%s-%s", lower(var.global_config.customer_prefix), lower(var.global_config.env), lower(var.region_code), lower(var.app_insights_custom_suffix))
  naming_template   = var.naming_file_json_tpl
}

module "bmw_log_analytics_workspace" {
  source               = "git::https://atc-github.azure.cloud.bmw/cgbp/terraform-azure-bmw-log-analytics-workspace.git?ref=4.0.5"
  global_config        = var.global_config
  cloud_region         = var.cloud_region
  resource_group_name  = var.resource_group_name
  sku                  = var.sku
  retention_in_days    = var.retention_in_days
  custom_tags          = var.tags
  create_app_insights  = var.create_app_insights_via_bmw_module
  naming_file_json_tpl = var.naming_file_json_tpl
}

resource "azurerm_application_insights" "explicit_app_insights" {
  count               = !var.create_app_insights_via_bmw_module ? 1 : 0
  name                = local.effective_ai_name
  location            = var.app_insights_explicit_location != null ? var.app_insights_explicit_location : var.cloud_region
  resource_group_name = var.resource_group_name
  workspace_id        = module.bmw_log_analytics_workspace.log_analytics_id
  application_type    = var.app_insights_application_type
  retention_in_days   = var.app_insights_retention_in_days != null ? var.app_insights_retention_in_days : var.retention_in_days
  tags                = var.tags
  lifecycle {
    # name: prevents REPLACE when naming convention changed between module versions
    #   (e.g. "fsam-ccg-2-aapin" vs "fsamccg2-aapin"). Azure retains the original name.
    # tags: prevents UPDATE drift from BMW-injected tags vs local merged_tags
    ignore_changes = [tags, name]
  }
}
