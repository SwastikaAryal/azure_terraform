# =================================================================================================
# File: terraform/modules/log_analytics_workspace/outputs.tf
# =================================================================================================

output "log_analytics_id" {
  description = "The resource ID of the Log Analytics Workspace."
  value       = module.bmw_log_analytics_workspace.log_analytics_id
}

output "log_analytics_workspace_id" {
  description = "The workspace ID of the Log Analytics Workspace."
  value       = module.bmw_log_analytics_workspace.log_analytics_workspace_id
}

output "log_analytics_name" {
  description = "The name of the Log Analytics Workspace."
  value       = module.bmw_log_analytics_workspace.log_analytics_name
}

output "log_analytics_primary_shared_key" {
  description = "The primary shared key for the Log Analytics Workspace."
  value       = module.bmw_log_analytics_workspace.log_analytics_primary_shared_key
  sensitive   = true
}

output "app_insights_id" {
  description = "The resource ID of Application Insights, created either via BMW module or explicitly."
  value       = var.create_app_insights_via_bmw_module ? module.bmw_log_analytics_workspace.app_insights_id : (length(azurerm_application_insights.explicit_app_insights) > 0 ? azurerm_application_insights.explicit_app_insights[0].id : null)
}

output "app_insights_name" {
  description = "The name of Application Insights, created either via BMW module or explicitly."
  value       = var.create_app_insights_via_bmw_module ? module.bmw_log_analytics_workspace.app_insights_name : (length(azurerm_application_insights.explicit_app_insights) > 0 ? azurerm_application_insights.explicit_app_insights[0].name : null)
}

output "app_insights_instrumentation_key" {
  description = "Instrumentation key for Application Insights."
  value       = var.create_app_insights_via_bmw_module ? module.bmw_log_analytics_workspace.app_insights_instrumentation_key : (length(azurerm_application_insights.explicit_app_insights) > 0 ? azurerm_application_insights.explicit_app_insights[0].instrumentation_key : null)
  sensitive   = true
}

output "app_insights_connection_string" {
  description = "Connection string for Application Insights."
  value       = var.create_app_insights_via_bmw_module ? module.bmw_log_analytics_workspace.app_insights_connection_string : (length(azurerm_application_insights.explicit_app_insights) > 0 ? azurerm_application_insights.explicit_app_insights[0].connection_string : null)
  sensitive   = true
}
