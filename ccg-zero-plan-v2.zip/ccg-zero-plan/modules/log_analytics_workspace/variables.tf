# =================================================================================================
# File: terraform/modules/log_analytics_workspace/variables.tf
# =================================================================================================

variable "global_config" {
  type        = any
  description = "Global configuration object containing customer_prefix, env, etc."
}

variable "region_code" {
  type        = string
  description = "Short region code used for naming (e.g., 'eus1')."
}

variable "cloud_region" {
  type        = string
  description = "Azure region where the Log Analytics Workspace will be deployed."
}

variable "resource_group_name" {
  type        = string
  description = "Name of the resource group for the Log Analytics Workspace."
}

variable "custom_name_suffix" {
  type        = string
  description = "Custom suffix to append to the Log Analytics Workspace name."
}

variable "tags" {
  type        = map(string)
  default     = {}
  description = "Tags to apply to the Log Analytics Workspace and related resources."
}

variable "sku" {
  type        = string
  default     = "PerGB2018"
  description = "SKU for the Log Analytics Workspace (e.g., 'PerGB2018')."
}

variable "retention_in_days" {
  type        = number
  default     = 90
  description = "Number of days to retain logs in the workspace."
}

variable "create_app_insights_via_bmw_module" {
  type        = bool
  default     = false
  description = "Whether to create Application Insights via the BMW module."
}

variable "app_insights_custom_suffix" {
  type        = string
  default     = "appins"
  description = "Custom suffix for the Application Insights name."
}

variable "app_insights_application_type" {
  type        = string
  default     = "web"
  description = "Application type for Application Insights (e.g., 'web', 'other')."
}

variable "app_insights_explicit_location" {
  type        = string
  default     = null
  description = "Explicit location for Application Insights. Defaults to workspace location if null."
}

variable "app_insights_retention_in_days" {
  type        = number
  default     = null
  description = "Retention period for Application Insights. Defaults to workspace retention if null."
}

variable "naming_file_json_tpl" {
  type        = any
  description = "The common naming template file"
  default     = null
}
