# =================================================================================================
# File: terraform/env/ccg/main.tf
# Fix: Removed DeploymentTimestamp and TerraformWorkspace from merged_tags.
#      These change on every plan run and caused ALL tag-related drift across every resource.
# =================================================================================================

locals {
  number_bump               = "2"
  global_config_for_commons = merge(var.global_config_base, { env = var.environment })
  effective_rg_name         = var.resource_group_name_override != "" ? var.resource_group_name_override : format("%s-%s-%s-rg", lower(local.global_config_for_commons.customer_prefix), lower(local.global_config_for_commons.env), local.number_bump)
  resource_name_prefix      = format("%s%s%s", lower(local.global_config_for_commons.customer_prefix), lower(local.global_config_for_commons.env), local.number_bump)
  naming_template           = "${path.module}/naming.json.tpl"
  naming_json               = local.naming_template

  commons_allowed_ips = flatten([
    module.common.data.networks["fia-muc"].ip4_cidrs,
    module.common.data.networks["fia-emea"].ip4_cidrs,
    module.common.data.networks["bmw-public"].ip4_cidrs,
    module.common.data.networks["fia-azr-eastus"].ip4_cidrs,
    module.common.data.networks["fia-azr"].ip4_cidrs,
  ])

  # DeploymentTimestamp and TerraformWorkspace removed — both change every plan run
  # and were the root cause of all tag drift across NICs, NSGs, VMs, LAW, Storage, etc.
  merged_tags = merge(
    {
      customer_prefix = var.global_config_base.customer_prefix,
      env             = var.global_config_base.env
    },
    {
      "environment" = var.environment
    }
  )
  vm_password_is_from_kv = var.vm_admin_password_kv_secret_name != null
}

module "common" {
  source        = "git::https://atc-github.azure.cloud.bmw/cgbp/terraform-bmw-cloud-commons.git?ref=2.3.0"
  global_config = local.global_config_for_commons
  cloud_region  = var.cloud_region
  custom_tags   = var.custom_tags_override
  custom_name   = local.global_config_for_commons.app_name
}

resource "azurerm_resource_group" "application_rg" {
  name     = local.effective_rg_name
  location = var.cloud_region
  tags     = local.merged_tags
  lifecycle {
    ignore_changes = [tags]
  }
}

module "central_managed_identity" {
  source              = "../../modules/managed_identity"
  resource_group_name = azurerm_resource_group.application_rg.name
  cloud_region        = var.cloud_region
  custom_name_suffix  = var.central_managed_identity_custom_suffix
  global_config       = local.global_config_for_commons
  region_code         = local.number_bump
  tags                = local.merged_tags
  depends_on          = [azurerm_resource_group.application_rg]
}
