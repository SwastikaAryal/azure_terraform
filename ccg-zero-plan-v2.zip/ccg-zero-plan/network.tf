# =================================================================================================
# File: terraform/env/ccg/network.tf
# Fixes applied:
#   Step 7  — psc_name_override = "fsamccgstprivatebmw-pe-file" to stop storage PE REPLACE
#             (module generates "psc-{name}" but state has no psc- prefix)
#   LB      — backend_nics populated for web1/web2 (NIC→LB associations)
# =================================================================================================

module "application_load_balancer" {
  source              = "../../modules/load_balancer"
  resource_group_name = azurerm_resource_group.application_rg.name
  cloud_region        = var.cloud_region
  custom_name_suffix  = var.load_balancer_custom_suffix
  global_config       = local.global_config_for_commons
  region_code         = local.number_bump
  tags                = local.merged_tags
  sku                 = "Standard"

  frontend_ip_configurations = [
    {
      name                          = format("feip-%s-%s", local.resource_name_prefix, var.load_balancer_custom_suffix)
      subnet_id                     = data.azurerm_subnet.app_subnet.id
      private_ip_address_allocation = "Dynamic"
    }
  ]
  backend_address_pools = [{ name = format("bepool-%s-vm", local.resource_name_prefix) }]
  probes = [
    { name = format("probe-http-%s", local.resource_name_prefix), protocol = "Http", port = 80, request_path = "/" },
    { name = format("probe-https-%s", local.resource_name_prefix), protocol = "Https", port = 443, request_path = "/" }
  ]
  load_balancing_rules = [
    {
      name                           = format("lbrul-http-%s", local.resource_name_prefix)
      protocol                       = "Tcp", frontend_port = 80, backend_port = 80
      frontend_ip_configuration_name = format("feip-%s-%s", local.resource_name_prefix, var.load_balancer_custom_suffix)
      backend_address_pool_names     = [format("bepool-%s-vm", local.resource_name_prefix)]
      probe_name                     = format("probe-http-%s", local.resource_name_prefix)
    },
    {
      name                           = format("lbrul-https-%s", local.resource_name_prefix)
      protocol                       = "Tcp", frontend_port = 443, backend_port = 443
      frontend_ip_configuration_name = format("feip-%s-%s", local.resource_name_prefix, var.load_balancer_custom_suffix)
      backend_address_pool_names     = [format("bepool-%s-vm", local.resource_name_prefix)]
      probe_name                     = format("probe-https-%s", local.resource_name_prefix)
    }
  ]
  # web1 and web2 NICs are associated to the LB backend pool
  # ip_configuration_name values confirmed from ARM export / state
  backend_nics = {
    "fs-ccg-web1" = {
      nic_id                = module.application_vms["fs-ccg-web1"].nic_id
      ip_configuration_name = "internal-ipconfig-fsamfs-ccg-web1winvm"
    }
    "fs-ccg-web2" = {
      nic_id                = module.application_vms["fs-ccg-web2"].nic_id
      ip_configuration_name = "internal-ipconfig-fsamfs-ccg-web2winvm"
    }
  }
  depends_on = [azurerm_resource_group.application_rg, data.azurerm_subnet.app_subnet, module.application_vms]
}

# =============================================================================
# Storage Private Endpoints
# ONLY "file" subresource exists in Azure portal.
# psc_name_override: state has "fsamccgstprivatebmw-pe-file" (no psc- prefix).
# Module normally generates "psc-{base_name}" → forces replacement without override.
# =============================================================================
module "application_storage_private_endpoints" {
  source = "../../modules/private_endpoint"
  for_each = var.enable_storage_private_endpoints ? {
    file = { subresource = "file", nic_suffix = "file" }
  } : {}

  resource_group_name            = azurerm_resource_group.application_rg.name
  cloud_region                   = var.cloud_region
  base_name                      = format("%s-pe-%s", module.application_storage_account.name, each.value.subresource)
  custom_nic_name                = format("%s-pe-%s-nic", module.application_storage_account.name, each.value.nic_suffix)
  private_connection_resource_id = module.application_storage_account.id
  is_manual_connection           = false
  subresource_names              = [each.value.subresource]
  subnet_id                      = data.azurerm_subnet.app_subnet.id
  private_dns_zone_ids           = []
  # Match PSC name already in Azure state — no "psc-" prefix was used originally
  psc_name_override = format("%s-pe-%s", module.application_storage_account.name, each.value.subresource)
  tags              = local.merged_tags
  depends_on        = [module.application_storage_account, data.azurerm_subnet.app_subnet]
}

# =============================================================================
# Key Vault Private Endpoint — NOT deployed in CCG portal (flag = false)
# =============================================================================
module "key_vault_private_endpoint" {
  count                          = var.enable_keyvault_private_endpoint ? 1 : 0
  source                         = "../../modules/private_endpoint"
  resource_group_name            = azurerm_resource_group.application_rg.name
  cloud_region                   = var.cloud_region
  base_name                      = format("%s-pe", module.application_key_vault.name)
  custom_nic_name                = format("nic-%s-pe-%s", local.resource_name_prefix, var.key_vault_custom_suffix)
  private_connection_resource_id = module.application_key_vault.id
  is_manual_connection           = false
  subresource_names              = ["vault"]
  subnet_id                      = data.azurerm_subnet.app_subnet.id
  private_dns_zone_ids           = []
  tags                           = local.merged_tags
  depends_on                     = [module.application_key_vault, data.azurerm_subnet.app_subnet]
}

# =============================================================================
# Automation Account Private Endpoint — "Webhook" subresource exists in portal
# =============================================================================
locals {
  automation_subresources = var.enable_automation_private_endpoint ? ["Webhook"] : []
}

module "automation_agentsvc_private_endpoint" {
  for_each                       = toset(local.automation_subresources)
  source                         = "../../modules/private_endpoint"
  resource_group_name            = azurerm_resource_group.application_rg.name
  cloud_region                   = var.cloud_region
  base_name                      = format("%s-pe-agentsvc-%s", module.application_automation_account.name, each.key)
  custom_nic_name                = format("nic-%s-pe-%s-agentsvc-%s", local.resource_name_prefix, var.automation_account_custom_suffix, each.key)
  private_connection_resource_id = module.application_automation_account.id
  is_manual_connection           = false
  subresource_names              = [each.key]
  subnet_id                      = data.azurerm_subnet.app_subnet.id
  private_dns_zone_ids           = []
  tags                           = local.merged_tags
  depends_on                     = [module.application_automation_account, data.azurerm_subnet.app_subnet]
}
