# =================================================================================================
# File: terraform/env/ccg/keyvault.tf
# Fix Step 4: create_diagnostic_settings = false
#   KV diagnostic setting does NOT exist in CCG Azure portal.
#   Leaving it true causes Terraform to plan CREATE azurerm_monitor_diagnostic_setting.this[0].
# =================================================================================================

module "application_key_vault" {
  source                      = "../../modules/keyvault"
  resource_group_name         = azurerm_resource_group.application_rg.name
  cloud_region                = var.cloud_region
  custom_name_suffix          = var.key_vault_custom_suffix
  sku_name                    = var.key_vault_sku_name
  enable_rbac_authorization   = false
  purge_protection_enabled    = var.key_vault_config_flags.purge_protection_enabled
  soft_delete_retention_days  = var.key_vault_config_flags.soft_delete_retention_days
  enabled_for_disk_encryption = var.key_vault_config_flags.enabled_for_disk_encryption
  global_config               = local.global_config_for_commons
  region_code                 = local.number_bump
  tags                        = local.merged_tags
  # Diagnostic setting does not exist in CCG portal — set false to prevent CREATE
  create_diagnostic_settings = false
  log_analytics_workspace_id = module.application_log_analytics.log_analytics_id
  naming_file_json_tpl       = local.naming_json

  allowed_subnet_ids = [data.azurerm_subnet.app_subnet.id]
  allowed_ips        = local.commons_allowed_ips

  network_acls_config = var.enable_keyvault_private_endpoint ? null : {
    default_action = contains(var.allowed_ips, "0.0.0.0/0") ? "Allow" : "Deny"
    bypass         = "AzureServices"
    ip_rules       = local.commons_allowed_ips
    virtual_network_subnet_ids = [
      data.azurerm_subnet.app_subnet.id
    ]
  }

  depends_on = [
    azurerm_resource_group.application_rg,
    module.central_managed_identity,
    module.application_log_analytics,
    data.azurerm_subnet.app_subnet
  ]
}
