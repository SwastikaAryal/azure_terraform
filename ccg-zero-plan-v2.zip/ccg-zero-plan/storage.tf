# =================================================================================================
# File: terraform/env/ccg/storage.tf
# Fix Step 5: create_diagnostic_settings = false
#   Storage diagnostic settings (blob/file/general/queue/table) do NOT exist in CCG portal.
#   Leaving true causes 5 CREATE operations for azurerm_monitor_diagnostic_setting.
# =================================================================================================

module "application_storage_account" {
  source              = "../../modules/storage_account"
  resource_group_name = azurerm_resource_group.application_rg.name
  cloud_region        = var.cloud_region
  custom_name_suffix  = var.storage_account_main_custom_suffix
  global_config       = local.global_config_for_commons
  region_code         = local.number_bump
  tags                = local.merged_tags
  account_tier        = var.storage_account_main_config.tier
  account_replication_type        = var.storage_account_main_config.replication_type
  account_kind                    = "StorageV2"
  allow_blob_public_access        = var.storage_account_main_config.allow_blob_public_access
  public_network_access_enabled   = var.enable_storage_private_endpoints ? true : var.storage_account_main_config.public_network_access_enabled
  shared_access_key_enabled       = var.storage_account_main_config.shared_access_key_enabled
  default_to_oauth_authentication = var.storage_account_main_config.default_to_oauth_authentication
  min_tls_version                 = var.storage_account_main_config.min_tls_version
  enable_cmk                      = false
  cmk_key_vault_id                = module.application_key_vault.id
  naming_file_json_tpl            = local.naming_json

  network_rules_config = var.enable_storage_private_endpoints ? null : {
    default_action             = contains(var.allowed_ips, "0.0.0.0/0") ? "Allow" : "Deny"
    bypass                     = ["AzureServices"]
    ip_rules                   = local.commons_allowed_ips
    virtual_network_subnet_ids = [data.azurerm_subnet.app_subnet.id]
  }

  # Storage diagnostic settings (blob/file/general/queue/table) do NOT exist in CCG portal.
  # Setting true would cause 5 CREATE operations — set false to prevent.
  create_diagnostic_settings = false
  log_analytics_workspace_id = module.application_log_analytics.log_analytics_id

  depends_on = [
    data.azurerm_subnet.app_subnet
  ]
}
