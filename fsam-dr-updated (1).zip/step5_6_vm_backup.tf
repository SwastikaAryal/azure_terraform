###############################################################################
# step5_6_vm_backup.tf
# GAP FIXES applied:
#   ✅ Scenario 2 (backup protection removed): already owned – re-registered on apply
#   ✅ Scenario 5 (policy changed to weekly): already owned – enforced daily on apply
#   ✅ Scenario 7 (Monitor Agent removed): already owned – re-deployed on apply
#   ✅ Scenario 6 (VM stopped): alert fires; output with az vm start command
#   ⚠️ Scenario 1 (VM deleted): alert fires + output with full RSV restore commands
#   ⚠️ Scenario 3 (OS disk corrupted): alert fires + output with restore commands
#   ⚠️ Scenario 4 (data disk corrupted): alert fires + output with restore commands
###############################################################################

# Daily VM backup policy – covers OS disk C:\ and data disk E:\ in one job
resource "azurerm_backup_policy_vm" "vm_daily_policy" {
  name                = "fsam-uat-vm-daily-policy"
  resource_group_name = local.rg
  recovery_vault_name = data.azurerm_recovery_services_vault.rsv.name

  timezone = "UTC"

  backup {
    frequency = "Daily"
    time      = "02:00"
  }

  retention_daily   { count = 30 }
  retention_weekly  { count = 12; weekdays = ["Sunday"] }
  retention_monthly { count = 12; weekdays = ["Sunday"]; weeks = ["First"] }

  instant_restore_retention_days = 2
}

# Register VM for backup in RSV
# Gap Scenario 2: if removed → terraform apply re-registers automatically
resource "azurerm_backup_protected_vm" "vm_backup" {
  resource_group_name = local.rg
  recovery_vault_name = data.azurerm_recovery_services_vault.rsv.name
  source_vm_id        = data.azurerm_virtual_machine.vm.id
  backup_policy_id    = azurerm_backup_policy_vm.vm_daily_policy.id
}

# Alert: VM heartbeat missing (VM deleted, down, or stopped)
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "vm_heartbeat" {
  name                 = "vm-heartbeat-missing"
  location             = local.loc
  resource_group_name  = local.rg
  severity             = 1
  description          = "VM heartbeat missing for 5 min – deleted, crashed, or deallocated"
  evaluation_frequency = "PT5M"
  window_duration      = "PT5M"
  scopes               = [data.azurerm_log_analytics_workspace.law.id]

  criteria {
    query = <<-QUERY
      Heartbeat
      | where Computer == "${var.vm_name}"
      | summarize LastHeartbeat = max(TimeGenerated)
      | where LastHeartbeat < ago(5m)
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action { action_groups = [azurerm_monitor_action_group.infra_ag.id] }
}

# Alert: VM CPU > 90%
resource "azurerm_monitor_metric_alert" "vm_cpu" {
  name                = "vm-cpu-high"
  resource_group_name = local.rg
  scopes              = [data.azurerm_virtual_machine.vm.id]
  description         = "VM CPU > 90% for 5 min"
  severity            = 2
  frequency           = "PT1M"
  window_size         = "PT5M"

  criteria {
    metric_namespace = "Microsoft.Compute/virtualMachines"
    metric_name      = "Percentage CPU"
    aggregation      = "Average"
    operator         = "GreaterThan"
    threshold        = 90
  }

  action { action_group_id = azurerm_monitor_action_group.infra_ag.id }
}

output "step5_6_verify" {
  description = "Steps 5+6 verification + manual restore commands for all VM disk scenarios"
  value = <<-EOT
    === STEPS 5+6 – VM Disk Verification ===

    # Confirm VM backup registered and healthy
    az backup item show \
      --resource-group ${local.rg} --vault-name ${var.rsv_name} \
      --container-name "iaasvmcontainer;iaasvmcontainerv2;${local.rg};${var.vm_name}" \
      --name "vm;iaasvmcontainerv2;${local.rg};${var.vm_name}" \
      --backup-management-type AzureIaasVM -o json

    # Latest restore point (should be < 24 hrs)
    az backup recoverypoint list \
      --resource-group ${local.rg} --vault-name ${var.rsv_name} \
      --container-name "iaasvmcontainer;iaasvmcontainerv2;${local.rg};${var.vm_name}" \
      --item-name "vm;iaasvmcontainerv2;${local.rg};${var.vm_name}" -o table

    # SCENARIO 1/3/4 FIX: Restore VM or disk from RSV backup:
    az backup restore restore-disks \
      --resource-group ${local.rg} --vault-name ${var.rsv_name} \
      --container-name "iaasvmcontainer;iaasvmcontainerv2;${local.rg};${var.vm_name}" \
      --item-name "vm;iaasvmcontainerv2;${local.rg};${var.vm_name}" \
      --rp-name <restore-point-name> \
      --storage-account ${var.storage_account_name} \
      --restore-to-staging-storage-account
    # After restore: terraform apply re-registers the VM in RSV

    # SCENARIO 6 FIX: VM stopped/deallocated – start it:
    az vm start --name ${var.vm_name} --resource-group ${local.rg}

    # SCENARIO 4 FIX: After data disk restore – detach corrupted, attach restored:
    # az vm disk detach --vm-name ${var.vm_name} --resource-group ${local.rg} --name <corrupted-disk>
    # az vm disk attach --vm-name ${var.vm_name} --resource-group ${local.rg} --name <restored-disk> --lun 0
  EOT
}
