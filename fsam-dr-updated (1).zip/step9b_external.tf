###############################################################################
# step9b_external.tf
# GAP FIXES applied:
#   ✅ Scenarios 1,2,3 (outbound HTTPS blocked): NSG outbound rules now owned
#      in step4_network.tf (TF-Allow-Outbound-Cognito rule covers all 3)
#   ✅ Alert: outbound connectivity failure already owned – fires on DENY events
#   ⚠️ Scenario 4 (external service down): platform-managed, output only
###############################################################################

# Alert: outbound HTTPS denies in NSG flow logs
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "external_connectivity" {
  name                 = "external-connectivity-failure"
  location             = local.loc
  resource_group_name  = local.rg
  severity             = 2
  description          = "Outbound HTTPS to Vertex/Cognito/AWS API being blocked – check NSG rules"
  evaluation_frequency = "PT15M"
  window_duration      = "PT15M"
  scopes               = [data.azurerm_log_analytics_workspace.law.id]

  criteria {
    query = <<-QUERY
      AzureDiagnostics
      | where Category == "NetworkSecurityGroupFlowEvent"
      | where FlowStatus_s == "D"
      | where DestPort_d == 443
      | where Direction_s == "O"
    QUERY
    time_aggregation_method = "Count"
    threshold               = 10
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action { action_groups = [azurerm_monitor_action_group.infra_ag.id] }
}

output "step9b_verify" {
  description = "Step 9b verification + fix commands"
  value = <<-EOT
    === STEP 9b – External Connectivity Verification ===

    # Run inside VM (PowerShell) – test all 3 external endpoints:
    $endpoints = @(
      "https://cognito-idp.us-east-1.amazonaws.com",
      "https://aiplatform.googleapis.com",
      "https://execute-api.us-east-1.amazonaws.com"
    )
    foreach ($ep in $endpoints) {
      try {
        $r = Invoke-WebRequest -Uri $ep -UseBasicParsing -TimeoutSec 10
        Write-Host "OK  [$($r.StatusCode)] $ep"
      } catch {
        Write-Host "FAIL $ep - $($_.Exception.Message)"
      }
    }

    # SCENARIOS 1,2,3 FIX: If outbound blocked – TF-managed rule should restore on apply:
    terraform apply -target=azurerm_network_security_rule.allow_outbound_cognito

    # Confirm TF-managed outbound rule is present:
    az network nsg rule list --nsg-name ${var.nsg_name} --resource-group ${local.rg} \
      --query "[?name=='TF-Allow-Outbound-Cognito'].{Name:name,Access:access,Port:destinationPortRange}" -o table

    # SCENARIO 4: External service itself down – check vendor status:
    # https://status.aws.amazon.com  (Cognito / API Gateway)
    # https://status.cloud.google.com  (Vertex AI)
  EOT
}
