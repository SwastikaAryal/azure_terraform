###############################################################################
# variables.tf
###############################################################################

variable "subscription_id"      { type = string }
variable "tenant_id"             { type = string }
variable "location"              { type = string; default = "East US" }
variable "resource_group_name"   { type = string; default = "FSAM-UAT-RG" }

# Existing resource names – must match exactly what is in the Azure portal
variable "rsv_name"              { type = string; default = "fsamuat-rsv" }
variable "keyvault_name"         { type = string; default = "fsamuat-kvprivatebmw" }
variable "storage_account_name"  { type = string; default = "fsamuatbackupsa" }
variable "vnet_name"             { type = string; default = "fsamuat-vnet" }
variable "nsg_name"              { type = string; default = "fsamuat-app-nsg" }
variable "vm_name"               { type = string; default = "fsam-uat-vm" }
variable "lb_name"               { type = string; default = "fsamuat-lb" }
variable "ssl_cert_name"         { type = string; default = "fsamuat-ssl-cert" }
variable "law_name"              { type = string; default = "fsamuat-law" }

# Identities
variable "dr_operator_object_id"             { type = string }
variable "app_managed_identity_principal_id" { type = string }
variable "admin_object_ids"                  { type = list(string); default = [] }

# Alerts
variable "alert_email" { type = string; default = "azure-infra@bmwgroup.net" }

# ── New: gap fixes from DR scenario analysis ──────────────────────────────────
variable "sql_sa_password_placeholder" {
  type      = string
  default   = "PLACEHOLDER-SET-BY-DBA-AFTER-RESTORE"
  sensitive = true
}
variable "db_connection_string_placeholder" {
  type      = string
  default   = "PLACEHOLDER-SET-BY-DBA-AFTER-RESTORE"
  sensitive = true
}
variable "kv_pe_subnet_name"          { type = string; default = "app-subnet" }
variable "backup_container_name"      { type = string; default = "vm-backup-staging" }
variable "nsg_outbound_priority_start"{ type = number; default = 200 }
variable "iis_site_name"              { type = string; default = "Default Web Site" }
