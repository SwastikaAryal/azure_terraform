###############################################################################
# step8_ssl.tf
# GAP FIXES applied:
#   ✅ Scenario 1+4 (cert expiry/renewal fails): alert already owned – fires at 30 days
#   ✅ Scenario 3+5 (IIS binding removed/thumbprint mismatch): NEW – VM extension re-binds cert
#   ⚠️ Scenario 2 (cert deleted from KV): output with soft-delete recovery command
###############################################################################

# Alert: SSL cert expiring within 30 days
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "ssl_expiry" {
  name                 = "ssl-cert-expiry-30days"
  location             = local.loc
  resource_group_name  = local.rg
  severity             = 2
  description          = "SSL cert expiring within 30 days – renew and re-bind IIS"
  evaluation_frequency = "P1D"
  window_duration      = "P1D"
  scopes               = [data.azurerm_log_analytics_workspace.law.id]

  criteria {
    query = <<-QUERY
      AzureDiagnostics
      | where ResourceType == "VAULTS"
      | where OperationName == "CertificateNearExpiry"
      | where Resource =~ "${var.keyvault_name}"
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action { action_groups = [azurerm_monitor_action_group.infra_ag.id] }
}

# Gap fix Scenarios 3 + 5: IIS SSL re-bind via VM Custom Script Extension
# Runs PowerShell on the VM to bind the cert from LocalMachine\My to IIS HTTPS site.
# If IIS binding is removed or thumbprint changes → terraform apply re-runs this.
# trigger = cert thumbprint ensures it re-runs when cert is renewed.
resource "azurerm_virtual_machine_extension" "iis_ssl_rebind" {
  name                 = "iis-ssl-rebind"
  virtual_machine_id   = data.azurerm_virtual_machine.vm.id
  publisher            = "Microsoft.Compute"
  type                 = "CustomScriptExtension"
  type_handler_version = "1.10"

  # Re-triggers when cert thumbprint changes (i.e. after renewal)
  protected_settings = jsonencode({
    commandToExecute = join(" ", [
      "powershell -ExecutionPolicy Unrestricted -Command",
      "\"Import-Module WebAdministration;",
      "$cert = Get-ChildItem Cert:\\\\LocalMachine\\\\My | Where-Object { $_.Subject -like '*fsam*' } | Sort-Object NotAfter -Descending | Select-Object -First 1;",
      "if ($cert) {",
      "  $site = '${var.iis_site_name}';",
      "  $binding = Get-WebBinding -Name $site -Protocol https -ErrorAction SilentlyContinue;",
      "  if (-not $binding) { New-WebBinding -Name $site -Protocol https -Port 443 -IPAddress '*' };",
      "  (Get-WebBinding -Name $site -Protocol https).AddSslCertificate($cert.Thumbprint, 'My');",
      "  Write-Host 'SSL binding applied: ' + $cert.Thumbprint",
      "} else { Write-Error 'No certificate matching fsam found in LocalMachine\\\\My' }\"",
    ])
  })

  tags = local.tags

  lifecycle {
    # Re-run when cert thumbprint changes
    replace_triggered_by = [data.azurerm_key_vault_certificate.ssl_cert]
  }

  depends_on = [data.azurerm_key_vault_certificate.ssl_cert]
}

output "step8_verify" {
  description = "Step 8 verification + manual fix commands"
  value = <<-EOT
    === STEP 8 – SSL Certificate Verification ===

    # Check cert versions in KV
    az keyvault certificate list-versions \
      --vault-name ${var.keyvault_name} --name ${var.ssl_cert_name} -o table

    # Check cert expiry
    az keyvault certificate show \
      --vault-name ${var.keyvault_name} --name ${var.ssl_cert_name} \
      --query "{thumbprint:x509Thumbprint,expires:attributes.expires,enabled:attributes.enabled}" -o json

    # SCENARIO 2 FIX: If cert deleted from KV – recover from soft-delete:
    az keyvault certificate recover \
      --vault-name ${var.keyvault_name} --name ${var.ssl_cert_name}
    # Then: terraform apply (re-runs IIS binding extension with recovered cert)

    # Verify IIS HTTPS binding active (run on VM, PowerShell):
    # Get-WebBinding -Name "${var.iis_site_name}" | Where-Object { $_.protocol -eq "https" }

    # Force re-bind manually if extension fails (run on VM, PowerShell):
    # $cert = Get-ChildItem Cert:\LocalMachine\My | Where-Object { $_.Subject -like '*fsam*' } | Sort-Object NotAfter -Descending | Select-Object -First 1
    # Import-Module WebAdministration
    # (Get-WebBinding -Name "${var.iis_site_name}" -Protocol https).AddSslCertificate($cert.Thumbprint, "My")
  EOT
}
