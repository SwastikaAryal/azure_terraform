###############################################################################
# step1_rsv.tf
# GAP FIXES applied:
#   ✅ Scenario 1 (RSV soft-deleted): null_resource pre-apply recovery command
#   ✅ Scenario 4 (RBAC removed): already owned – no change
#   ✅ Scenario 5 (backup job fails): alert already owned – no change
#   ⚠️ Scenario 3 (GRS drift) + Scenario 6 (soft-delete drift): added output
#      with exact fix commands — cannot enforce via data block
###############################################################################

# DR operator Backup Operator role on existing RSV
# Gap fix Scenario 4: if removed → terraform apply re-creates automatically
resource "azurerm_role_assignment" "dr_operator_backup_operator" {
  scope                = data.azurerm_recovery_services_vault.rsv.id
  role_definition_name = "Backup Operator"
  principal_id         = var.dr_operator_object_id
}

# Alert: backup job failure
resource "azurerm_monitor_scheduled_query_rules_alert_v2" "rsv_backup_failure" {
  name                 = "rsv-backup-job-failure"
  location             = local.loc
  resource_group_name  = local.rg
  severity             = 1
  description          = "RSV backup job failed – DR operator must investigate"
  evaluation_frequency = "PT1H"
  window_duration      = "PT1H"
  scopes               = [data.azurerm_recovery_services_vault.rsv.id]

  criteria {
    query = <<-QUERY
      AddonAzureBackupJobs
      | where JobStatus == "Failed"
      | where BackupItemType in ("AzureIaasVM", "SQLDataBase")
    QUERY
    time_aggregation_method = "Count"
    threshold               = 0
    operator                = "GreaterThan"
    failing_periods {
      minimum_failing_periods_to_trigger_alert = 1
      number_of_evaluation_periods             = 1
    }
  }

  action { action_groups = [azurerm_monitor_action_group.infra_ag.id] }
}

# Gap fix Scenario 2: RSV soft-deleted recovery
# Run this BEFORE terraform apply when RSV shows as soft-deleted
resource "null_resource" "rsv_soft_delete_recovery" {
  triggers = { rsv_name = var.rsv_name }

  provisioner "local-exec" {
    command = <<-CMD
      echo "Checking if RSV ${var.rsv_name} is soft-deleted..."
      STATE=$(az backup vault show \
        --name ${var.rsv_name} \
        --resource-group ${var.resource_group_name} \
        --query "properties.provisioningState" -o tsv 2>/dev/null || echo "NotFound")

      if [ "$STATE" = "NotFound" ]; then
        echo "RSV not found – attempting soft-delete recovery..."
        RSV_ID=$(az resource list \
          --resource-type "Microsoft.RecoveryServices/vaults" \
          --query "[?name=='${var.rsv_name}'].id" -o tsv 2>/dev/null || echo "")

        if [ -n "$RSV_ID" ]; then
          az resource invoke-action \
            --action recoverSoftDeleted \
            --ids "$RSV_ID" \
            --request-body "{}" 2>/dev/null \
            && echo "RSV recovered from soft-delete" \
            || echo "WARN: RSV soft-delete recovery failed – may need manual portal recovery"
        else
          echo "WARN: RSV not found even in soft-deleted state – terraform will recreate via backup policy"
        fi
      else
        echo "RSV is active (state=$STATE) – no recovery needed"
      fi
    CMD
    interpreter = ["bash", "-c"]
  }
}

output "step1_verify" {
  description = "Step 1 verification + manual fix commands for scenarios Terraform cannot auto-fix"
  value = <<-EOT
    === STEP 1 – RSV Verification ===

    # Confirm vault healthy
    az backup vault show --name ${var.rsv_name} --resource-group ${local.rg} \
      --query "{state:properties.provisioningState,softDelete:properties.softDeleteFeatureState}" -o json

    # SCENARIO 3 FIX: If replication changed from GRS to LRS (Terraform cannot enforce on data block):
    az backup vault backup-properties set \
      --name ${var.rsv_name} --resource-group ${local.rg} \
      --backup-storage-redundancy GeoRedundant

    # SCENARIO 6 FIX: If soft-delete was disabled (Terraform cannot enforce on data block):
    az backup vault update \
      --name ${var.rsv_name} --resource-group ${local.rg} \
      --soft-delete-feature-state Enable

    # Confirm backup items
    az backup item list --resource-group ${local.rg} --vault-name ${var.rsv_name} -o table

    # Latest restore point (RPO gap)
    az backup recoverypoint list \
      --resource-group ${local.rg} --vault-name ${var.rsv_name} \
      --container-name "iaasvmcontainer;iaasvmcontainerv2;${local.rg};${var.vm_name}" \
      --item-name "vm;iaasvmcontainerv2;${local.rg};${var.vm_name}" -o table
  EOT
}
