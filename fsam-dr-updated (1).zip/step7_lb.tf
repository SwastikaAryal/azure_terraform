###############################################################################
# step7_lb.tf
# GAP FIXES applied:
#   ✅ Scenario 5 (diagnostic logs disabled): already owned – re-created on apply
#   ⚠️ Scenario 4 (public IP / VIP deleted): lb-vip alert fires + output fix cmds
#   ⚠️ Scenario 1 (LB deleted): output with recreate commands
#   ⚠️ Scenario 2 (probe misconfigured): output with fix command
#   ⚠️ Scenario 3 (backend pool removed): output with fix command
###############################################################################

resource "azurerm_monitor_diagnostic_setting" "lb_diag" {
  name                       = "lb-diag-dr"
  target_resource_id         = data.azurerm_lb.lb.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.law.id

  metric { category = "AllMetrics"; enabled = true }
}

# Alert: backend health probe failing
resource "azurerm_monitor_metric_alert" "lb_dip" {
  name                = "lb-backend-unhealthy"
  resource_group_name = local.rg
  scopes              = [data.azurerm_lb.lb.id]
  description         = "LB backend health probe failing – VM unreachable"
  severity            = 1
  frequency           = "PT1M"
  window_size         = "PT5M"

  criteria {
    metric_namespace = "Microsoft.Network/loadBalancers"
    metric_name      = "DipAvailability"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 100
  }

  action { action_group_id = azurerm_monitor_action_group.infra_ag.id }
}

# Alert: frontend VIP unavailable
resource "azurerm_monitor_metric_alert" "lb_vip" {
  name                = "lb-vip-unavailable"
  resource_group_name = local.rg
  scopes              = [data.azurerm_lb.lb.id]
  description         = "LB VIP unavailable – frontend unreachable"
  severity            = 1
  frequency           = "PT1M"
  window_size         = "PT5M"

  criteria {
    metric_namespace = "Microsoft.Network/loadBalancers"
    metric_name      = "VipAvailability"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 100
  }

  action { action_group_id = azurerm_monitor_action_group.infra_ag.id }
}

output "step7_verify" {
  description = "Step 7 verification + manual fix commands"
  value = <<-EOT
    === STEP 7 – Load Balancer Verification ===

    # Confirm LB config
    az network lb show --name ${var.lb_name} --resource-group ${local.rg} \
      --query "{frontendIPs:frontendIPConfigurations[].name,backendPools:backendAddressPools[].name,probes:probes[].{name:name,port:port}}" -o json

    # SCENARIO 1 FIX: LB deleted – recreate from last exported config then terraform apply:
    # az network lb create --name ${var.lb_name} --resource-group ${local.rg} --sku Standard ...
    # Then: terraform apply (recreates diagnostic settings and alerts)

    # SCENARIO 2 FIX: Health probe misconfigured:
    az network lb probe update --lb-name ${var.lb_name} --resource-group ${local.rg} \
      --name <probe-name> --protocol Https --port 443 --path /health

    # SCENARIO 3 FIX: Backend pool VM association removed:
    az network lb address-pool address add \
      --lb-name ${var.lb_name} --resource-group ${local.rg} \
      --pool-name <pool-name> --name ${var.vm_name} \
      --vnet ${var.vnet_name} --ip-address <vm-private-ip>

    # SCENARIO 4 FIX: Public IP deleted – recreate and update LB frontend:
    # az network public-ip create --name fsamuat-lb-pip --resource-group ${local.rg} --sku Standard
    # az network lb frontend-ip update --lb-name ${var.lb_name} --resource-group ${local.rg} \
    #   --name <frontend-name> --public-ip-address fsamuat-lb-pip

    # Export LB config as source-of-truth snapshot
    az network lb show --name ${var.lb_name} --resource-group ${local.rg} -o json \
      > lb-config-export-$(date +%Y%m%d).json
  EOT
}
