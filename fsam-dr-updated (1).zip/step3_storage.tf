###############################################################################
# step3_storage.tf
# GAP FIXES applied:
#   ✅ Scenario 4 (lifecycle policy removed): already owned – re-created on apply
#   ✅ Scenario 3 (container deleted): NEW – azurerm_storage_container owned by TF
#   ⚠️ Scenario 1 (SA deleted): output with recreate commands
#   ⚠️ Scenario 2 (ZRS drift): output with fix command
#   ⚠️ Scenario 5 (public access enabled): output with fix command
###############################################################################

# Gap fix Scenario 3: backup staging container owned by Terraform
# If container is deleted → terraform apply recreates it automatically
resource "azurerm_storage_container" "backup_staging" {
  name                  = var.backup_container_name
  storage_account_name  = data.azurerm_storage_account.backup_sa.name
  container_access_type = "private"
}

# Lifecycle policy aligned to RSV daily/incremental retention
resource "azurerm_storage_management_policy" "backup_lifecycle" {
  storage_account_id = data.azurerm_storage_account.backup_sa.id

  rule {
    name    = "backup-staging-retention"
    enabled = true

    filters {
      blob_types   = ["blockBlob"]
      prefix_match = ["backup/"]
    }

    actions {
      base_blob {
        tier_to_cool_after_days_since_modification_greater_than    = 7
        tier_to_archive_after_days_since_modification_greater_than = 30
        delete_after_days_since_modification_greater_than          = 90
      }
      snapshot {
        delete_after_days_since_creation_greater_than = 30
      }
    }
  }
}

# Diagnostic logs: storage → Log Analytics
resource "azurerm_monitor_diagnostic_setting" "storage_diag" {
  name                       = "storage-diag-dr"
  target_resource_id         = "${data.azurerm_storage_account.backup_sa.id}/blobServices/default"
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.law.id

  enabled_log { category = "StorageRead" }
  enabled_log { category = "StorageWrite" }
  enabled_log { category = "StorageDelete" }
  metric      { category = "Transaction"; enabled = true }
}

# Alert: storage availability drop
resource "azurerm_monitor_metric_alert" "storage_availability" {
  name                = "storage-availability-drop"
  resource_group_name = local.rg
  scopes              = [data.azurerm_storage_account.backup_sa.id]
  description         = "Storage availability < 100% – backup staging at risk"
  severity            = 2
  frequency           = "PT5M"
  window_size         = "PT15M"

  criteria {
    metric_namespace = "Microsoft.Storage/storageAccounts"
    metric_name      = "Availability"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 100
  }

  action { action_group_id = azurerm_monitor_action_group.infra_ag.id }
}

output "step3_verify" {
  description = "Step 3 verification + manual fix commands"
  value = <<-EOT
    === STEP 3 – Storage Verification ===

    # Confirm replication = ZRS
    az storage account show --name ${var.storage_account_name} --resource-group ${local.rg} \
      --query "{replication:sku.name,tier:sku.tier}" -o json

    # SCENARIO 2 FIX: If replication downgraded to LRS (cannot enforce via data block):
    az storage account update \
      --name ${var.storage_account_name} --resource-group ${local.rg} \
      --sku Standard_ZRS

    # SCENARIO 5 FIX: If public access enabled (cannot enforce via data block):
    az storage account update \
      --name ${var.storage_account_name} --resource-group ${local.rg} \
      --allow-blob-public-access false

    # SCENARIO 1 FIX: If SA deleted – recreate manually then run terraform apply:
    az storage account create \
      --name ${var.storage_account_name} --resource-group ${local.rg} \
      --sku Standard_ZRS --kind StorageV2 \
      --allow-blob-public-access false --min-tls-version TLS1_2
    # Then: terraform apply (recreates container, lifecycle policy, diagnostic settings)

    # Confirm container exists
    az storage container list --account-name ${var.storage_account_name} -o table
  EOT
}
