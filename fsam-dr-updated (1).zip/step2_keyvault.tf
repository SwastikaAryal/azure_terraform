###############################################################################
# step2_keyvault.tf
# GAP FIXES applied:
#   ✅ Scenario 3 (MI role removed): already owned – re-created on apply
#   ✅ Scenario 5 (secret deleted): NEW – azurerm_key_vault_secret slots added
#   ✅ Scenario 4 (PE disconnected): NEW – azurerm_private_endpoint owned by TF
#   ⚠️ Scenario 2 (purge-protection): cannot set via data block – output fix cmd
#   ⚠️ Scenario 1 (KV deleted): provider auto-recover on soft-delete; output for hard-purge
#   ❌ Scenario 6 (geo-redundancy): platform-managed, output only
###############################################################################

# MI → Key Vault Secrets User
# Gap Scenario 3: if removed → terraform apply re-creates automatically
resource "azurerm_role_assignment" "app_mi_kv_secrets_user" {
  scope                = data.azurerm_key_vault.kv.id
  role_definition_name = "Key Vault Secrets User"
  principal_id         = var.app_managed_identity_principal_id
}

# KV Admin for DBA / infra team
resource "azurerm_role_assignment" "kv_admin" {
  for_each             = toset(var.admin_object_ids)
  scope                = data.azurerm_key_vault.kv.id
  role_definition_name = "Key Vault Administrator"
  principal_id         = each.value
}

# Gap fix Scenario 5: Secret slots owned by Terraform
# Slot is recreated on terraform apply if deleted.
# lifecycle ignore_changes = [value] means DBA sets real value; TF only manages the slot.
resource "azurerm_key_vault_secret" "sql_sa_password" {
  name         = "sql-sa-password"
  value        = var.sql_sa_password_placeholder
  key_vault_id = data.azurerm_key_vault.kv.id

  lifecycle {
    ignore_changes = [value]  # DBA sets real value post-restore; TF only recreates the slot
  }

  depends_on = [azurerm_role_assignment.kv_admin]
}

resource "azurerm_key_vault_secret" "db_connection_string" {
  name         = "db-connection-string"
  value        = var.db_connection_string_placeholder
  key_vault_id = data.azurerm_key_vault.kv.id

  lifecycle {
    ignore_changes = [value]  # DBA sets real value post-restore; TF only recreates the slot
  }

  depends_on = [azurerm_role_assignment.kv_admin]
}

# Gap fix Scenario 4: Private Endpoint owned by Terraform
# If PE is disconnected or deleted → terraform apply recreates and auto-approves it
resource "azurerm_private_endpoint" "kv_pe" {
  name                = "fsamuat-kvprivatebmw-pe"
  location            = local.loc
  resource_group_name = local.rg
  subnet_id           = data.azurerm_subnet.app_subnet.id

  private_service_connection {
    name                           = "kv-psc"
    private_connection_resource_id = data.azurerm_key_vault.kv.id
    subresource_names              = ["vault"]
    is_manual_connection           = false  # auto-approved = Connection state: Approved
  }

  tags = local.tags
}

# Diagnostic logs: KV audit events → Log Analytics
resource "azurerm_monitor_diagnostic_setting" "kv_diag" {
  name                       = "kv-diag-dr"
  target_resource_id         = data.azurerm_key_vault.kv.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.law.id

  enabled_log { category = "AuditEvent" }
  metric      { category = "AllMetrics"; enabled = true }
}

# Alert: KV availability drop
resource "azurerm_monitor_metric_alert" "kv_availability" {
  name                = "kv-availability-drop"
  resource_group_name = local.rg
  scopes              = [data.azurerm_key_vault.kv.id]
  description         = "KV availability < 100% – check soft-delete/purge state"
  severity            = 1
  frequency           = "PT5M"
  window_size         = "PT15M"

  criteria {
    metric_namespace = "Microsoft.KeyVault/vaults"
    metric_name      = "Availability"
    aggregation      = "Average"
    operator         = "LessThan"
    threshold        = 100
  }

  action { action_group_id = azurerm_monitor_action_group.infra_ag.id }
}

output "step2_verify" {
  description = "Step 2 verification + manual fix commands"
  value = <<-EOT
    === STEP 2 – Key Vault Verification ===

    # Confirm KV not purged
    az keyvault show --name ${var.keyvault_name} --resource-group ${local.rg} \
      --query "{softDelete:properties.enableSoftDelete,purgeProtection:properties.enablePurgeProtection}" -o json

    # SCENARIO 2 FIX: Enable purge-protection (cannot set via data block, set once manually):
    az keyvault update --name ${var.keyvault_name} --resource-group ${local.rg} \
      --enable-purge-protection true

    # SCENARIO 1 FIX: If KV hard-purged, DBA must re-set secret values after terraform apply:
    az keyvault secret set --vault-name ${var.keyvault_name} --name sql-sa-password --value "<real-pwd>"
    az keyvault secret set --vault-name ${var.keyvault_name} --name db-connection-string --value "<real-conn-str>"

    # Confirm PE connection state = Approved
    az network private-endpoint show --name fsamuat-kvprivatebmw-pe --resource-group ${local.rg} \
      --query "privateLinkServiceConnections[0].privateLinkServiceConnectionState" -o json

    # Test MI access from inside VM (PowerShell):
    # $t = (Invoke-RestMethod "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://vault.azure.net" -Headers @{Metadata="true"}).access_token
    # Invoke-RestMethod "https://${var.keyvault_name}.vault.azure.net/secrets/sql-sa-password?api-version=7.3" -Headers @{Authorization="Bearer $t"}

    # If MI access fails – re-run:
    # terraform apply -target=azurerm_role_assignment.app_mi_kv_secrets_user
  EOT
}
