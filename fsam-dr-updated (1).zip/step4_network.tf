###############################################################################
# step4_network.tf
# GAP FIXES applied:
#   ✅ Scenario 3 (flow logs disabled): already owned – re-created on apply
#   ✅ Scenario 6 (Network Watcher deleted): already owned – re-created on apply
#   ✅ Scenario 1,2,5,9b (NSG outbound rules): NEW – TF-owned outbound rules added
#   ⚠️ Scenario 1 (VNet deleted): output with manual recreate commands
#   ⚠️ Scenario 2 (NSG inbound rule blocks SQL): output with fix command
#   ⚠️ Scenario 4 (NIC deleted): output with recreate commands
#   ⚠️ Scenario 5 (subnet prefix changed): output with fix commands
###############################################################################

# Network Watcher – owned by Terraform
resource "azurerm_network_watcher" "nw" {
  name                = "fsamuat-network-watcher"
  location            = local.loc
  resource_group_name = local.rg
  tags                = local.tags
}

# NSG flow logs → Storage + Log Analytics
resource "azurerm_network_watcher_flow_log" "nsg_flow_log" {
  network_watcher_name      = azurerm_network_watcher.nw.name
  resource_group_name       = local.rg
  name                      = "fsamuat-nsg-flowlog"
  network_security_group_id = data.azurerm_network_security_group.nsg.id
  storage_account_id        = data.azurerm_storage_account.backup_sa.id
  enabled                   = true

  retention_policy {
    enabled = true
    days    = 30
  }

  traffic_analytics {
    enabled               = true
    workspace_id          = data.azurerm_log_analytics_workspace.law.workspace_id
    workspace_region      = data.azurerm_log_analytics_workspace.law.location
    workspace_resource_id = data.azurerm_log_analytics_workspace.law.id
    interval_in_minutes   = 10
  }

  tags = local.tags
}

# Gap fix Scenarios 1,2,5,9b: Outbound NSG rules owned by Terraform
# These ensure external connectivity and SQL access are always enforced.
# If rules are deleted or overridden → terraform apply restores them.

resource "azurerm_network_security_rule" "allow_sql_inbound" {
  name                        = "TF-Allow-SQL-Inbound"
  priority                    = var.nsg_outbound_priority_start
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "1433"
  source_address_prefix       = "10.0.0.0/16"
  destination_address_prefix  = "*"
  resource_group_name         = local.rg
  network_security_group_name = data.azurerm_network_security_group.nsg.name
  description                 = "DR: Allow SQL 1433 inbound from VNet. Terraform-managed – do not delete."
}

resource "azurerm_network_security_rule" "allow_https_inbound" {
  name                        = "TF-Allow-HTTPS-Inbound"
  priority                    = var.nsg_outbound_priority_start + 1
  direction                   = "Inbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "*"
  destination_address_prefix  = "*"
  resource_group_name         = local.rg
  network_security_group_name = data.azurerm_network_security_group.nsg.name
  description                 = "DR: Allow HTTPS 443 inbound. Terraform-managed – do not delete."
}

resource "azurerm_network_security_rule" "allow_outbound_cognito" {
  name                        = "TF-Allow-Outbound-Cognito"
  priority                    = var.nsg_outbound_priority_start + 10
  direction                   = "Outbound"
  access                      = "Allow"
  protocol                    = "Tcp"
  source_port_range           = "*"
  destination_port_range      = "443"
  source_address_prefix       = "*"
  destination_address_prefix  = "Internet"
  resource_group_name         = local.rg
  network_security_group_name = data.azurerm_network_security_group.nsg.name
  description                 = "DR: Allow outbound HTTPS to AWS Cognito/Vertex/AWS API. Terraform-managed."
}

# Diagnostic settings: NSG → Log Analytics
resource "azurerm_monitor_diagnostic_setting" "nsg_diag" {
  name                       = "nsg-diag-dr"
  target_resource_id         = data.azurerm_network_security_group.nsg.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.law.id

  enabled_log { category = "NetworkSecurityGroupEvent" }
  enabled_log { category = "NetworkSecurityGroupRuleCounter" }
}

# Diagnostic settings: VNet → Log Analytics
resource "azurerm_monitor_diagnostic_setting" "vnet_diag" {
  name                       = "vnet-diag-dr"
  target_resource_id         = data.azurerm_virtual_network.vnet.id
  log_analytics_workspace_id = data.azurerm_log_analytics_workspace.law.id

  metric { category = "AllMetrics"; enabled = true }
}

output "step4_verify" {
  description = "Step 4 verification + manual fix commands"
  value = <<-EOT
    === STEP 4 – Network Verification ===

    # Confirm NSG flow logs active
    az network watcher flow-log show --location ${local.loc} --name fsamuat-nsg-flowlog -o json

    # Confirm TF-managed NSG rules are present
    az network nsg rule list --nsg-name ${var.nsg_name} --resource-group ${local.rg} \
      --query "[?contains(name,'TF-')].{Name:name,Dir:direction,Access:access,Port:destinationPortRange}" -o table

    # SCENARIO 1 FIX: VNet deleted – recreate manually then run terraform apply:
    # az network vnet create --name ${var.vnet_name} --resource-group ${local.rg} --address-prefix 10.0.0.0/16
    # az network vnet subnet create --vnet-name ${var.vnet_name} --name app-subnet --resource-group ${local.rg} --address-prefix 10.0.1.0/24
    # Then: terraform apply (recreates flow logs, NSG rules, diagnostic settings)

    # SCENARIO 4 FIX: NIC deleted – recreate manually then run terraform apply:
    # az network nic create --name fsam-uat-vm-nic --resource-group ${local.rg} \
    #   --vnet-name ${var.vnet_name} --subnet app-subnet

    # SCENARIO 5 FIX: Subnet prefix changed – requires VM detach/reattach (coordinate with team)
    az network vnet show --name ${var.vnet_name} --resource-group ${local.rg} \
      --query "subnets[].{Name:name,NSG:networkSecurityGroup.id,Prefix:addressPrefix}" -o table
  EOT
}
