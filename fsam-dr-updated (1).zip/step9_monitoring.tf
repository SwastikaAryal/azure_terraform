###############################################################################
# step9_monitoring.tf
# GAP FIXES applied:
#   ✅ Scenario 2 (action group deleted): already owned – re-created on apply
#   ✅ Scenario 3 (all alerts deleted): all alert resources owned – re-created on apply
#   ✅ Scenario 4 (DCR dissociated): already owned – re-associated on apply
#   ✅ Scenario 5 (Monitor Agent removed): already owned – re-deployed on apply
#   ⚠️ Scenario 1 (LAW deleted): output with recreate commands + re-link steps
###############################################################################

# Action Group – shared by every alert across all steps
resource "azurerm_monitor_action_group" "infra_ag" {
  name                = "fsamuat-infra-alerts"
  resource_group_name = local.rg
  short_name          = "fsam-ag"

  email_receiver {
    name                    = "infra-team"
    email_address           = var.alert_email
    use_common_alert_schema = true
  }

  tags = local.tags
}

# Data Collection Rule: VM perf + events → Log Analytics
resource "azurerm_monitor_data_collection_rule" "vm_dcr" {
  name                = "fsamuat-vm-dcr"
  resource_group_name = local.rg
  location            = local.loc
  tags                = local.tags

  destinations {
    log_analytics {
      workspace_resource_id = data.azurerm_log_analytics_workspace.law.id
      name                  = "law-dest"
    }
  }

  data_flow {
    streams      = ["Microsoft-Perf", "Microsoft-Event"]
    destinations = ["law-dest"]
  }

  data_sources {
    performance_counter {
      streams                       = ["Microsoft-Perf"]
      sampling_frequency_in_seconds = 60
      counter_specifiers = [
        "\\Processor(_Total)\\% Processor Time",
        "\\Memory\\Available MBytes",
        "\\LogicalDisk(C:)\\% Free Space",
        "\\LogicalDisk(E:)\\% Free Space",
        "\\Network Interface(*)\\Bytes Total/sec",
      ]
      name = "vm-perf-counters"
    }

    windows_event_log {
      streams        = ["Microsoft-Event"]
      x_path_queries = [
        "Application!*[System[(Level=1 or Level=2)]]",
        "System!*[System[(Level=1 or Level=2)]]",
      ]
      name = "vm-event-logs"
    }
  }
}

# Associate DCR with VM – Gap Scenario 4: re-associated on apply if removed
resource "azurerm_monitor_data_collection_rule_association" "vm_dcr_assoc" {
  name                    = "fsamuat-vm-dcr-assoc"
  target_resource_id      = data.azurerm_virtual_machine.vm.id
  data_collection_rule_id = azurerm_monitor_data_collection_rule.vm_dcr.id
}

# Azure Monitor Agent – Gap Scenario 5: re-deployed on apply if removed
resource "azurerm_virtual_machine_extension" "ama" {
  name                       = "AzureMonitorWindowsAgent"
  virtual_machine_id         = data.azurerm_virtual_machine.vm.id
  publisher                  = "Microsoft.Azure.Monitor"
  type                       = "AzureMonitorWindowsAgent"
  type_handler_version       = "1.0"
  auto_upgrade_minor_version = true
  tags                       = local.tags
}

output "step9_verify" {
  description = "Step 9 verification + manual fix commands"
  value = <<-EOT
    === STEP 9 – Monitoring Verification ===

    # Confirm heartbeat ingestion (run in LAW → Logs):
    # Heartbeat | where Computer == "${var.vm_name}" | summarize max(TimeGenerated)

    # Confirm all alert rules enabled
    az monitor metrics alert list --resource-group ${local.rg} -o table
    az monitor scheduled-query list --resource-group ${local.rg} -o table

    # Confirm action group active
    az monitor action-group show --name fsamuat-infra-alerts --resource-group ${local.rg} -o json

    # SCENARIO 1 FIX: LAW deleted – recreate manually then run terraform apply:
    az monitor log-analytics workspace create \
      --workspace-name ${var.law_name} --resource-group ${local.rg} \
      --sku PerGB2018 --retention-time 90
    # Then: terraform apply (re-creates DCR, DCR association, all diagnostic settings, all alerts)

    # Confirm Monitor Agent running on VM (PowerShell):
    # Get-Service -Name AzureMonitorAgent
  EOT
}
